# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 查看 msigdbr C3 MIRDB 集名格式
suppressPackageStartupMessages(library(msigdbr))
c3 <- msigdbr(species = "Homo sapiens", category = "C3", subcategory = "MIR:MIRDB")
gs <- unique(c3$gs_name)
cat("MIRDB sets:", length(gs), "\n")
print(head(gs, 15))
# 找含 146 / 181 / 29 的
for (k in c("146","181","29","223","155")) {
  cat("\nmiR", k, "sets:\n")
  print(grep(paste0("MIR_", k, "(_|[^0-9])"), gs, value = TRUE)[1:4])
}
