# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E6e - 可迁移性分析【最终修正版】
# 修: ① merge 加 sort = FALSE(E6c 的死亡时间错位根因)
#     ② gcs_total 改名规则
#     ③ subject 级聚类 bootstrap(与主分析一致)
#     ④ 密度比权重截断 [0.1,10]
# 用法: source(file.path(PATHS$clinical, "步骤E6e-可迁移性最终修正版.R"), encoding="UTF-8")  约 25 分钟
# ============================================================

library(data.table)
options(error = NULL); set.seed(2026)
dir_out   <- PATHS$clinical
dir_mimic <- PATHS$mimic   # 若不一致请改
G <- 48; B <- 200

f_mimic <- file.path(dir_out, "01_分析队列.csv")

xvars <- c("age","female","gcs","mech_vent","neurosx","sbp","hr",
           "platelet","hemoglobin","creatinine","glucose")

# ---- MIMIC: 从 admissions 合并 deathtime -> death_hrs ----
build_death_hrs_mimic <- function(dt) {
  f_adm <- file.path(dir_mimic, "hosp", "admissions.csv.gz")
  if (!file.exists(f_adm)) f_adm <- file.path(dir_mimic, "hosp", "admissions.csv")
  if (!file.exists(f_adm)) { cat("!! 找不到 admissions 表, 退回 outtime 近似\n"); return(NULL) }
  adm <- fread(f_adm, select = c("hadm_id", "deathtime"))
  adm <- adm[!is.na(hadm_id)]
  dt2 <- merge(dt, adm, by = "hadm_id", all.x = TRUE, sort = FALSE)
  dh <- rep(Inf, nrow(dt2))
  has_dt <- !is.na(dt2$deathtime)
  dh[has_dt] <- as.numeric(difftime(as.POSIXct(dt2$deathtime[has_dt]),
                                    as.POSIXct(dt2$intime[has_dt]), units = "hours"))
  # hosp_mort==1 但无 deathtime: 用 outtime 作上限近似
  fb <- dt2$hosp_mort == 1 & !has_dt
  if (any(fb)) {
    dh[fb] <- as.numeric(difftime(as.POSIXct(dt2$outtime[fb]),
                                  as.POSIXct(dt2$intime[fb]), units = "hours"))
    cat("MIMIC: ", sum(fb), " 例住院死亡无 deathtime, 用 outtime 近似\n")
  }
  cat("MIMIC: death_hrs 合并完成, 72h 内死亡 =", sum(dh <= 72, na.rm = TRUE), "\n")
  dh
}

prep <- function(path, dbname) {
  dt <- fread(path)
  nn <- names(dt); low <- tolower(nn)
  ren <- c("^gcs_min$|^gcs_first$|^gcs_admit$|^gcs_total$" = "gcs",
           "^anchor_age$" = "age", "^hospital_expire_flag$" = "hosp_mort",
           "^ventilation$|^vent$" = "mech_vent")
  for (pat in names(ren)) {
    hit <- nn[grepl(pat, low) & nn != ren[[pat]]]
    if (length(hit) >= 1 && !(ren[[pat]] %in% nn)) setnames(dt, hit[1], ren[[pat]])
  }
  if (!"female" %in% names(dt) && "gender" %in% names(dt))
    dt[, female := as.integer(gender %in% c("F", "Female", "女"))]
  if (!"death_hrs" %in% names(dt)) {
    if (dbname == "MIMIC") {
      dh <- build_death_hrs_mimic(dt)
      if (!is.null(dh)) dt[, death_hrs := dh]
    }
  }
  if (!"death_hrs" %in% names(dt)) {
    if ("hospitaldischargeoffset" %in% names(dt)) {
      dt[, death_hrs := fifelse(hosp_mort == 1, as.numeric(hospitaldischargeoffset)/60, Inf)]
    } else if (all(c("deathtime", "intime") %in% names(dt))) {
      dt[, death_hrs := fifelse(hosp_mort == 1,
                                as.numeric(difftime(as.POSIXct(deathtime), as.POSIXct(intime), units = "hours")), Inf)]
    } else {
      los_col <- nn[grepl("^los", low)][1]
      if (!is.na(los_col)) {
        mult <- if (grepl("hrs|hour", tolower(los_col))) 1 else 24
        dt[, death_hrs := fifelse(hosp_mort == 1, as.numeric(get(los_col))*mult, Inf)]
        cat(dbname, ": death_hrs 由", los_col, "推算\n")
      } else {
        dt[, death_hrs := Inf]
        cat(dbname, ": !! 无死亡时间信息, ev_before_div 将全为 0(结果不可信)\n")
      }
    }
  }
  dt[, db := dbname]
  dt
}

dm <- prep(f_mimic, "MIMIC")
de <- prep(file.path(dir_out, "E1_分析队列.csv"), "eICU")
f_nw <- file.path(dir_out, "N1_分析队列.csv")
dw <- if (file.exists(f_nw)) prep(f_nw, "NWICU") else NULL
all_d <- list(MIMIC = dm, eICU = de); if (!is.null(dw)) all_d$NWICU <- dw
common <- Reduce(intersect, lapply(all_d, function(d) intersect(xvars, names(d))))
cat("共同协变量:", paste(common, collapse = ", "), "\n")
if (!"gcs" %in% common) cat("!! 警告: gcs 未进入共同协变量集, 请检查各库 GCS 列名\n")
for (nm in names(all_d)) {
  d <- all_d[[nm]]
  for (v in common) if (any(is.na(d[[v]]))) d[is.na(get(v)), (v) := median(d[[v]], na.rm = TRUE)]
  all_d[[nm]] <- d
  cat(nm, ": n =", nrow(d), " 分流前死亡(<=", G, "h) =",
      sum(d$hosp_mort == 1 & d$death_hrs <= G, na.rm = TRUE), "\n")
}

# ---- 核心估计器: 带外权重 IPCW-HT, 返回原始 RD ----
ht_point <- function(dt, w_extra, f) {
  n <- nrow(dt)
  cl <- rbind(copy(dt)[, arm := 1L][, wx := w_extra], copy(dt)[, arm := 0L][, wx := w_extra])
  cl[, t_div := pmin(first_px_hrs, G, na.rm = FALSE)]
  cl[is.na(first_px_hrs), t_div := G]
  cl[, adherent := as.integer((arm == 1 & !is.na(first_px_hrs) & first_px_hrs <= G) |
                                (arm == 0 & (is.na(first_px_hrs) | first_px_hrs > G)))]
  cl[, ev_before_div := as.integer(hosp_mort == 1 & death_hrs <= t_div)]
  cl[, Y := hosp_mort]
  cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
  m <- suppressWarnings(glm(f, data = cl[ev_before_div == 0], family = binomial))
  pc <- pmin(pmax(predict(m, newdata = cl, type = "response"), 0.02), 0.98)
  cl[, w := fifelse(kept == 1 & ev_before_div == 1, 1, fifelse(kept == 1, 1/pc, 0)) * wx]
  den <- sum(w_extra)
  k <- cl[kept == 1]
  sum(k$w*(k$arm==1)*k$Y)/den - sum(k$w*(k$arm==0)*k$Y)/den
}

# subject 级聚类 bootstrap(与主分析一致); 行号重抽样后同步取 w_extra
ht_trans <- function(dt, w_extra, f, label) {
  rd <- ht_point(dt, w_extra, f)
  n <- nrow(dt)
  boot <- replicate(B, {
    if ("subject_id" %in% names(dt)) {
      sids <- unique(dt$subject_id)
      drawn <- sample(sids, length(sids), TRUE)
      bi <- unlist(lapply(drawn, function(s) which(dt$subject_id == s)))
    } else bi <- sample(seq_len(n), n, TRUE)
    tryCatch(ht_point(dt[bi], w_extra[bi], f), error = function(e) NA_real_)
  })
  cat(sprintf("  [%s] bootstrap 成功率: %d/%d\n", label, sum(!is.na(boot)), B))
  ci <- quantile(boot, c(.025, .975), na.rm = TRUE)
  list(rd = 100*rd, lo = 100*ci[1], hi = 100*ci[2])
}

comb <- rbindlist(lapply(all_d, function(d) d[, c(common, "db"), with = FALSE]), fill = TRUE)
comb[, db := factor(db)]
f <- reformulate(c("factor(arm)", common), response = "adherent")
res <- list()
for (src_db in setdiff(names(all_d), "MIMIC")) {
  sub <- rbind(comb[db == "MIMIC"], comb[db == src_db])
  sub[, is_mimic := as.integer(db == "MIMIC")]
  mm <- glm(reformulate(common, response = "is_mimic"), data = sub, family = binomial)
  pm <- pmin(pmax(predict(mm, newdata = sub, type = "response"), 0.05), 0.95)
  w_src <- pmin(pmax(pm/(1-pm), 0.1), 10)
  w_src <- w_src / mean(w_src[sub$db == src_db])
  w_extra_src <- w_src[sub$db == src_db]
  cat(sprintf("\n===== %s -> MIMIC 人群 =====\n", src_db))
  r_crude <- ht_trans(all_d[[src_db]], rep(1, nrow(all_d[[src_db]])), f, paste0(src_db, "-原始"))
  cat(sprintf("%s 原始: %+.2fpp (%+.2f,%+.2f)\n", src_db, r_crude$rd, r_crude$lo, r_crude$hi))
  r_std <- ht_trans(all_d[[src_db]], w_extra_src, f, paste0(src_db, "-标准化"))
  cat(sprintf("%s 标准化到 MIMIC: %+.2fpp (%+.2f,%+.2f)\n", src_db, r_std$rd, r_std$lo, r_std$hi))
  res[[paste0(src_db, "_crude")]] <- data.table(db = src_db, type = "原始",
                                                rd = round(r_crude$rd,2), lo = round(r_crude$lo,2), hi = round(r_crude$hi,2))
  res[[paste0(src_db, "_std")]] <- data.table(db = src_db, type = "标准化到MIMIC人群",
                                              rd = round(r_std$rd,2), lo = round(r_std$lo,2), hi = round(r_std$hi,2))
}
cat("\n===== MIMIC 参照 =====\n")
r_mimic <- ht_trans(all_d$MIMIC, rep(1, nrow(all_d$MIMIC)), f, "MIMIC-参照")
cat(sprintf("MIMIC 原始(参照): %+.2fpp (%+.2f,%+.2f)\n", r_mimic$rd, r_mimic$lo, r_mimic$hi))
res[["MIMIC"]] <- data.table(db = "MIMIC", type = "原始(参照)",
                             rd = round(r_mimic$rd,2), lo = round(r_mimic$lo,2), hi = round(r_mimic$hi,2))

res_all <- rbindlist(res)
print(res_all)
fwrite(res_all, file.path(dir_out, "E6_可迁移性结果.csv"))
cat("/n完成 -> [clinical output directory]/E6_可迁移性结果.csv/n")
cat("\n【核对要点】MIMIC 参照应接近主分析的 -5.8pp; 若仍明显偏离, 把控制台输出发我\n")
