# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 读全部 feature_ref 映射 + series matrix 治疗分组
ex <- file.path(PATHS$project, "00_data/GSE313043/extracted")
dd <- file.path(PATHS$project, "00_data/GSE313043")
for (f in list.files(ex, pattern = "feature_ref")) {
  fr <- read.csv(gzfile(file.path(ex, f)))
  cat("\n###", sub("_feature_ref.csv.gz", "", f), "\n")
  print(fr[, c("id", "multiplexed_sample")])
}
cat("\n\n========== SERIES MATRIX (GPL24676) ==========\n")
sm <- readLines(gzfile(file.path(dd, "GSE313043-GPL24676_series_matrix.txt.gz")))
cat("lines:", length(sm), "\n")
idx <- grep("Sample_title|Sample_geo|Sample_characteristics|Sample_source", sm)
cat(sm[idx], sep = "\n")
