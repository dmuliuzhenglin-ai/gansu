# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
suppressPackageStartupMessages(library(msigdbr))
c3 <- msigdbr(species = "Homo sapiens", category = "C3", subcategory = "MIR:MIRDB")
gs <- unique(c3$gs_name)
non_let <- grep("^LET", gs, value = TRUE, invert = TRUE)
cat("non-LET sets:", length(non_let), "\n")
print(head(non_let, 30))
