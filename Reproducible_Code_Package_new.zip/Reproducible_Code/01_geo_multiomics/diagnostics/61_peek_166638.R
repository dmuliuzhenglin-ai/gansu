# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 查看 GSE166638 dge 表格式
f <- file.path(PATHS$project, "00_data/GSE166638/extracted/GSM5076804_Day1_050_BLD_R1_Next_dge.txt.gz")
d <- read.delim(gzfile(f), nrows = 5)
cat("preview dim:", dim(d), "\n"); print(d[, 1:min(6, ncol(d))])
dfull <- read.delim(gzfile(f))
cat("full dim:", dim(dfull), "\n"); print(head(rownames(dfull), 3))
