# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# ========================================================================
# File        : 22_ml_analyses.R
# Purpose     : ML/AI 方法学补充分析（转投前方法学加固）
#   A. Causal Forest (grf) —— 全队列：接受预防 vs 未接受（观察性对照）
#      - 全局 ATE + GCS 3-8 / 9-15 分层 CATE（验证异质性数据驱动稳健）
#      - 变量重要性（GCS 是否为最重要效应修饰因子）
#   B. Causal Forest —— 接受预防者内部：早(<=48h) vs 晚(>48h)
#      - 检验"时间效应"是否独立存在（预期≈0，与 UFH 亚组互证）
#   C. TMLE (tmle 包, SuperLearner 库) —— 双重稳健 ATE
#   D. SuperLearner 倾向性分数 + IPW —— 检验对 PS 模型选择的稳健性
# Inputs      : [clinical output directory]/01_分析队列.csv（队列含 exposure_48h/first_px_hrs/
#               hosp_mort/gcs_total 及协变量）
# Outputs     : [clinical output directory]/22_ML分析结果.txt + 22_ML分析汇总.csv
# ========================================================================
rm(list = ls())
suppressMessages({
  library(data.table)
  library(grf)
  library(tmle)
  library(SuperLearner)
  library(glmnet)
  library(ranger)
  library(xgboost)
})
set.seed(2026)

dir_out <- PATHS$clinical
sink(file.path(dir_out, "22_ML分析结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

dat <- fread(file.path(dir_out, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]
cat("队列行数：", nrow(dat), "\n")
cat("exposure_48h 分布：\n"); print(table(dat$exposure_48h, useNA = "ifany"))
cat("first_px_hrs 非NA（接受过预防）：", sum(!is.na(dat$first_px_hrs)), "\n")
cat("hosp_mort 分布：\n"); print(table(dat$hosp_mort, useNA = "ifany"))

# ----------------------------------------------------------------
# 0. 协变量矩阵（同21脚本口径：中位数填补 + 缺失指示符）
# ----------------------------------------------------------------
cat("\n== 0. 协变量预处理 ==\n")
dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")

make_X <- function(dt) {
  d <- copy(dt)
  for (v in num_vars) {
    d[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
    med <- median(d[[v]], na.rm = TRUE)
    d[is.na(get(v)), (v) := med]
  }
  miss_vars <- paste0(num_vars, "_miss")
  for (v in bin_vars) d[is.na(get(v)), (v) := FALSE]
  x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                           collapse = " + ")))
  model.matrix(x_formula, data = d)[, -1, drop = FALSE]
}
X_mm <- make_X(dat)
cat("协变量维数：", ncol(X_mm), "\n")

Y  <- as.integer(dat$hosp_mort)
W  <- fifelse(dat$exposure_48h == "早期(<=48h)", 1L, 0L)  # 1=早期预防, 0=延迟/未预防
res <- list()

# ----------------------------------------------------------------
# A. Causal Forest —— 全队列：接受早期预防 vs 其他
# ----------------------------------------------------------------
cat("\n== A. Causal Forest（全队列：早期预防 vs 其他） ==\n")
cf_all <- causal_forest(X_mm, Y, W, num.trees = 2000, seed = 2026,
                        honesty = TRUE, honesty.fraction = 0.5)
ate_all <- average_treatment_effect(cf_all, target.sample = "overlap")
cat(sprintf("全局 ATE (RD) = %.4f (95%%CI %.4f ~ %.4f), se=%.4f\n",
            ate_all[1], ate_all[1] - 1.96 * ate_all[2],
            ate_all[1] + 1.96 * ate_all[2], ate_all[2]))
res[["A_CF_global"]] <- data.table(
  analysis = "CF_global_early_vs_other", n = nrow(dat),
  ATE_RD = round(ate_all[1], 4),
  ATE_lo = round(ate_all[1] - 1.96 * ate_all[2], 4),
  ATE_hi = round(ate_all[1] + 1.96 * ate_all[2], 4))

# GCS 分层 CATE（用原始 GCS 分 3-8 vs 9-15）
dat[, gcs_cat := fifelse(is.na(gcs_total), NA_character_,
                         fifelse(gcs_total <= 8, "GCS3-8", "GCS9-15"))]
for (g in c("GCS3-8", "GCS9-15")) {
  idx <- which(dat$gcs_cat == g)
  cat(sprintf("  %s: n=%d\n", g, length(idx)))
  if (length(idx) < 50) next
  ate_g <- average_treatment_effect(cf_all, subset = idx, target.sample = "overlap")
  cat(sprintf("    %s CATE (RD) = %.4f (95%%CI %.4f ~ %.4f)\n",
              g, ate_g[1], ate_g[1] - 1.96 * ate_g[2], ate_g[1] + 1.96 * ate_g[2]))
  res[[paste0("A_CF_", gsub("-", "_", g))]] <- data.table(
    analysis = paste0("CF_CATE_", g), n = length(idx),
    ATE_RD = round(ate_g[1], 4), ATE_lo = round(ate_g[1] - 1.96 * ate_g[2], 4),
    ATE_hi = round(ate_g[1] + 1.96 * ate_g[2], 4))
}

# 变量重要性
vi <- variable_importance(cf_all)
vi_df <- data.frame(var = colnames(X_mm), imp = round(vi, 4),
                    stringsAsFactors = FALSE)
vi_df <- vi_df[order(-vi_df$imp), , drop = FALSE]
vi_dt <- as.data.table(vi_df)
cat("变量重要性 Top10：\n")
print(head(vi_dt, 10))
res[["A_CF_vi"]] <- vi_dt
cat("gcs_total 重要性排名：",
    which(vi_dt$var == "gcs_total"), "/", nrow(vi_dt), "\n")

# ----------------------------------------------------------------
# B. Causal Forest —— 接受预防者内部：早(<=48h) vs 晚(>48h)
# ----------------------------------------------------------------
cat("\n== B. Causal Forest（接受预防者内部：早 vs 晚） ==\n")
rx <- !is.na(dat$first_px_hrs)
cat("接受预防者 n =", sum(rx), "\n")
W2 <- as.integer(dat$first_px_hrs[rx] <= 48)
cat("其中早期(<=48h)：", sum(W2), "；晚期(>48h)：", sum(1 - W2), "\n")
if (sum(rx) > 200 && sum(W2) > 50 && sum(1 - W2) > 50) {
  cf_rx <- causal_forest(X_mm[rx, , drop = FALSE], Y[rx], W2,
                         num.trees = 2000, seed = 2026,
                         honesty = TRUE, honesty.fraction = 0.5)
  ate_rx <- average_treatment_effect(cf_rx, target.sample = "overlap")
  cat(sprintf("接受者内 ATE (RD) = %.4f (95%%CI %.4f ~ %.4f)\n",
              ate_rx[1], ate_rx[1] - 1.96 * ate_rx[2], ate_rx[1] + 1.96 * ate_rx[2]))
  res[["B_CF_rx_timing"]] <- data.table(
    analysis = "CF_timing_early_vs_late", n = sum(rx),
    ATE_RD = round(ate_rx[1], 4), ATE_lo = round(ate_rx[1] - 1.96 * ate_rx[2], 4),
    ATE_hi = round(ate_rx[1] + 1.96 * ate_rx[2], 4))
  for (g in c("GCS3-8", "GCS9-15")) {
    idx <- which(dat$gcs_cat[rx] == g)
    if (length(idx) < 30) next
    ate_g <- average_treatment_effect(cf_rx, subset = idx, target.sample = "overlap")
    cat(sprintf("  %s(接受者内) CATE = %.4f (95%%CI %.4f ~ %.4f), n=%d\n",
                g, ate_g[1], ate_g[1] - 1.96 * ate_g[2], ate_g[1] + 1.96 * ate_g[2],
                length(idx)))
    res[[paste0("B_CF_timing_", gsub("-", "_", g))]] <- data.table(
      analysis = paste0("CF_timing_CATE_", g), n = length(idx),
      ATE_RD = round(ate_g[1], 4), ATE_lo = round(ate_g[1] - 1.96 * ate_g[2], 4),
      ATE_hi = round(ate_g[1] + 1.96 * ate_g[2], 4))
  }
} else {
  cat("接受预防者数量不足，跳过 B。\n")
}

# ----------------------------------------------------------------
# C. TMLE —— 双重稳健 ATE（全队列：早期预防 vs 其他）
# ----------------------------------------------------------------
cat("\n== C. TMLE（SuperLearner 库，全队列） ==\n")
SL_lib <- c("SL.glm", "SL.glmnet", "SL.ranger", "SL.xgboost")
Wdf <- as.data.frame(X_mm)
tmle_fit <- tryCatch(
  tmle(Y = Y, A = W, W = Wdf, family = "binomial",
       Q.SL.library = SL_lib, g.SL.library = SL_lib,
       gbound = 0.01, verbose = FALSE),
  error = function(e) { cat("TMLE 报错：", conditionMessage(e), "\n"); NULL })
if (!is.null(tmle_fit)) {
  at <- tmle_fit$estimates$ATE
  cat(sprintf("TMLE ATE (RD) = %.4f (95%%CI %.4f ~ %.4f)\n",
              at$psi, at$CI[1], at$CI[2]))
  res[["C_TMLE"]] <- data.table(
    analysis = "TMLE_early_vs_other", n = nrow(dat),
    ATE_RD = round(at$psi, 4), ATE_lo = round(at$CI[1], 4), ATE_hi = round(at$CI[2], 4))
}

# ----------------------------------------------------------------
# D. SuperLearner 倾向性分数 + IPW（对照主分析 PS=cv.glmnet 口径）
# ----------------------------------------------------------------
cat("\n== D. SuperLearner PS + IPW（全队列） ==\n")
sl_ps <- tryCatch(
  SuperLearner(Y = W, X = Wdf, family = "binomial",
               SL.library = SL_lib, cvControl = list(V = 5, stratifyCV = TRUE)),
  error = function(e) { cat("SuperLearner 报错：", conditionMessage(e), "\n"); NULL })
if (!is.null(sl_ps)) {
  cat("SuperLearner 各学习器权重：\n")
  print(sl_ps$coef)
  ps <- sl_ps$SL.predict
  cat(sprintf("PS 范围：%.4f ~ %.4f（均值 %.4f）\n", min(ps), max(ps), mean(ps)))
  # 稳定 IPW（边际概率截断）
  stab1 <- mean(W); stab0 <- 1 - stab1
  w <- ifelse(W == 1, stab1 / pmax(ps, 0.01), stab0 / pmax(1 - ps, 0.01))
  q <- quantile(w, c(0.01, 0.99))
  w <- pmin(pmax(w, q[1]), q[2])
  r1 <- sum(w[W == 1] * Y[W == 1]) / sum(w[W == 1])
  r0 <- sum(w[W == 0] * Y[W == 0]) / sum(w[W == 0])
  rd_sl <- r1 - r0
  # 分块 bootstrap（按 subject 聚类）
  usubj <- unique(dat$subject_id)
  idx_list <- split(seq_len(nrow(dat)), dat$subject_id)
  set.seed(2026)
  bd <- numeric(300)
  for (b in 1:300) {
    bs <- sample(usubj, replace = TRUE)
    bi <- unlist(idx_list[as.character(bs)])
    wb <- w[bi]; yb <- Y[bi]; wb2 <- W[bi]
    r1b <- sum(wb[wb2 == 1] * yb[wb2 == 1]) / sum(wb[wb2 == 1])
    r0b <- sum(wb[wb2 == 0] * yb[wb2 == 0]) / sum(wb[wb2 == 0])
    bd[b] <- r1b - r0b
  }
  ci_sl <- quantile(bd, c(0.025, 0.975))
  cat(sprintf("SL-IPW RD = %.4f (95%%CI %.4f ~ %.4f)\n", rd_sl, ci_sl[1], ci_sl[2]))
  res[["D_SL_IPW"]] <- data.table(
    analysis = "SL_IPW_early_vs_other", n = nrow(dat),
    ATE_RD = round(rd_sl, 4), ATE_lo = round(ci_sl[1], 4), ATE_hi = round(ci_sl[2], 4))
  # 与主分析 cv.glmnet-PS 的 PS 相关性（诊断）
  fit_g <- cv.glmnet(X_mm, W, family = "binomial", nfolds = 5)
  ps_g <- as.numeric(predict(fit_g, X_mm, s = "lambda.min", type = "response"))
  cat(sprintf("SL-PS 与 glmnet-PS 相关系数 = %.4f\n", cor(ps, ps_g)))
}

# ----------------------------------------------------------------
# 汇总输出
# ----------------------------------------------------------------
res_all <- rbindlist(res, fill = TRUE)
cat("\n== 汇总 ==\n")
print(res_all)
fwrite(res_all, file.path(dir_out, "22_ML分析汇总.csv"))
cat("\n结果已保存：22_ML分析结果.txt / 22_ML分析汇总.csv\n")
sink()
cat("运行完毕：[clinical output directory]/22_ML分析结果.txt/n")
