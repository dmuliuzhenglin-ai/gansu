# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
suppressPackageStartupMessages(library(GSVA))
cat("GSVA version:", as.character(packageVersion("GSVA")), "\n")
cat("ssgseaParam exists:", exists("ssgseaParam"), "\n")
print(args(ssgseaParam))
cat("\ngsva args:\n"); print(args(gsva))
