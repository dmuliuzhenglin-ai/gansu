# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 00_geo_utils.R
# GEO 下载工具：绕过 R 内置 download.file 的 SSL/吊销问题，
# 目录列举用 xml2::read_html（本机已验证可用），文件下载用系统 curl.exe --ssl-no-revoke

GEO_ROOT <- "https://ftp.ncbi.nlm.nih.gov/geo/series"
CURL_EXE  <- "curl.exe"
PROXY     <- "http://127.0.0.1:7897"   # 本机 Clash 代理；置 NULL 可直连

# GSE 编号 -> GEO 系列目录 URL
gse_dir_url <- function(gse) {
  num <- as.integer(sub("GSE", "", gse))
  bucket <- paste0("GSE", floor(num / 1000), "nnn")
  file.path(GEO_ROOT, bucket, gse)
}

# 列出 GEO 目录下的条目（相对名）
# 用系统 curl 抓 HTML 再正则提取，比 xml2::read_html 更稳（部分目录页 read_html 会漏条目）
geo_dir_list <- function(url) {
  args <- c("-sS", "-L", "--ssl-no-revoke", "--connect-timeout", "20",
            shQuote(url))
  html <- system2("curl.exe", args, stdout = TRUE, stderr = TRUE)
  m <- gregexpr('href="[^"]+"', html)
  hrefs <- unlist(regmatches(html, m))
  hrefs <- gsub('^href="|"$', "", hrefs)
  # 去掉父目录、绝对链接（http 开头或以 / 开头的路径）、外部链接
  hrefs <- hrefs[!grepl("^https?://|^/|hhs.gov", hrefs)]
  sub("/$", "", hrefs)
}

# 用 curl HEAD 拿远端文件字节数
head_size <- function(url) {
  args <- c("-sS", "-I", "-L",
            if (!is.null(PROXY)) c("--proxy", PROXY),
            "--ssl-no-revoke", "--connect-timeout", "20", shQuote(url))
  out <- system2("curl.exe", args, stdout = TRUE, stderr = TRUE)
  cl <- grep("content-length:", out, ignore.case = TRUE, value = TRUE)
  if (length(cl) == 0) return(NA_real_)
  as.numeric(trimws(sub("content-length:\\s*", "", cl[length(cl)],
                        ignore.case = TRUE)))
}

# 用系统 curl 下载（跳过证书吊销检查，跟随重定向）
curl_download <- function(url, destfile, retries = 3) {
  dir.create(dirname(destfile), recursive = TRUE, showWarnings = FALSE)
  for (i in seq_len(retries)) {
    args <- c("-sS", "-L", "-C", "-",
              if (!is.null(PROXY)) c("--proxy", PROXY),
              "--ssl-no-revoke", "--connect-timeout", "30",
              "--max-time", "3600",
              "--speed-time", "60", "--speed-limit", "1024",
              "--retry", "2", "-o", shQuote(destfile), shQuote(url))
    rc <- system2(CURL_EXE, args, stdout = TRUE, stderr = TRUE)
    # 断点续传：已完整下载（本地大小达到远端大小）才算成功，否则继续重试
    if (is.null(attr(rc, "status")) && file.exists(destfile) &&
        file.info(destfile)$size > 0) {
      return(invisible(destfile))
    }
    message("download attempt ", i, " failed for ", url, ": ",
            paste(rc, collapse = " "))
    Sys.sleep(3)
  }
  stop("curl download failed after ", retries, " attempts: ", url)
}

# 下载并读取 series matrix（可能有多份 part）
get_gse_eset <- function(gse, destdir) {
  base <- gse_dir_url(gse)
  mfiles <- geo_dir_list(paste0(base, "/matrix"))
  mfiles <- mfiles[grepl("series_matrix\\.txt\\.gz$", mfiles)]
  if (length(mfiles) == 0) stop("no series matrix found for ", gse)
  esets <- list()
  for (mf in mfiles) {
    url <- paste0(base, "/matrix/", mf)
    lf <- file.path(destdir, mf)
    if (!file.exists(lf)) curl_download(url, lf)
    esets[[mf]] <- GEOquery::getGEO(filename = lf, getGPL = FALSE)
  }
  if (length(esets) == 1) esets[[1]] else esets
}

# 下载 supplementary 目录全部文件（或按正则筛选）
download_suppl <- function(gse, destdir, pattern = NULL) {
  base <- gse_dir_url(gse)
  sfiles <- tryCatch(geo_dir_list(paste0(base, "/suppl")),
                     error = function(e) character(0))
  if (!is.null(pattern)) sfiles <- sfiles[grepl(pattern, sfiles)]
  out <- character(0)
  for (sf in sfiles) {
    lf <- file.path(destdir, sf)
    if (!file.exists(lf)) curl_download(paste0(base, "/suppl/", sf), lf)
    out <- c(out, lf)
  }
  out
}

# 下载 GPL 平台注释（soft）
get_gpl_annot <- function(gpl, destdir) {
  num <- as.integer(sub("GPL", "", gpl))
  bucket <- paste0("GPL", floor(num / 1000), "nnn")
  url <- sprintf("https://ftp.ncbi.nlm.nih.gov/geo/platforms/%s/%s/annot/%s.annot.gz",
                 bucket, gpl, gpl)
  lf <- file.path(destdir, paste0(gpl, ".annot.gz"))
  if (!file.exists(lf)) curl_download(url, lf)
  lf
}
