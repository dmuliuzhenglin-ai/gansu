# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# Figure5 v3 - 三数据库主估计森林图(修正数据源)
# 数据源:
#   MIMIC-IV : 02b_结果汇总.csv    (长表, RD为比例, x100)
#   eICU-CRD : IPCW-HT 读 E2_结果汇总.csv  (rd_pp已为pp, 直接用)
#              AIPW-DR 读 E2d_结果汇总.csv (rd_pp已为pp, 直接用)
#              注意: E2d里只有AIPW-DR行; E2里的AIPW行是坏的, 绝不用
#   NWICU    : N2_结果汇总.csv 主分析-院内死亡 G=48 行 (比例制, x100)
#              注意: N2c_结果汇总.csv 只有 G24/G72/VTE 三行,
#                    没有 G48 院内死亡行, 禁止用它兜底(会抓到VTE行)
#   ATO      : E4_ATO结果.csv (已为pp)
#   标准化    : E6_可迁移性结果.csv (已为pp)
# 用法: source(file.path(PATHS$clinical, "Figure5-三库森林图v3.R"), encoding="UTF-8")
# 输出: [clinical output directory]/Figure5_forest.png (300dpi)
# ============================================================

library(data.table)
library(ggplot2)
options(error = NULL)
dir_out <- PATHS$clinical
G0 <- 48

rows <- list()
add <- function(db, est, rd, lo = NA_real_, hi = NA_real_)
  rows[[length(rows)+1]] <<- data.table(db = db, est = est, rd = rd, lo = lo, hi = hi)

# ---- MIMIC-IV: 02b (长表, RD 为比例) ----
m <- fread(file.path(dir_out, "02b_结果汇总.csv"))
m48 <- m[grace_h == G0 & outcome == "hosp_mort"]
r <- m48[method == "IPCW"]; if (nrow(r)) add("MIMIC-IV", "IPCW-HT", r$RD*100, r$RD_lo*100, r$RD_hi*100)
r <- m48[method == "AIPW"]; if (nrow(r)) add("MIMIC-IV", "AIPW",    r$RD*100, r$RD_lo*100, r$RD_hi*100)

# ---- eICU: IPCW-HT 从 E2_结果汇总.csv 读 ----
e2 <- fread(file.path(dir_out, "E2_结果汇总.csv"))
r <- e2[G == G0 & grepl("院内", spec) & est == "IPCW-HT"]
if (nrow(r)) add("eICU-CRD", "IPCW-HT", r$rd_pp[1], r$rd_lo[1], r$rd_hi[1])

# ---- eICU: AIPW-DR 从 E2d_结果汇总.csv 读 ----
e2d <- fread(file.path(dir_out, "E2d_结果汇总.csv"))
r <- e2d[G == G0 & grepl("院内", spec) & grepl("AIPW", est)]
if (nrow(r)) add("eICU-CRD", "AIPW-DR", r$rd_pp[1], r$rd_lo[1], r$rd_hi[1])

# ---- NWICU: N2_结果汇总.csv 主分析行 (宽表, 比例制) ----
n2 <- fread(file.path(dir_out, "N2_结果汇总.csv"))
n48 <- n2[G == G0 & outcome == "hosp_mort" & grepl("主分析", label)]
if (nrow(n48) == 0) stop("N2_结果汇总.csv 中找不到 主分析-院内死亡 G=48 行, 请检查文件")
r <- n48[1]
add("NWICU", "IPCW-HT", r$ipcw_RD*100, r$ipcw_RD_lo*100, r$ipcw_RD_hi*100)
if ("aipw_RD" %in% names(r) && !is.na(r$aipw_RD))
  add("NWICU", "AIPW", r$aipw_RD*100, r$aipw_RD_lo*100, r$aipw_RD_hi*100)

# ---- E4 ATO (NWICU, 48h; 已是 pp) ----
e4 <- fread(file.path(dir_out, "E4_ATO结果.csv"))
hit <- grepl("NW", toupper(e4[[1]]))
gc <- names(e4)[tolower(names(e4)) %in% c("g","grace","grace_h")][1]
if (!is.na(gc)) hit <- hit & e4[[gc]] == G0
if (any(hit)) { r <- e4[hit][1]
rdc <- names(e4)[grepl("^rd", tolower(names(e4)))][1]
add("NWICU", "ATO (overlap)", as.numeric(r[[rdc]])) }

# ---- E6 标准化 ----
e6 <- fread(file.path(dir_out, "E6_可迁移性结果.csv"))
r <- e6[db == "NWICU" & grepl("标准", type)]
if (nrow(r)) add("NWICU", "standardized to MIMIC-IV", r$rd, r$lo, r$hi)

pd <- rbindlist(rows)
pd[, lab := factor(paste0(db, "  ", est), levels = rev(paste0(db, "  ", est)))]
pd[, ci_txt := fifelse(is.na(lo), sprintf("%+.1f", rd), sprintf("%+.1f (%+.1f, %+.1f)", rd, lo, hi))]
print(pd[, .(lab, rd, lo, hi)])
cat("\n【核对】MIMIC ≈ -5.8/-6.2; eICU IPCW ≈ -3.5, AIPW ≈ -3.8;\n")
cat("        NWICU IPCW ≈ +0.3 (-0.9,+1.0), AIPW ≈ -14.7 (-19.3,-10.1);\n")
cat("        ATO ≈ -11.4; 标准化 ≈ -6.8\n")

xr <- range(c(pd$lo, pd$hi), na.rm = TRUE)
x_pad <- max(abs(xr)) * 1.15
g <- ggplot(pd, aes(y = lab, x = rd)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey60") +
  geom_errorbar(aes(xmin = lo, xmax = hi, orientation = "y"),
                width = 0.18, color = "#2C5F8A", na.rm = TRUE) +
  geom_point(size = 2.8, color = "#2C5F8A") +
  geom_text(aes(x = x_pad * 0.62, label = ci_txt), hjust = 0, size = 3.2) +
  coord_cartesian(xlim = c(-x_pad, x_pad * 0.62), clip = "off") +
  labs(x = "Risk difference for in-hospital mortality, percentage points (95% CI)\nearly vs delayed prophylaxis, 48-h grace period", y = NULL) +
  theme_classic(base_size = 11) +
  theme(plot.margin = margin(6, 100, 6, 6))
ggsave(file.path(dir_out, "Figure5_forest.png"), g, width = 8.5, height = 5, dpi = 300)
cat("完成 -> [clinical output directory]/Figure5_forest.png/n")

