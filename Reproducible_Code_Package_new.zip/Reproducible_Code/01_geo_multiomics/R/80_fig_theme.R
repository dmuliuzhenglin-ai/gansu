# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 80_fig_theme.R
# Shared journal-grade plotting theme, palettes and PDF writer for the
# integrated multi-omics manuscript. All figures are vector PDF (cairo_pdf),
# sized in physical units (1-column = 89 mm, 2-column = 180 mm).
suppressPackageStartupMessages({
  library(ggplot2); library(ggtext)
})

# ---- global typography ---------------------------------------------------
base_family <- "sans"
fig_theme <- theme_classic(base_family = base_family, base_size = 9) +
  theme(
    axis.text = element_text(size = 8, colour = "grey15"),
    axis.title = element_text(size = 9),
    axis.ticks = element_line(linewidth = .3, colour = "grey30"),
    axis.line = element_line(linewidth = .35, colour = "grey20"),
    plot.title = element_text(size = 9.5, face = "bold", hjust = 0,
                              margin = margin(b = 3)),
    plot.subtitle = element_text(size = 8, colour = "grey30"),
    legend.text = element_text(size = 7.5),
    legend.title = element_text(size = 8, face = "bold"),
    legend.key.size = unit(3.2, "mm"),
    strip.background = element_rect(fill = "grey92", linewidth = .3),
    strip.text = element_text(size = 8, face = "bold"),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    plot.margin = margin(4, 5, 4, 5)
  )

# ---- colour-blind-safe palettes ------------------------------------------
pal_dir <- c(up = "#C0392B", down = "#2471A3")          # signed direction
pal_sig <- c(significant = "#C0392B", NS = "#B2BABB")
pal_cell <- c(neutrophils = "#E67E22", monocytes = "#C0392B",
              monocytes_macrophages = "#C0392B", microglia = "#8E44AD",
              astrocytes = "#27AE60", endothelial = "#16A085",
              T_cells = "#2471A3", B_cells = "#2E86C1",
              NK_cells = "#7F8C8D", dendritic_cells = "#138D90",
              dendritic = "#138D90", unassigned = "#D5DBDB")
pal_meth <- c(hyper = "#C0392B", hypo = "#2471A3")
pal_cohort <- c(MIMIC = "#2C3E50", eICU = "#E67E22", NWICU = "#16A085")
# continuous scale for signed logFC / correlations
signed_scale <- function(limits = c(-1, 1), ...) {
  scale_fill_gradient2(low = "#2471A3", mid = "white", high = "#C0392B",
                       midpoint = 0, limits = limits, ...)
}

# ---- PDF writer ----------------------------------------------------------
save_pdf <- function(plot, name, width_mm, height_mm, figdir = NULL) {
  if (is.null(figdir))
    figdir <- file.path(PATHS$project, "03_figures")
  dir.create(figdir, showWarnings = FALSE, recursive = TRUE)
  w_in <- width_mm / 25.4; h_in <- height_mm / 25.4
  cairo_pdf(file.path(figdir, paste0(name, ".pdf")),
            width = w_in, height = h_in, onefile = FALSE)
  print(plot)
  dev.off()
  # also a high-res PNG preview for quick inspection
  png(file.path(figdir, paste0(name, ".png")),
      width = width_mm, height = height_mm, units = "mm", res = 300)
  print(plot); dev.off()
  invisible(file.path(figdir, paste0(name, ".pdf")))
}
