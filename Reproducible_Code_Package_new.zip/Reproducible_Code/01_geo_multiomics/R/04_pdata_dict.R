# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 04_pdata_dict.R - 提取各数据集 series matrix 的分组元数据
source(file.path(PATHS$project, "01_code/00_geo_utils.R"))
data_root <- file.path(PATHS$project, "00_data")

gse_list <- c("GSE296792", "GSE163256", "GSE335924", "GSE179759",
              "GSE166638", "GSE43618", "GSE313043", "GSE266873")

for (gse in gse_list) {
  cat("\n=================", gse, "=================\n")
  ddir <- file.path(data_root, gse)
  mfiles <- list.files(ddir, pattern = "series_matrix.txt.gz$", full.names = TRUE)
  if (length(mfiles) == 0) { cat("no local matrix\n"); next }
  for (mf in mfiles) {
    es <- tryCatch(GEOquery::getGEO(filename = mf, getGPL = FALSE),
                   error = function(e) e)
    if (inherits(es, "error")) { cat("read fail:", es$message, "\n"); next }
    cat("[part]", basename(mf), "samples:", ncol(Biobase::exprs(es)), "\n")
    pd <- Biobase::pData(es)
    keep <- grep(":ch1$|characteristics|source_name", colnames(pd), value = TRUE)
    for (fld in keep) {
      vals <- unique(pd[[fld]])
      cat(" ", fld, "(", length(vals), "levels):",
          paste(head(vals, 8), collapse = " | "), "\n")
    }
  }
}
