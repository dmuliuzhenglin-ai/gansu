# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 40_wgcna_gse335924.R
# Weighted gene co-expression network on GSE335924 PBMC (n=53).
# Identifies modules, relates module eigengenes to ICH status, and ranks hubs.
suppressPackageStartupMessages({ library(WGCNA); library(edgeR); library(dplyr) })
options(stringsAsFactors = FALSE)
allowWGCNAThreads(nThreads = 2)
root <- PATHS$project
resdir <- file.path(root, "02_results")

r <- readRDS(file.path(resdir, "GSE335924_edgeR.rds"))
y <- r$dge
# log2 CPM on TMM-normalised libraries, restricted to genes that passed filter
logcpm <- cpm(y, log = TRUE, normalized.lib.sizes = TRUE)
group <- as.character(y$samples$group)
cat("samples:", ncol(logcpm), "group table:", table(group), "\n")

# keep top 5000 most variable genes for a stable network
madv <- apply(logcpm, 1, mad)
keep <- order(madv, decreasing = TRUE)[1:min(5000, length(madv))]
dat <- t(logcpm[keep, ])                 # samples x genes
gname <- colnames(dat)

# soft-threshold power
pows <- 1:20
sft <- pickSoftThreshold(dat, powerVector = pows, verbose = 0,
                         networkType = "signed")
pow <- sft$powerEstimate
if (is.na(pow)) pow <- 12
cat("chosen soft power:", pow,
    "| SFT R2 at power:", round(sft$fitIndices$SFT.R.sq[match(pow, pows)], 3), "\n")

set.seed(42)
net <- blockwiseModules(
  dat, power = pow, networkType = "signed", TOMType = "unsigned",
  minModuleSize = 30, reassignThreshold = 0, mergeCutHeight = 0.25,
  numericLabels = TRUE, pamRespectsDendro = FALSE, maxBlockSize = 6000,
  verbose = 0)
labels <- net$colors
me <- net$MEs
cat("module sizes:\n"); print(table(labels))

# module eigengene vs ICH status (ICH coded 1)
ich <- as.numeric(group == "ICH")
mods <- sort(unique(labels))
trait_tab <- lapply(mods, function(m) {
  eig <- me[[paste0("ME", m)]]
  ct <- cor.test(eig, ich, use = "p")
  data.frame(module = m, n_genes = sum(labels == m),
             cor_ICH = unname(ct$estimate), p_value = ct$p.value)
}) %>% bind_rows()
trait_tab$FDR <- p.adjust(trait_tab$p_value, method = "BH")
trait_tab <- trait_tab %>% arrange(p_value)
write.csv(trait_tab, file.path(resdir, "GSE335924_WGCNA_module_trait.csv"),
          row.names = FALSE)
cat("\nmodule-trait associations:\n"); print(trait_tab, row.names = FALSE)

# gene-level module membership and gene significance; rank hubs
KME <- cor(dat, me, use = "p")
GS <- as.numeric(cor(dat, ich, use = "p"))
gene_tab <- data.frame(
  gene = gname, module = labels,
  gene_significance = GS[match(gname, gname)],
  kme = KME[cbind(seq_along(gname), match(paste0("ME", labels), colnames(KME)))])
write.csv(gene_tab, file.path(resdir, "GSE335924_WGCNA_gene_module.csv"),
          row.names = FALSE)

# hubs: top intramodular connectivity (kme) within significant modules
sig_mods <- trait_tab$module[trait_tab$FDR < 0.05]
hubs <- gene_tab %>% filter(module %in% sig_mods) %>%
  group_by(module) %>% arrange(desc(abs(kme)), .by_group = TRUE) %>%
  slice_head(n = 10) %>% ungroup()
write.csv(hubs, file.path(resdir, "GSE335924_WGCNA_hubs.csv"), row.names = FALSE)
cat("\nhub genes in ICH-associated modules:\n"); print(hubs, row.names = FALSE)
saveRDS(list(power = pow, sft = sft, labels = labels, MEs = me,
             gene_tab = gene_tab, trait_tab = trait_tab),
        file.path(resdir, "GSE335924_WGCNA.rds"))
cat("\nWGCNA done\n")
