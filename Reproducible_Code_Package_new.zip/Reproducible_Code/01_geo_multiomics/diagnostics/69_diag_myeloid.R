# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 诊断髓系 cluster：逐基因阳性率，区分中性粒 vs 单核
suppressPackageStartupMessages(library(Seurat))
sobj <- readRDS(file.path(PATHS$project, "02_results/GSE313043_seurat.rds"))
expr_data <- GetAssayData(sobj, layer = "data")
clusters <- sobj$seurat_clusters
mye_cl <- c("0","1","3","14","23","12","20","4","24")
genes <- c("FCGR3B","CSF3R","CXCR2","S100A12","S100A9","LCN2",
           "CD14","FCGR3A","VCAN","CTSS","CST3","S100A8")
out <- sapply(mye_cl, function(cl) {
  cells <- which(clusters == cl)
  sapply(genes, function(g) {
    if (!g %in% rownames(expr_data)) return(NA)
    mean(expr_data[g, cells] > 0)
  })
})
colnames(out) <- paste0("cl", mye_cl)
print(round(out, 2))
cat("\ncluster sizes:\n")
print(table(clusters)[mye_cl])
