# Reproducible Code Package

**Manuscript:** *Immunosuppressive myeloid reprogramming after intracerebral
hemorrhage: multi-omics mechanisms and a three-database target trial of early
venous thromboembolism prophylaxis*

**Authors:** Zhenglin Liu; corresponding author Jian Yin
(Department of Neurosurgery, The Second Affiliated Hospital of Dalian Medical
University)

This package contains the complete analysis code used to produce the figures,
tables and statistical estimates in the manuscript. Every hard-coded local
path has been removed and redirected to a single configuration file.

---

## 1. Directory layout

```
Reproducible_Code/
├── config_paths.R            # R path configuration (EDIT THIS)
├── config_paths.py           # Python path configuration (EDIT THIS)
├── run_all.R                 # master driver for the R analyses
├── 01_geo_multiomics/
│   ├── R/                    # GEO download, DEG, integration, WGCNA, single-cell,
│   │                         #   methylation, miRNA, figures
│   └── diagnostics/          # optional peek/diagnostic scripts
├── 02_clinical_target_trial/
│   └── R/                    # cohort construction, clone-censor-weight emulation,
│                             #   GCS strata, causal forest, sensitivity analyses
├── 03_immune_bridge/
│   ├── R/                    # longitudinal immune trajectories, ALBI, Figure 8
│   └── python/               # laboratory-record extraction (run before the R steps)
└── 04_manuscript/
    ├── python/               # Word document and cover-letter assembly
    └── powershell/           # Word -> PDF export
```

---

## 2. Data and how to obtain it

No raw data are bundled. The two classes of data differ in how you get them.

### 2.1 Public GEO data (nine accessions)

These are open and can be downloaded directly from NCBI GEO by running
`01_geo_multiomics/R/02_download_all.R` (internet connection required):

| Layer | Accessions |
|---|---|
| Bulk transcriptomics | GSE335924, GSE296792, GSE125512, GSE163256 |
| Single-cell | GSE266873, GSE166638, GSE313043 |
| DNA methylation (EPIC) | GSE179759 |
| miRNA | GSE43618; the miRNA arm of GSE296792 (shared with its bulk arm) |

### 2.2 Access-controlled critical-care databases

MIMIC-IV, eICU-CRD and the Northwestern ICU database are restricted and cannot
be redistributed. To access them you must create a free PhysioNet account,
complete the CITI "Data or Specimens Only Research" training, and sign the data
use agreement, then download from:

- MIMIC-IV v3.1 — https://physionet.org/content/mimiciv/3.1/
- eICU-CRD v2.0 — https://physionet.org/content/eicu-crd/2.0/
- Northwestern ICU v0.1.0 — https://physionet.org/content/northwestern-icu/0.1.0/
- MIMIC-IV Notes v2.2 — https://physionet.org/content/mimic-iv-note/2.2/

The derived analysis cohorts (e.g. `01_分析队列.csv`, `E1_分析队列.csv`,
`N1_分析队列.csv`) are produced from these source tables by the scripts in
`02_clinical_target_trial/R`.

---

## 3. Software environment

- **R 4.4.3** (the code was developed on Windows; forward slashes are used
  throughout so the scripts also run on macOS/Linux).
- **Python 3.14** with `pandas`, `numpy`, `python-docx` (1.2.0) and `pymupdf`.
- PowerShell is used only for the Word -> PDF export (Microsoft Word required
  for that step; the scientific analyses themselves do not depend on Word).

Key R packages (the authoritative list is the set of `library()` calls in the
scripts): `data.table`, `edgeR`, `limma`, `WGCNA`, `clusterProfiler`,
`msigdbr`, `GSVA`, `Seurat`, `glmnet`, `ranger`, `grf`, `policytree`, `tmle`,
`SuperLearner`, `ggplot2`, `cowplot`, plus the EPIC/minfi methylation tooling.
Install any missing package from CRAN or Bioconductor in the usual way.

---

## 4. Configuration

Open `config_paths.R` (and `config_paths.py` for the Python steps) and replace
each `"PLEASE_SET/..."` value with the folder on your machine. This is the only
file that needs editing; every analysis script reads its locations from the
`PATHS` object and loads it automatically.

---

## 5. Running the analyses

From the package root (the folder containing `config_paths.R`):

1. **GEO multi-omics** — download the public data, then run the R pipeline in
   numeric order. The whole sequence is wired up in `run_all.R`.
2. **Clinical target trial** — after configuring the access-controlled
   database paths, run the cohort and emulation scripts (section 2 of
   `run_all.R`).
3. **Immune bridge** — first run the two extractors in
   `03_immune_bridge/python`:
   ```
   python 03_immune_bridge/python/100_extract_labs.py
   python 03_immune_bridge/python/102_extract_eicu_labs.py
   ```
   then run the R steps in section 3 of `run_all.R`.
4. To execute everything in one pass:
   ```
   setwd(".../Reproducible_Code")
   source("run_all.R")
   ```

Scripts read and write intermediate files (derived cohorts, DEG tables,
figures) and therefore must be run in the listed order. Scripts in
`01_geo_multiomics/diagnostics` are optional inspection helpers and are not
part of the master driver.

---

## 6. Reproducibility notes and limitations

- Confidence intervals for the clinical emulation use subject-level cluster
  bootstrap; the immune-bridge trajectories use stabilized inverse-probability
  weights and hospital-cluster bootstrap, as described in the manuscript
  Methods.
- The clinical and multi-omics cohorts are separate populations with no
  individual-level linkage; the bridge analyses provide phenotype-level
  correspondence, not causal mediation. This is stated explicitly in the
  manuscript.
- Random number generation uses fixed seeds (`set.seed(2026)` in the R
  scripts), so results are reproducible up to platform-specific numerical
  differences.

---

## 7. Deterministic re-analysis (post-review correction)

The original emulation scripts called `cv.glmnet` without an explicit `foldid`,
so the cross-validation fold allocation depended on the global RNG state and
the archived point estimates could not be reproduced from a fresh R session.
The scripts in `02_clinical_target_trial/deterministic` fix this by wrapping
`cv.glmnet` with an internally generated, fixed `foldid` (stratified on the
outcome for rare-event specifications):

- `153_02b_deterministic.R` — MIMIC-IV 48-hour clone-censor-weight emulation;
  the deterministic in-hospital mortality risk difference is **-0.0418**
  (95% CI -0.0602 to -0.0242; RR 0.773), replacing the archived -0.0577.
  Two consecutive runs produce byte-identical output (sha256 verified).
- `155_nwicu_deterministic.R` — Northwestern ICU external validation; under the
  deterministic flow all IPCW estimates are null (48-hour in-hospital
  RD -0.0005, 95% CI -0.0079 to +0.0091; RR 0.998), while the augmented
  IP-weighted estimator remains protective (RD -0.1254, RR 0.542).
- `156_evalue.R` — E-value calculations for the corrected risk ratios.
- `158_fig1_rerun.R`, `159_forest_s4.R` — regeneration of Figure 1 and
  Supplementary Figure S4 from the deterministic outputs (300 dpi PNG plus
  vector PDF).

The supporting truncation-grid and fold-envelope diagnostics are in
`02_clinical_target_trial/diagnostics` (`150_sens_grid.R`, `152_envelope.R`,
`140_repro_test.R`, `141_figure_s1_final.R`, `142_forest_align.R`). The
envelope analysis (20 independent fold allocations) spans RD -0.0432 to
-0.0364, confirming the archived estimate lies outside the fold-allocation
distribution.
