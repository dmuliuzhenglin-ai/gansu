# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 20_enrich_gse335924.R
# Functional enrichment for GSE335924 DEGs (PBMC, ICH vs hypertension control)
# ORA on significant DEGs (up/down) + GSEA on the full ranked gene list
suppressPackageStartupMessages({
  library(clusterProfiler); library(org.Hs.eg.db); library(dplyr)
})
root <- PATHS$project
resdir <- file.path(root, "02_results"); figdir <- file.path(root, "03_figures")

deg <- read.csv(file.path(resdir, "GSE335924_DEG_all.csv"),
                stringsAsFactors = FALSE)
sig <- subset(deg, regulation %in% c("up", "down"))
cat("significant genes:", nrow(sig), "\n")

# map symbols -> Entrez (keep first match)
map <- bitr(sig$gene, fromType = "SYMBOL", toType = "ENTREZID",
            OrgDb = org.Hs.eg.db)
map <- map[!duplicated(map$SYMBOL), ]
sig <- merge(sig, map, by.x = "gene", by.y = "SYMBOL", all.x = TRUE)
up_e <- sig$ENTREZID[sig$regulation == "up" & !is.na(sig$ENTREZID)]
dn_e <- sig$ENTREZID[sig$regulation == "down" & !is.na(sig$ENTREZID)]

# ---- ORA: GO BP / CC / MF and KEGG ----
ora <- list()
for (ont in c("BP", "CC", "MF")) {
  for (set in c(up = "up", down = "down")) {
    genes <- if (set == "up") up_e else dn_e
    if (length(genes) < 5) next
    e <- enrichGO(gene = genes, OrgDb = org.Hs.eg.db, ont = ont,
                  readable = TRUE, pAdjustMethod = "BH",
                  pvalueCutoff = 0.05, qvalueCutoff = 0.2)
    if (!is.null(e) && nrow(as.data.frame(e)) > 0) {
      nm <- paste0("GO_", ont, "_", set)
      ora[[nm]] <- as.data.frame(e)
      cat(nm, "terms:", nrow(ora[[nm]]), "\n")
    }
  }
}
for (set in c(up = "up", down = "down")) {
  genes <- if (set == "up") up_e else dn_e
  if (length(genes) < 5) next
  k <- tryCatch(enrichKEGG(gene = genes, organism = "hsa",
                          pvalueCutoff = 0.05), error = function(e) e)
  if (!inherits(k, "error") && nrow(as.data.frame(k)) > 0) {
    nm <- paste0("KEGG_", set); ora[[nm]] <- as.data.frame(setReadable(k, org.Hs.eg.db, "ENTREZID"))
    cat(nm, "pathways:", nrow(ora[[nm]]), "\n")
  }
}
saveRDS(ora, file.path(resdir, "GSE335924_ORA.rds"))

# ---- GSEA: full list ranked by signed significance ----
full <- deg[!is.na(deg$gene), ]
fm <- bitr(full$gene, "SYMBOL", "ENTREZID", org.Hs.eg.db)
fm <- fm[!duplicated(fm$SYMBOL), ]
full <- merge(full, fm, by.x = "gene", by.y = "SYMBOL")
full <- full[!duplicated(full$ENTREZID), ]
ranks <- full$logFC; names(ranks) <- full$ENTREZID
ranks <- sort(ranks, decreasing = TRUE)
set.seed(1)
gsea_go <- gseGO(geneList = ranks, OrgDb = org.Hs.eg.db, ont = "BP",
                 eps = 0, seed = TRUE)
gsea_kegg <- tryCatch(gseKEGG(geneList = ranks, organism = "hsa", eps = 0,
                              seed = TRUE), error = function(e) e)
saveRDS(list(GO = as.data.frame(gsea_go),
             KEGG = if (!inherits(gsea_kegg, "error")) as.data.frame(gsea_kegg) else NULL),
        file.path(resdir, "GSE335924_GSEA.rds"))
cat("\nGSEA GO terms:", nrow(as.data.frame(gsea_go)), "\n")
cat("GSEA KEGG pathways:",
    if (!inherits(gsea_kegg, "error")) nrow(as.data.frame(gsea_kegg)) else 0, "\n")

# print top enriched terms for the report
cat("\n=== top GO BP (up) ===\n")
if ("GO_BP_up" %in% names(ora)) print(head(ora$GO_BP_up[, c("Description","p.adjust","Count")], 10), row.names=FALSE)
cat("\n=== top KEGG (up) ===\n")
if ("KEGG_up" %in% names(ora)) print(head(ora$KEGG_up[, c("Description","p.adjust","Count")], 10), row.names=FALSE)
cat("\nenrichment done\n")
