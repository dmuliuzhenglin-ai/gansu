# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 探查 GSE313043 HTO 结构
ex <- file.path(PATHS$project, "00_data/GSE313043/extracted")
cat("=== feature_ref (MixA P3_4) ===\n")
fr <- read.csv(gzfile(file.path(ex,
  "GSM9359709_Patient_3_4_Day_1_3_7_MixA_feature_ref.csv.gz")))
print(fr)
cat("\n=== tail of features.tsv (MixA; HTO rows at bottom) ===\n")
ft <- read.delim(gzfile(file.path(ex,
  "GSM9359708_Patient_3_4_Day_1_3_7_MixA_features.tsv.gz")), header = FALSE)
cat("features n:", nrow(ft), "\n"); print(tail(ft, 12))
cat("\n=== barcodes count MixA ===\n")
bc <- read.delim(gzfile(file.path(ex,
  "GSM9359708_Patient_3_4_Day_1_3_7_MixA_barcodes.tsv.gz")), header = FALSE)
cat("cells:", nrow(bc), "\n")
cat("\n=== plain GEX features (P2 Day1) ===\n")
ft2 <- read.delim(gzfile(file.path(ex,
  "GSM9359705_Patient_2_Day_1_features.tsv.gz")), header = FALSE)
cat("features n:", nrow(ft2), "\n"); print(tail(ft2, 3))
