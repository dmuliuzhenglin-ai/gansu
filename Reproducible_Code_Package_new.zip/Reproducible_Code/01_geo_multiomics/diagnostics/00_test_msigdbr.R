# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 测试 msigdbr 取 C8 细胞类型标志
Sys.setenv(http_proxy = "http://127.0.0.1:7897",
           https_proxy = "http://127.0.0.1:7897")
cat("msigdbr version:", as.character(packageVersion("msigdbr")), "\n")
suppressPackageStartupMessages(library(msigdbr))
# 查看可用集合（新版用 msigdbr_collections）
cols <- tryCatch(msigdbr_collections(), error = function(e) e)
print(cols)
c8 <- tryCatch(msigdbr(species = "Homo sapiens", category = "C8"),
               error = function(e) e)
if (!inherits(c8, "error")) {
  cat("\nC8 rows:", nrow(c8), "| gene sets:", length(unique(c8$gs_name)), "\n")
  print(head(unique(c8$gs_name), 12))
} else {
  cat("\nC8 fetch failed:", conditionMessage(c8), "\n")
}
