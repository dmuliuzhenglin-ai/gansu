# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 60_scrna_gse266873.R (v2)
# Single-cell analysis of peri-hematoma edematous tissue (GSE266873).
# v5 JoinLayers, corrected time parsing, cluster-level hierarchical marker
# annotation, and bulk hub-gene localisation.
suppressPackageStartupMessages({
  library(Seurat); library(harmony); library(dplyr)
})
options(future.globals.maxSize = 8 * 1024^3)
root <- PATHS$project
exdir <- file.path(root, "00_data/GSE266873/extracted")
resdir <- file.path(root, "02_results")

bc_files <- list.files(exdir, pattern = "barcodes.tsv.gz$")
objs <- list()
for (bc in bc_files) {
  base <- sub("_barcodes.tsv.gz$", "", bc)
  mtx <- ReadMtx(mtx = file.path(exdir, paste0(base, "_matrix.mtx.gz")),
                 features = file.path(exdir, paste0(base, "_features.tsv.gz")),
                 cells = file.path(exdir, bc), feature.column = 2)
  s <- CreateSeuratObject(mtx, project = base, min.cells = 3, min.features = 200)
  parts <- strsplit(base, "_")[[1]]
  s$gsm <- parts[1]; s$patient <- sub("sample", "patient", parts[2])
  s$draw <- parts[3]; s$timepoint <- parts[5]
  s$time_h <- as.numeric(sub("h", "", parts[5]))
  s$phase <- ifelse(s$time_h <= 12, "early_<=12h", "late_>12h")
  objs[[base]] <- s
}
sobj <- merge(objs[[1]], objs[-1])
sobj <- JoinLayers(sobj)                       # v5: merge RNA layers
sobj[["percent_mt"]] <- PercentageFeatureSet(sobj, pattern = "^MT-")
cat("cells before QC:", ncol(sobj), "\n")
sobj <- subset(sobj, subset = nFeature_RNA > 200 & nFeature_RNA < 8000 &
                 percent_mt < 20)
cat("cells after QC:", ncol(sobj), "\n")

sobj <- NormalizeData(sobj, verbose = FALSE)
sobj <- FindVariableFeatures(sobj, nfeatures = 2000, verbose = FALSE)
sobj <- ScaleData(sobj, verbose = FALSE)
sobj <- RunPCA(sobj, npcs = 30, verbose = FALSE)
sobj <- RunHarmony(sobj, group.by.vars = "patient", verbose = FALSE)
sobj <- RunUMAP(sobj, reduction = "harmony", dims = 1:20, verbose = FALSE)
sobj <- FindNeighbors(sobj, reduction = "harmony", dims = 1:20, verbose = FALSE)
sobj <- FindClusters(sobj, resolution = 0.6, verbose = FALSE)

# ---- cluster-level hierarchical annotation via marker-positive fraction ----
expr_data <- GetAssayData(sobj, layer = "data")
clusters <- sobj$seurat_clusters
clv <- levels(clusters)
posfrac <- function(genes) {
  genes <- intersect(genes, rownames(expr_data))
  sapply(clv, function(cl) {
    cells <- which(clusters == cl)
    mean(colSums(expr_data[genes, cells, drop = FALSE] > 0) > 0)
  })
}
pf <- list(
  astro = posfrac(c("GFAP","AQP4","SLC1A2","ALDH1L1")),
  endo  = posfrac(c("PECAM1","CLDN5","VWF","KDR")),
  mic   = posfrac(c("P2RY12","TMEM119","CX3CR1")),
  neut  = posfrac(c("FCGR3B","CSF3R","CXCR2","S100A12")),
  macc  = posfrac(c("CD14","C1QA","C1QB","CD68","APOE","FCGR3A")),
  tcell = posfrac(c("CD3D","CD3E","TRAC")),
  bcell = posfrac(c("CD79A","CD79B","MS4A1")),
  nk    = posfrac(c("GNLY","NKG7","KLRD1","KLRF1")))
pf <- as.data.frame(pf); rownames(pf) <- clv
print(round(pf, 2))
annotate <- function(r) {
  if (r["astro"] >= 0.5) return("astrocytes")
  if (r["endo"]  >= 0.5) return("endothelial")
  if (r["mic"]   >= 0.4) return("microglia")
  if (r["neut"]  >= 0.5) return("neutrophils")
  if (r["macc"]  >= 0.5) return("monocytes_macrophages")
  if (r["tcell"] >= 0.5) return("T_cells")
  if (r["bcell"] >= 0.5) return("B_cells")
  if (r["nk"]    >= 0.5 && r["tcell"] < 0.3) return("NK_cells")
  "unassigned"
}
cl_annot <- apply(pf, 1, annotate)
sobj$cell_type <- unname(cl_annot[as.character(clusters)])
cat("\ncell type counts:\n"); print(table(sobj$cell_type))

Idents(sobj) <- "cell_type"
mk <- FindAllMarkers(sobj, only.pos = TRUE, min.pct = 0.25,
                     logfc.threshold = 0.5, verbose = FALSE)
write.csv(mk, file.path(resdir, "GSE266873_celltype_markers.csv"),
          row.names = FALSE)

# ---- bulk hub-gene localisation ----
lists <- readRDS(file.path(resdir, "consensus_gene_lists.rds"))
w <- readRDS(file.path(resdir, "GSE335924_WGCNA.rds"))
hub_cand <- unique(c(head(lists$cs_up, 60), head(lists$cs_dn, 30),
                     head(w$gene_tab$gene[w$gene_tab$module == 1], 20)))
hub_cand <- intersect(hub_cand, rownames(sobj))
avg <- AverageExpression(sobj, features = hub_cand, group.by = "cell_type",
                         assay = "RNA")[[1]]
write.csv(as.data.frame(avg), file.path(resdir, "GSE266873_hub_localisation.csv"))
pct <- sapply(unique(sobj$cell_type), function(ct) {
  cells <- which(sobj$cell_type == ct)
  rowMeans(expr_data[hub_cand, cells, drop = FALSE] > 0)
})
write.csv(as.data.frame(pct), file.path(resdir,
          "GSE266873_hub_pct_expressing.csv"))
comp <- as.data.frame(prop.table(table(sobj$phase, sobj$cell_type), margin = 1))
write.csv(comp, file.path(resdir, "GSE266873_composition_phase.csv"),
          row.names = FALSE)
saveRDS(sobj, file.path(resdir, "GSE266873_seurat.rds"))
cat("\nhub genes localised:", paste(hub_cand, collapse = ", "), "\n")
cat("GSE266873 single-cell done\n")
