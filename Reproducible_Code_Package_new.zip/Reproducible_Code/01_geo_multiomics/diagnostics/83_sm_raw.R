# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 查看 series matrix 原始表达表行 ID
f <- file.path(PATHS$project, "00_data/GSE43618/GSE43618_series_matrix.txt.gz")
con <- gzfile(f); lines <- readLines(con); close(con)
tb_start <- grep("!series_matrix_table_begin", lines)
cat("table begins at line", tb_start, "\n")
print(lines[tb_start:(tb_start + 6)])
# 平台 ID 列相关注释
cat("\nplatform annotation lines:\n")
print(grep("!platform", lines, value = TRUE))
