# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 02_download_all.R - 正式下载全部数据文件
# 规则：甲基化跳过 888MB IDAT 原始包（用 processed matrix）；
# 单细胞 RAW.tar 必须下载；其余 suppl 全量下载
source(file.path(PATHS$project, "01_code/00_geo_utils.R"))
data_root <- file.path(PATHS$project, "00_data")

plan <- list(
  GSE125512 = NULL,                              # 全量（仅 1 个 xls.gz）
  GSE296792 = NULL,                              # 2 个 counts CSV
  GSE166638 = NULL,                              # 先全量小文件，RAW.tar 单独处理
  GSE163256 = NULL,                              # 6 个 CSV
  GSE335924 = NULL,                              # expression.xlsx
  GSE313043 = NULL,                              # 单细胞 tar + filelist
  GSE266873 = NULL,                              # 单细胞 tar + filelist
  GSE179759 = "GSE179759_RAW\\.tar",             # 排除 888MB IDAT tar
  GSE43618  = NULL                               # 无 suppl
)

for (gse in names(plan)) {
  cat("\n=================", gse, "=================\n")
  ddir <- file.path(data_root, gse)
  dir.create(ddir, recursive = TRUE, showWarnings = FALSE)
  base <- gse_dir_url(gse)
  sfiles <- tryCatch(geo_dir_list(paste0(base, "/suppl")),
                     error = function(e) character(0))
  if (!is.null(plan[[gse]])) {
    sfiles <- sfiles[!grepl(plan[[gse]], sfiles)]
  }
  if (length(sfiles) == 0) {
    cat("no suppl to download (data may live in series matrix)\n")
    next
  }
  for (sf in sfiles) {
    lf <- file.path(ddir, sf)
    if (file.exists(lf) && file.info(lf)$size > 0) {
      cat("skip (exists):", sf, "\n"); next
    }
    t0 <- Sys.time()
    tryCatch({
      curl_download(paste0(base, "/suppl/", sf), lf)
      cat("OK:", sf, round(file.info(lf)$size / 1e6, 1), "MB in",
          round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1), "s\n")
    }, error = function(e) cat("FAIL:", sf, "->", e$message, "\n"))
  }
}

# 校验：列出所有本地文件与大小
cat("\n===== local inventory =====\n")
fl <- list.files(data_root, recursive = TRUE, full.names = TRUE)
for (f in fl) cat(round(file.info(f)$size / 1e6, 2), "MB\t", f, "\n")
cat("\ntotal files:", length(fl), "\n")
