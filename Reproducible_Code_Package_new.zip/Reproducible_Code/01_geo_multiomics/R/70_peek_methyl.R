# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 探查 GSE179759 甲基化数据格式
root <- PATHS$project
dr <- file.path(root, "00_data/GSE179759")

# series matrix grouping
es <- GEOquery::getGEO(filename = file.path(dr, "GSE179759_series_matrix.txt.gz"),
                       getGPL = FALSE)
pd <- Biobase::pData(es)
cat("samples:", nrow(pd), "\n"); cat("columns:\n"); print(colnames(pd))
for (f in grep("character|source|title", colnames(pd), value = TRUE)) {
  cat("\n", f, ":\n", sep = ""); print(head(pd[[f]], 8))
}

# processed matrix head
matf <- gzfile(file.path(dr, "GSE179759_Matrix_processed.csv.gz"))
mat <- read.csv(matf, nrows = 5, check.names = FALSE)
cat("\nprocessed matrix first rows:\n"); print(dim(mat))
print(mat[, 1:min(6, ncol(mat))])
