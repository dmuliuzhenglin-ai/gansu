# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 03_peek_formats.R - 已下载文件格式探查（轻量，只读前几行）
data_root <- file.path(PATHS$project, "00_data")

peek_csv_gz <- function(p, n = 3) {
  cat("---", p, "---\n")
  df <- read.csv(gzfile(p), nrows = n, check.names = FALSE)
  cat("cols:", ncol(df), "\n")
  print(names(df)[1:min(8, ncol(df))])
  print(df[1:min(2, nrow(df)), 1:min(5, ncol(df))])
  cat("\n")
}

# GSE296792
peek_csv_gz(file.path(data_root, "GSE296792/GSE296792_Normalized_mRNA_counts_v1.csv.gz"))
peek_csv_gz(file.path(data_root, "GSE296792/GSE296792_Normalized_miRNA_counts_v1.csv.gz"))

# GSE163256
peek_csv_gz(file.path(data_root, "GSE163256/GSE163256_monos_counts.csv.gz"))
peek_csv_gz(file.path(data_root, "GSE163256/GSE163256_neuts_counts.csv.gz"))

# GSE125512 差异结果表
p <- file.path(data_root, "GSE125512/GSE125512_SecondSample_vs_FirstSample.all.gene.result.xls.gz")
cat("---", p, "---\n")
d12 <- read.csv(gzfile(p), nrows = 5, sep = "\t", check.names = FALSE)
cat("cols:\n"); print(names(d12))
print(head(d12, 3))
