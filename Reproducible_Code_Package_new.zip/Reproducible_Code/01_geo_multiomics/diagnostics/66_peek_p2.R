# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# Patient 2 治疗分组（GPL20301 series matrix）
dd <- file.path(PATHS$project, "00_data/GSE313043")
sm <- readLines(gzfile(file.path(dd, "GSE313043-GPL20301_series_matrix.txt.gz")))
cat("lines:", length(sm), "\n")
cat(grep("Sample_title|Sample_geo|treatment|cell type|source_name", sm,
         value = TRUE), sep = "\n")
