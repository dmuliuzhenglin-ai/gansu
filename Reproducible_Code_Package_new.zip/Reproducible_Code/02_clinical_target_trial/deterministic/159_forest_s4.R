# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R",
                "../../../config_paths.R", "../../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 159_forest_s4.R
# Regenerate Figure S4 (estimator forest) on the deterministic pipeline:
# MIMIC 02b -> _02b_det/run1; NWICU -> _nwicu_det/run1; eICU, ATO, E6 unchanged.
suppressPackageStartupMessages({library(data.table); library(ggplot2)})
clin <- PATHS$clinical
root <- PATHS$project
figdir <- file.path(root, "03_figures")
G0 <- 48

rows <- list()
add <- function(db, est, rd, lo = NA_real_, hi = NA_real_)
  rows[[length(rows) + 1]] <<- data.table(db = db, est = est, rd = rd, lo = lo, hi = hi)

m <- fread(file.path(root, "02_results/_02b_det/run1/02b_结果汇总.csv"))
m48 <- m[grace_h == G0 & outcome == "hosp_mort"]
r <- m48[method == "IPCW"]; add("MIMIC-IV", "IPCW-HT", r$RD*100, r$RD_lo*100, r$RD_hi*100)
r <- m48[method == "AIPW"]; add("MIMIC-IV", "AIPW", r$RD*100, r$RD_lo*100, r$RD_hi*100)

e2 <- fread(file.path(clin, "E2_结果汇总.csv"))
r <- e2[G == G0 & grepl("院内", spec) & est == "IPCW-HT"]
add("eICU-CRD", "IPCW-HT", r$rd_pp[1], r$rd_lo[1], r$rd_hi[1])

e2d <- fread(file.path(clin, "E2d_结果汇总.csv"))
r <- e2d[G == G0 & grepl("院内", spec) & grepl("AIPW", est)]
add("eICU-CRD", "AIPW-DR", r$rd_pp[1], r$rd_lo[1], r$rd_hi[1])

n2 <- fread(file.path(root, "02_results/_nwicu_det/run1/N2_结果汇总.csv"))
n48 <- n2[G == G0 & outcome == "hosp_mort" & grepl("主分析", label)]
r <- n48[1]
add("NWICU", "IPCW-HT", r$ipcw_RD*100, r$ipcw_RD_lo*100, r$ipcw_RD_hi*100)
add("NWICU", "AIPW", r$aipw_RD*100, r$aipw_RD_lo*100, r$aipw_RD_hi*100)

e4 <- fread(file.path(clin, "E4_ATO结果.csv"))
hit <- grepl("NW", toupper(e4[[1]]))
gc <- names(e4)[tolower(names(e4)) %in% c("g", "grace", "grace_h")][1]
if (!is.na(gc)) hit <- hit & e4[[gc]] == G0
if (any(hit)) {
  r <- e4[hit][1]
  rdc <- names(e4)[grepl("^rd", tolower(names(e4)))][1]
  add("NWICU", "ATO (overlap)", as.numeric(r[[rdc]]))
}

e6 <- fread(file.path(clin, "E6_可迁移性结果.csv"))
r <- e6[db == "NWICU" & grepl("标准", type)]
add("NWICU", "standardized to MIMIC-IV", r$rd, r$lo, r$hi)

pd <- rbindlist(rows)
pd[, lab := factor(paste0(db, "  ", est), levels = rev(paste0(db, "  ", est)))]
pd[, ci_txt := fifelse(is.na(lo), sprintf("%+.1f", rd),
                       sprintf("%+.1f (%+.1f, %+.1f)", rd, lo, hi))]
print(pd[, .(lab, rd, lo, hi)])

xr <- range(c(pd$lo, pd$hi), na.rm = TRUE)
x_pad <- max(abs(xr)) * 1.15
g <- ggplot(pd, aes(y = lab, x = rd)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey60") +
  geom_errorbar(aes(xmin = lo, xmax = hi, orientation = "y"),
                width = 0.18, color = "#2C5F8A", na.rm = TRUE) +
  geom_point(size = 2.8, color = "#2C5F8A") +
  geom_text(aes(x = x_pad * 0.62, label = ci_txt), hjust = 0, size = 3.2) +
  coord_cartesian(xlim = c(-x_pad, x_pad * 0.62), clip = "off") +
  labs(x = "Risk difference for in-hospital mortality, percentage points (95% CI)\nearly vs delayed prophylaxis, 48-h grace period",
       y = NULL) +
  theme_classic(base_size = 11) +
  theme(plot.margin = margin(6, 100, 6, 6))
ggsave(file.path(figdir, "FigureS4_forest.png"), g,
       width = 8.5, height = 5, dpi = 300)
ggsave(file.path(figdir, "FigureS4_forest.pdf"), g,
       width = 8.5, height = 5, device = cairo_pdf)
cat("done\n")
