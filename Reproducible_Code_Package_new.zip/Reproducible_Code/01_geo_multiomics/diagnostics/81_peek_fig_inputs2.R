# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 探查甲基化支持对、ORA家族、hub定位、DEG长表结构
r <- file.path(PATHS$project, "02_results")
ora <- read.csv(file.path(r, "consensus_ORA.csv"), check.names = FALSE)
cat("=== ORA set categories ===\n"); print(table(ora$set))

cat("\n=== methylation-expression supported links ===\n")
ml <- read.csv(file.path(r, "methyl_expression_link.csv"), check.names = FALSE)
print(ml[!is.na(ml$link_type), ])

cat("\n=== DEG long structure ===\n")
cl <- read.csv(file.path(r, "cross_DEG_long.csv"), check.names = FALSE)
cat("dim:", dim(cl), "\n"); print(head(cl, 3))
cat("units:\n"); print(table(cl$unit))

cat("\n=== GSE266873 hub pct (key) ===\n")
h1 <- read.csv(file.path(r, "GSE266873_hub_pct_expressing.csv"),
               check.names = FALSE, row.names = 1)
print(round(h1[intersect(c("IL1R2","FCGR3B","CXCL8","ACSL1","CD74","HLA-DRA",
  "ALOX5AP","ADM","UPP1","FCER1G","KCNJ15"), rownames(h1)), ], 2))

cat("\n=== GSE166638 hub pct (key) ===\n")
h2 <- read.csv(file.path(r, "GSE166638_hub_pct_expressing.csv"),
               check.names = FALSE, row.names = 1)
print(round(h2[intersect(c("ACSL1","ADM","ALOX5AP","UPP1","FKBP5","IL1R2"),
  rownames(h2)), ], 2))
