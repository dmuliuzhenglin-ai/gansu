# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E4 - 重叠权重 (Overlap Weights, ATO 估计量) 三库敏感性分析
# 目标人群: 临床 equipoise 人群 (ps 接近 0.5 者权重最大)
# w_ow = (1-ps) 处理组; ps 对照组  -> 天然规避 positivity 问题
# 在 kept 克隆框架内估计: 与 E2d 相同的共享事件处理
# 用法: source(file.path(PATHS$clinical, "步骤E4-重叠权重.R"), encoding="UTF-8")
# ============================================================

library(data.table)
options(error = NULL); set.seed(2026)
dir_out <- PATHS$clinical
B <- 300

xvars <- c("age","female","gcs","mech_vent","neurosx","sbp","hr",
           "platelet","hemoglobin","creatinine","glucose",
           "hypertension","diabetes","ckd","heart_failure","malignancy","liver",
           "prior_vte","prior_stroke")

ato_one <- function(dt, G, label) {
  n <- nrow(dt)
  cl <- rbind(copy(dt)[, arm := 1L], copy(dt)[, arm := 0L])
  cl[, t_div := pmin(first_px_hrs, G, na.rm = FALSE)]
  cl[is.na(first_px_hrs), t_div := G]
  cl[, ev_before_div := as.integer(hosp_mort == 1 & death_hrs <= t_div)]
  cl[, adherent := as.integer((arm == 1 & !is.na(first_px_hrs) & first_px_hrs <= G) |
                                (arm == 0 & (is.na(first_px_hrs) | first_px_hrs > G)))]
  cl[, Y := hosp_mort]
  s <- sum(cl$ev_before_div[cl$arm == 1])
  cl2 <- cl[ev_before_div == 0]
  n_at <- n - s
  
  # 依从性模型 (各臂"服从该策略"的倾向) — ATO 施加在依从性倾向分数上
  use <- intersect(xvars, names(cl2))
  f <- reformulate(c("factor(arm)", use), response = "adherent")
  m <- suppressWarnings(glm(f, data = cl2, family = binomial))
  pc <- pmin(pmax(predict(m, newdata = cl2, type = "response"), 1e-3), 1 - 1e-3)
  # 重叠权重: 依从者 w=1-pc, 非依从删失方向 w=pc
  w_ow <- fifelse(cl2$adherent == 1, 1 - pc, pc)
  # 在 ATO 权重下估计各臂风险: 加权均值 (依从克隆)
  r1s <- sum(w_ow * (cl2$arm == 1) * (cl2$adherent == 1) * cl2$Y) /
    sum(w_ow * (cl2$arm == 1) * (cl2$adherent == 1))
  r0s <- sum(w_ow * (cl2$arm == 0) * (cl2$adherent == 1) * cl2$Y) /
    sum(w_ow * (cl2$arm == 0) * (cl2$adherent == 1))
  r1 <- s/n + (n_at/n)*r1s; r0 <- s/n + (n_at/n)*r0s
  # bootstrap (按 subject)
  subj <- dt$subject_id; uids <- unique(subj)
  boot <- replicate(B, {
    bs <- sample(uids, length(uids), TRUE)
    db <- dt[subject_id %in% bs]
    nb <- nrow(db)
    cb <- rbind(copy(db)[, arm := 1L], copy(db)[, arm := 0L])
    cb[, t_div := pmin(first_px_hrs, G, na.rm = FALSE)]
    cb[is.na(first_px_hrs), t_div := G]
    cb[, evb := as.integer(hosp_mort == 1 & death_hrs <= t_div)]
    cb[, adh := as.integer((arm == 1 & !is.na(first_px_hrs) & first_px_hrs <= G) |
                             (arm == 0 & (is.na(first_px_hrs) | first_px_hrs > G)))]
    sb <- sum(cb$evb[cb$arm == 1]); cb2 <- cb[evb == 0]; nb_at <- nb - sb
    mb <- tryCatch(suppressWarnings(glm(reformulate(c("factor(arm)", use), response = "adh"),
                                        data = cb2, family = binomial)), error = function(e) NULL)
    if (is.null(mb)) return(NA_real_)
    pcb <- pmin(pmax(predict(mb, newdata = cb2, type = "response"), 1e-3), 1-1e-3)
    wb <- ifelse(cb2$adh == 1, 1 - pcb, pcb)
    r1b <- sum(wb*(cb2$arm==1)*(cb2$adh==1)*cb2$hosp_mort)/sum(wb*(cb2$arm==1)*(cb2$adh==1))
    r0b <- sum(wb*(cb2$arm==0)*(cb2$adh==1)*cb2$hosp_mort)/sum(wb*(cb2$arm==0)*(cb2$adh==1))
    (sb/nb + (nb_at/nb)*r1b) - (sb/nb + (nb_at/nb)*r0b)
  })
  ci <- quantile(boot, c(.025,.975), na.rm = TRUE)
  cat(sprintf("%s G%d: ATO RD = %+.2fpp (%+.2f, %+.2f)  RR %.3f\n",
              label, G, 100*(r1-r0), 100*ci[1], 100*ci[2], r1/r0))
  data.table(db = label, G = G, est = "ATO-overlap",
             rd_pp = round(100*(r1-r0), 2), rd_lo = round(100*ci[1], 2), rd_hi = round(100*ci[2], 2),
             rr = round(r1/r0, 3))
}

prep <- function(path) {
  dt <- fread(path)
  if ("gender" %in% names(dt) && !"female" %in% names(dt))
    dt[, female := as.integer(gender == "Female")]
  if (!"death_hrs" %in% names(dt)) {
    if ("hospitaldischargeoffset" %in% names(dt))
      dt[, death_hrs := fifelse(hosp_mort == 1, as.numeric(hospitaldischargeoffset)/60, Inf)]
  }
  for (v in intersect(xvars, names(dt)))
    if (any(is.na(dt[[v]]))) dt[is.na(get(v)), (v) := median(dt[[v]], na.rm = TRUE)]
  dt
}

res <- list()
res[["eICU48"]]  <- ato_one(prep(file.path(dir_out, "E1_分析队列.csv")), 48, "eICU")
res[["eICU24"]]  <- ato_one(prep(file.path(dir_out, "E1_分析队列.csv")), 24, "eICU")
res[["eICU72"]]  <- ato_one(prep(file.path(dir_out, "E1_分析队列.csv")), 72, "eICU")
nw_file <- file.path(dir_out, "N1_分析队列.csv")
if (file.exists(nw_file)) {
  d_nw <- prep(nw_file)
  res[["NWICU48"]] <- ato_one(d_nw, 48, "NWICU")
  res[["NWICU24"]] <- ato_one(d_nw, 24, "NWICU")
  res[["NWICU72"]] <- ato_one(d_nw, 72, "NWICU")
}
res_all <- rbindlist(res)
print(res_all)
fwrite(res_all, file.path(dir_out, "E4_ATO结果.csv"))
cat("/n完成 -> [clinical output directory]/E4_ATO结果.csv/n")
cat("解读: ATO 估计 equipoise 人群效应, 应与 IPCW-HT/AIPW 方向量级相近; 差异大提示效应集中于极端倾向人群\n")

