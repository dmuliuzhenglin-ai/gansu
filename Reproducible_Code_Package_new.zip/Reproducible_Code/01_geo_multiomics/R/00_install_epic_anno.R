# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 安装 EPIC 甲基化探针注释包
Sys.setenv(http_proxy = "http://127.0.0.1:7897",
           https_proxy = "http://127.0.0.1:7897")
options(repos = c(CRAN = "https://cloud.r-project.org"))
BiocManager::install("IlluminaHumanMethylationEPICanno.ilm10b4.hg19",
                     ask = FALSE, update = FALSE, quiet = FALSE)
cat("\ninstalled:",
    requireNamespace("IlluminaHumanMethylationEPICanno.ilm10b4.hg19",
                      quietly = TRUE), "\n")
