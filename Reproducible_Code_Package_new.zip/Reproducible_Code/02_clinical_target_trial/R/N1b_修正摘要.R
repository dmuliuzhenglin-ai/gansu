# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# NWICU 步骤1b：修正补丁（直接覆盖 N1_分析队列.csv）
# 修正1：emar的event_txt取值与MIMIC不同 → 先探查实际取值再过滤
# 修正2：机械通气/神外会诊是医嘱类条目 → 从procedureevents表提取
# 修正3：hospital_expire_flag不可靠 → hosp_mort改用deathtime非空判定
# 输入：[clinical output directory]/N1_分析队列.csv + NWICU原始表
# 输出：覆盖保存 N1_分析队列.csv + N1b_修正摘要.txt
# ================================================================

rm(list = ls())
suppressMessages(library(data.table))

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "N1b_修正摘要.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

rd <- function(rel, ...) fread(file.path(dir_nwicu, rel), ...)
cohort <- fread(file.path(dir_out, "N1_分析队列.csv"))
cohort[, intime := as.POSIXct(intime)]
cat("载入队列：", nrow(cohort), "stay\n\n")

# ----------------------------------------------------------------
# 修正1：暴露（先看event_txt实际取值，再计数）
# ----------------------------------------------------------------
cat("== 修正1：暴露（emar） ==\n")
emar <- rd("data/nw_hosp/emar.csv.gz")
emar[, charttime := as.POSIXct(charttime)]
hep_all <- emar[grepl("HEPARIN|ENOXAPARIN", medication, ignore.case = TRUE)]
cat("event_txt 取值分布（全部肝素/依诺肝素记录）：\n")
print(hep_all[, .N, by = event_txt][order(-N)])

# 预防剂量：肝素5000U注射剂 / 依诺肝素30-40mg；不排除任何event_txt（给药记录即证据）
proph <- hep_all[
  (grepl("HEPARIN.*5000", medication, ignore.case = TRUE) &
     !grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("30 MG|40 MG", medication, ignore.case = TRUE))
]
cat("预防剂量给药记录（不过滤event_txt）：", nrow(proph), "\n")
px <- merge(proph[, .(hadm_id, charttime)],
            cohort[, .(stay_id, hadm_id, intime)], by = "hadm_id")
px[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
first_px <- px[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
cohort[, first_px_hrs := NULL]
cohort <- merge(cohort, first_px, by = "stay_id", all.x = TRUE, sort = FALSE)
cat("有预防抗凝的 stay：", sum(!is.na(cohort$first_px_hrs)), "/", nrow(cohort),
    "；48h内：", sum(cohort$first_px_hrs <= 48, na.rm = TRUE),
    "；72h内：", sum(cohort$first_px_hrs <= 72, na.rm = TRUE), "\n")

# 治疗剂量排除（同步改为不过滤event_txt）
therap <- hep_all[
  (grepl("HEPARIN", medication, ignore.case = TRUE) &
     grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("80 MG|100 MG|120 MG|150 MG", medication, ignore.case = TRUE))
]
iv_hadms <- unique(therap$hadm_id)
n0 <- nrow(cohort)
cohort <- cohort[!hadm_id %in% iv_hadms]
cat("排除治疗剂量抗凝：", n0 - nrow(cohort), "；剩余", nrow(cohort), "\n\n")

# ----------------------------------------------------------------
# 修正2：机械通气/神外会诊（procedureevents）
# ----------------------------------------------------------------
cat("== 修正2：机械通气与神外会诊 ==\n")
items <- rd("data/nw_icu/d_items.csv.gz")
vent_ids <- items[grepl("INTUBATION|MECHANICAL VENTILATION|NON-INVASIVE VENTILATION",
                        label, ignore.case = TRUE)]$itemid
nsx_ids  <- items[grepl("NEUROSURG", label, ignore.case = TRUE)]$itemid
proc <- rd("data/nw_icu/procedureevents.csv.gz")
cat("procedureevents 列名：", paste(names(proc), collapse = ", "), "\n")
proc_id <- intersect(c("stay_id", "hadm_id"), names(proc))[1]
cohort[, mech_vent := get(proc_id) %in% proc[itemid %in% vent_ids][[proc_id]]]
cohort[, neurosx   := get(proc_id) %in% proc[itemid %in% nsx_ids][[proc_id]]]
# 若procedureevents仍无覆盖，回退到chartevents再试一次
if (sum(cohort$mech_vent) == 0) {
  ch <- rd("data/nw_icu/chartevents.csv.gz", select = c("stay_id", "itemid"))
  cohort[, mech_vent := stay_id %in% ch[itemid %in% vent_ids]$stay_id]
  cohort[, neurosx   := stay_id %in% ch[itemid %in% nsx_ids]$stay_id]
  cat("（回退到chartevents提取）\n")
}
cat("机械通气：", sum(cohort$mech_vent), sprintf("(%.1f%%)", 100*mean(cohort$mech_vent)),
    "；神外会诊/介入：", sum(cohort$neurosx), sprintf("(%.1f%%)\n", 100*mean(cohort$neurosx)))

# ----------------------------------------------------------------
# 修正3：院内死亡改用deathtime
# ----------------------------------------------------------------
cat("\n== 修正3：院内死亡 ==\n")
cohort[, hosp_mort := as.integer(!is.na(death_hrs))]
cat("院内死亡：", sum(cohort$hosp_mort == 1), sprintf("(%.1f%%)\n",
                                                 100 * mean(cohort$hosp_mort)))
cat("90天死亡：", sum(cohort$mort90 == 1), sprintf("(%.1f%%)\n",
                                               100 * mean(cohort$mort90)))

# ----------------------------------------------------------------
# 保存
# ----------------------------------------------------------------
fwrite(cohort, file.path(dir_out, "N1_分析队列.csv"))
cat("\n修正后队列：", nrow(cohort), " stay\n")
cat("暴露汇总：48h内早期预防", sum(cohort$first_px_hrs <= 48, na.rm = TRUE),
    "例；未早期预防", sum(is.na(cohort$first_px_hrs) | cohort$first_px_hrs > 48), "例\n")
cat("已覆盖保存：", file.path(dir_out, "N1_分析队列.csv"), "\n")
sink()
cat("完成，请上传 N1b_修正摘要.txt\n")

