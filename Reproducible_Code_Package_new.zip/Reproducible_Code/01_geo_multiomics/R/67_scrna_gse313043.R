# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 67_scrna_gse313043.R
# Full HTO demultiplexing of multiplexed PBMC CITE-seq (GSE313043), plus plain
# GEX wells. Each Mix well is demultiplexed with its feature_ref mapping;
# "None" tags and Negative/Doublet cells are removed. All singlets are merged,
# QC'd, integrated by patient, annotated, and compared across treatment and day.
suppressPackageStartupMessages({
  library(Seurat); library(harmony); library(dplyr)
})
options(future.globals.maxSize = 20 * 1024^3)
root <- PATHS$project
ex <- file.path(root, "00_data/GSE313043/extracted")
resdir <- file.path(root, "02_results")

treatment_map <- c("2" = "BAF312", "3" = "BAF312", "4" = "BAF312",
                   "5" = "Placebo", "6" = "Placebo", "7" = "BAF312",
                   "8" = "BAF312")

# GEX well prefixes (defined by barcodes files); feature_ref files excluded
bc_files <- list.files(ex, pattern = "barcodes.tsv.gz$")
prefixes <- sub("_barcodes.tsv.gz$", "", bc_files)

dedupe_rows <- function(mat) {
  rn <- rownames(mat)
  if (!any(duplicated(rn))) return(mat)
  totals <- Matrix::rowSums(mat)
  ord <- order(-totals)
  keep <- sort(ord[!duplicated(rn[ord])])
  mat[keep, , drop = FALSE]
}

objs <- list()
demux_stats <- list()
for (pfx in prefixes) {
  is_mix <- grepl("Mix", pfx)
  lane <- if (is_mix) sub(".*_(Mix[A-C])$", "\\1", pfx) else "plain"
  full <- ReadMtx(mtx = file.path(ex, paste0(pfx, "_matrix.mtx.gz")),
                  features = file.path(ex, paste0(pfx, "_features.tsv.gz")),
                  cells = file.path(ex, paste0(pfx, "_barcodes.tsv.gz")),
                  feature.column = 2)
  if (is_mix) {
    feat_tab <- read.delim(gzfile(file.path(ex, paste0(pfx,
      "_features.tsv.gz"))), header = FALSE)
    gex_names <- feat_tab$V2[feat_tab$V3 == "Gene Expression"]
    hto_names <- feat_tab$V2[feat_tab$V3 == "Antibody Capture"]
    gex <- dedupe_rows(full[gex_names, , drop = FALSE])
    hto_all <- full[hto_names, , drop = FALSE]
    # feature_ref shares the well label (without GSM) but has its own GSM id
    well_id <- sub("^GSM[0-9]+_", "", pfx)
    fr_file <- list.files(ex, pattern = paste0(well_id, "_feature_ref"),
                          full.names = TRUE)
    fr <- read.csv(gzfile(fr_file))
    valid <- fr[fr$multiplexed_sample != "None", c("id", "multiplexed_sample")]
    rownames(valid) <- valid$id
    hto <- hto_all[valid$id, , drop = FALSE]
    common <- intersect(colnames(gex), colnames(hto))
    gex <- gex[, common, drop = FALSE]; hto <- hto[, common, drop = FALSE]
    s <- CreateSeuratObject(gex, min.features = 0)
    s[["HTO"]] <- CreateAssay5Object(counts = hto)
    s <- NormalizeData(s, assay = "HTO", normalization.method = "CLR",
                       verbose = FALSE)
    s <- HTODemux(s, assay = "HTO", verbose = FALSE)
    demux_stats[[pfx]] <- table(s$HTO_classification.global)
    s <- subset(s, subset = HTO_classification.global == "Singlet")
    tag <- as.character(s$hash.ID)
    ms <- valid[tag, "multiplexed_sample"]
    pp <- strsplit(ms, "_")
    s$patient <- sapply(pp, function(z) z[2])
    s$day <- as.numeric(sapply(pp, function(z) z[4]))
  } else {
    s <- CreateSeuratObject(dedupe_rows(full), min.features = 0)
    p <- strsplit(pfx, "_")[[1]]
    s$patient <- p[3]; s$day <- as.numeric(p[5])
  }
  s$lane <- lane
  s$treatment <- unname(treatment_map[s$patient])
  s$well <- pfx
  objs[[pfx]] <- s
  cat(sprintf("%s -> %d singlets (patient %s)\n", pfx, ncol(s),
              paste(unique(s$patient), collapse = "/")))
}
cat("\n=== demux global counts per mixed well ===\n"); print(demux_stats)

sobj <- merge(objs[[1]], objs[-1])
sobj <- JoinLayers(sobj)
sobj[["percent_mt"]] <- PercentageFeatureSet(sobj, pattern = "^MT-")
cat("\ncells before QC:", ncol(sobj), "\n")
sobj <- subset(sobj, subset = nFeature_RNA > 200 & nFeature_RNA < 8000 &
                 percent_mt < 20)
cat("cells after QC:", ncol(sobj), "\n")

sobj <- NormalizeData(sobj, verbose = FALSE)
sobj <- FindVariableFeatures(sobj, nfeatures = 2000, verbose = FALSE)
sobj <- ScaleData(sobj, verbose = FALSE)
sobj <- RunPCA(sobj, npcs = 30, verbose = FALSE)
sobj <- RunHarmony(sobj, group.by.vars = "patient", verbose = FALSE)
sobj <- RunUMAP(sobj, reduction = "harmony", dims = 1:20, verbose = FALSE)
sobj <- FindNeighbors(sobj, reduction = "harmony", dims = 1:20, verbose = FALSE)
sobj <- FindClusters(sobj, resolution = 0.6, verbose = FALSE)

# PBMC marker annotation (no brain-resident lineages)
expr_data <- GetAssayData(sobj, layer = "data")
clusters <- sobj$seurat_clusters; clv <- levels(clusters)
posfrac <- function(genes) {
  genes <- intersect(genes, rownames(expr_data))
  sapply(clv, function(cl) {
    cells <- which(clusters == cl)
    mean(colSums(expr_data[genes, cells, drop = FALSE] > 0) > 0)
  })
}
pf <- as.data.frame(list(
  neut = posfrac(c("FCGR3B","CSF3R","S100A12","CXCR2")),
  mono = posfrac(c("CD14","LYZ","S100A8","FCGR3A")),
  dc   = posfrac(c("FCER1A","CLEC10A","CST3")),
  tcell= posfrac(c("CD3D","CD3E","TRAC")),
  bcell= posfrac(c("CD79A","CD79B","MS4A1")),
  nk   = posfrac(c("GNLY","NKG7","KLRD1"))))
rownames(pf) <- clv; print(round(pf, 2))
annot <- apply(pf, 1, function(r) {
  if (r["neut"] >= .5) "neutrophils"
  else if (r["nk"] >= .6 && r["tcell"] < .5) "NK_cells"
  else if (r["mono"] >= .5) "monocytes"
  else if (r["dc"] >= .5) "dendritic_cells"
  else if (r["tcell"] >= .5) "T_cells"
  else if (r["bcell"] >= .5) "B_cells"
  else "unassigned"
})
sobj$cell_type <- unname(annot[as.character(clusters)])
cat("\ncell type counts:\n"); print(table(sobj$cell_type))

Idents(sobj) <- "cell_type"
mk <- FindAllMarkers(sobj, only.pos = TRUE, min.pct = .25,
                     logfc.threshold = .5, verbose = FALSE)
write.csv(mk, file.path(resdir, "GSE313043_celltype_markers.csv"),
          row.names = FALSE)

# composition by treatment and by day
comp_tx <- as.data.frame(prop.table(table(sobj$treatment, sobj$cell_type),
                                    margin = 1))
write.csv(comp_tx, file.path(resdir, "GSE313043_composition_treatment.csv"),
          row.names = FALSE)
comp_day <- as.data.frame(prop.table(table(sobj$day, sobj$cell_type),
                                     margin = 1))
write.csv(comp_day, file.path(resdir, "GSE313043_composition_day.csv"),
          row.names = FALSE)

# hub localisation
lists <- readRDS(file.path(resdir, "consensus_gene_lists.rds"))
w <- readRDS(file.path(resdir, "GSE335924_WGCNA.rds"))
hub <- unique(c(head(lists$cs_up, 60), head(lists$cs_dn, 30),
                head(w$gene_tab$gene[w$gene_tab$module == 1], 20)))
hub <- intersect(hub, rownames(sobj))
pct <- sapply(unique(sobj$cell_type), function(ct) {
  cells <- which(sobj$cell_type == ct)
  rowMeans(expr_data[hub, cells, drop = FALSE] > 0)
})
write.csv(as.data.frame(pct), file.path(resdir,
          "GSE313043_hub_pct_expressing.csv"))
saveRDS(sobj, file.path(resdir, "GSE313043_seurat.rds"))
cat("\nGSE313043 HTO single-cell done\n")
