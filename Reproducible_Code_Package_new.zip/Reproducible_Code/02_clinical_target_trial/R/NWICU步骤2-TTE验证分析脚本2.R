# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# NWICU 步骤2c：补跑 G24/G72/VTE（强化版）
# 背景：N2-v2主分析（G48院内死亡/90天死亡）已成功；
#   G24在AIPW交叉拟合某折内glmnet遇到单一类别y而中断。
# 强化：AIPW交叉拟合中所有模型调用加tryCatch；
#   失败折回退为该臂训练集均值（边际预测），不再中断。
# 前置：N1c已重建队列（N1_分析队列.csv，558 stay）
# 输出：N2c_补跑结果.txt + N2c_结果汇总.csv
# ================================================================

rm(list = ls())
suppressMessages({library(data.table); library(glmnet); library(ranger)})
set.seed(2026)

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "N2c_补跑结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

rd <- function(rel, ...) fread(file.path(dir_nwicu, rel), ...)
dat <- fread(file.path(dir_out, "N1_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]

# 前置修正1：暴露重建（排除Not Given）
emar <- rd("data/nw_hosp/emar.csv.gz")
emar[, charttime := as.POSIXct(charttime)]
hep_all <- emar[grepl("HEPARIN|ENOXAPARIN", medication, ignore.case = TRUE)]
proph <- hep_all[
  (grepl("HEPARIN.*5000", medication, ignore.case = TRUE) &
     !grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("30 MG|40 MG", medication, ignore.case = TRUE))
]
proph <- proph[event_txt != "Not Given" | is.na(event_txt)]
px <- merge(proph[, .(hadm_id, charttime)],
            dat[, .(stay_id, hadm_id, intime)], by = "hadm_id")
px[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
first_px <- px[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
dat[, first_px_hrs := NULL]
dat <- merge(dat, first_px, by = "stay_id", all.x = TRUE, sort = FALSE)
cat("48h内早期预防：", sum(dat$first_px_hrs <= 48, na.rm = TRUE), "/",
    nrow(dat), "\n")

# 前置修正2：90天死亡口径
dat[!is.na(death_hrs) & (is.na(death90_hrs) | death90_hrs > 90 * 24) &
      death_hrs <= 90 * 24, death90_hrs := death_hrs]
dat[, mort90 := as.integer(!is.na(death90_hrs) & death90_hrs <= 90 * 24)]
cat("VTE结局：", sum(dat$vte), sprintf("(%.1f%%)\n\n", 100*mean(dat$vte)))

# 协变量矩阵
dat[, race4 := fcase(grepl("WHITE", race, ignore.case = TRUE), "White",
                     grepl("BLACK", race, ignore.case = TRUE), "Black",
                     grepl("ASIAN", race, ignore.case = TRUE), "Asian",
                     default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4 := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]
num_vars <- c("anchor_age","sbp","hr","platelet","creatinine","glucose","hemoglobin")
bin_vars <- c("hypertension","diabetes","prior_stroke","atrial_fib","ckd",
              "liver_dz","malignancy","longterm_ac","mech_vent","neurosx")
cat_vars <- c("gender_f","race4","insurance","admission_type")
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
miss_vars <- paste0(num_vars, "_miss")
for (v in bin_vars) { dat[is.na(get(v)), (v) := 0L]; dat[, (v) := as.integer(get(v))] }
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]

build_clones <- function(dt, G, evar) {
  ev <- dt[[evar]]
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early")],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed")])
  cl[, px := rep(ev, 2)]
  cl[, t_div := fifelse(!is.na(px) & px <= G, px, G)]
  cl[, adherent := fcase(arm == "early" & !is.na(px) & px <= G, 1L,
                         arm == "delayed" & (is.na(px) | px > G), 1L,
                         default = 0L)]
  cl
}

# 强化版：安全的glmnet包装（失败返回NULL）
safe_glmnet <- function(x, y) {
  y <- as.integer(y)
  if (length(unique(y)) < 2) return(NULL)
  tryCatch(cv.glmnet(x, y, family = "binomial", nfolds = 3),
           error = function(e) NULL)
}
safe_pred <- function(fit, x, fallback) {
  if (is.null(fit)) return(rep(fallback, nrow(x)))
  as.numeric(predict(fit, x, s = "lambda.min", type = "response"))
}

analyze_one <- function(dt, X, G, yvar, tvar, evar, n_boot = 500, label = "") {
  cat("[stage]", label, "构建克隆 G =", G, "\n")
  cl <- build_clones(dt, G, evar)
  cl[, Y := as.integer(dt[[yvar]][src_row])]
  tv <- dt[[tvar]][cl$src_row]
  cl[, ev_before_div := as.integer(!is.na(tv) & tv <= t_div)]
  Xall <- X[cl$src_row, , drop = FALSE]
  arm_all <- as.integer(cl$arm == "early")
  n_arm <- nrow(dt)
  cat("[stage]", label, "依从模型\n")
  p_all <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_all == a)
    fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                       family = "binomial", nfolds = 5)
    p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                     s = "lambda.min", type = "response"))
  }
  p_all <- pmax(p_all, 0.01)
  stab <- ave(cl$adherent, cl$arm, FUN = mean)
  w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
  w_all[cl$ev_before_div == 1] <- 1
  pos <- cl$adherent == 1 & cl$ev_before_div == 0
  qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
  w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])
  ht_est <- function(wv, arm_v, Y_v) {
    r_e <- sum(wv[arm_v == 1] * Y_v[arm_v == 1]) / n_arm
    r_d <- sum(wv[arm_v == 0] * Y_v[arm_v == 0]) / n_arm
    c(r_e, r_d, r_e - r_d, r_e / r_d)
  }
  kept <- cl$adherent == 1 | cl$ev_before_div == 1
  pt <- ht_est(w_all[kept], arm_all[kept], cl$Y[kept])
  subj <- cl$subject_id
  usubj <- unique(subj)
  idx_list <- split(seq_len(nrow(cl)), subj)
  boot_mat <- matrix(NA_real_, n_boot, 4)
  colnames(boot_mat) <- c("risk_early", "risk_delayed", "RD", "RR")
  for (b in 1:n_boot) {
    bs <- sample(usubj, replace = TRUE)
    bi <- unlist(idx_list[as.character(bs)])
    if (length(unique(cl$adherent[bi])) < 2) next
    p_b <- rep(NA_real_, length(bi))
    ok <- TRUE
    for (a in 0:1) {
      ia <- which(arm_all[bi] == a)
      fb <- mean(cl$adherent[bi][ia])
      fit_b <- safe_glmnet(Xall[bi[ia], , drop = FALSE], cl$adherent[bi][ia])
      if (is.null(fit_b) && length(unique(cl$adherent[bi][ia])) < 2) { ok <- FALSE; break }
      p_b[ia] <- safe_pred(fit_b, Xall[bi[ia], , drop = FALSE], fb)
    }
    if (!ok) next
    p_b <- pmax(p_b, 0.01)
    stab_b <- ave(cl$adherent[bi], arm_all[bi], FUN = mean)
    w_b <- ifelse(cl$adherent[bi] == 1, stab_b / p_b, 1)
    w_b[cl$ev_before_div[bi] == 1] <- 1
    posb <- cl$adherent[bi] == 1 & cl$ev_before_div[bi] == 0
    qsb <- quantile(w_b[posb], c(0.01, 0.99), na.rm = TRUE)
    w_b[posb] <- pmin(pmax(w_b[posb], qsb[1]), qsb[2])
    kept_b <- cl$adherent[bi] == 1 | cl$ev_before_div[bi] == 1
    boot_mat[b, ] <- ht_est(w_b[kept_b], arm_all[bi][kept_b], cl$Y[bi][kept_b])
  }
  ci_rd <- quantile(boot_mat[, 3], c(0.025, 0.975), na.rm = TRUE)
  ci_rr <- quantile(boot_mat[, 4], c(0.025, 0.975), na.rm = TRUE)
  cat("[stage]", label, "结局模型(强化交叉拟合)\n")
  M <- 5
  ofolds <- sample(rep(1:M, length.out = nrow(cl)))
  mu1 <- mu0 <- phat <- rep(NA_real_, nrow(cl))
  for (m in 1:M) {
    tr <- ofolds != m; te <- ofolds == m
    for (a in 0:1) {
      tr_a <- tr & arm_all == a & cl$adherent == 1
      fb_o <- mean(cl$Y[tr_a])
      fit_o <- safe_glmnet(Xall[tr_a, , drop = FALSE], cl$Y[tr_a])
      pr <- safe_pred(fit_o, Xall[te, , drop = FALSE], fb_o)
      if (a == 1) mu1[te] <- pr else mu0[te] <- pr
      tr_aa <- tr & arm_all == a
      fb_a <- mean(cl$adherent[tr_aa])
      fit_a <- safe_glmnet(Xall[tr_aa, , drop = FALSE], cl$adherent[tr_aa])
      phat[te & arm_all == a] <- safe_pred(fit_a,
                                           Xall[te & arm_all == a, , drop = FALSE], fb_a)
    }
  }
  phat <- pmax(phat, 0.01)
  in_arm <- arm_all == 1
  aug_w <- ifelse(cl$ev_before_div == 1, 1,
                  ifelse(cl$adherent == 1, 1 / phat, 0))
  aipw1 <- mu1 + in_arm * aug_w * (cl$Y - mu1)
  aipw0 <- mu0 + (!in_arm) * aug_w * (cl$Y - mu0)
  psi <- aipw1 - aipw0
  rd_aipw <- mean(psi)
  Dc <- tapply(psi - rd_aipw, subj, sum)
  se_rd <- sqrt(sum(Dc^2)) / length(psi)
  rr_aipw <- mean(aipw1) / mean(aipw0)
  ci_rd_a <- c(rd_aipw - 1.96 * se_rd, rd_aipw + 1.96 * se_rd)
  data.table(label = label, G = G, outcome = yvar,
             n_stay = n_arm, n_kept = sum(kept),
             ipcw_risk_early = round(pt[1], 4), ipcw_risk_delayed = round(pt[2], 4),
             ipcw_RD = round(pt[3], 4), ipcw_RD_lo = round(ci_rd[1], 4),
             ipcw_RD_hi = round(ci_rd[2], 4),
             ipcw_RR = round(pt[4], 3), ipcw_RR_lo = round(ci_rr[1], 3),
             ipcw_RR_hi = round(ci_rr[2], 3),
             aipw_RD = round(rd_aipw, 4), aipw_RD_lo = round(ci_rd_a[1], 4),
             aipw_RD_hi = round(ci_rd_a[2], 4), aipw_RR = round(rr_aipw, 3))
}

specs <- list(
  list(G = 24, y = "hosp_mort", t = "death_hrs", lab = "敏感性-G24"),
  list(G = 72, y = "hosp_mort", t = "death_hrs", lab = "敏感性-G72"),
  list(G = 48, y = "vte",       t = "death_hrs", lab = "敏感性-VTE")
)
res_list <- list()
for (sp in specs) {
  cat("\n======== ", sp$lab, " ========\n")
  out <- tryCatch(analyze_one(dat, X_mm, sp$G, sp$y, sp$t, "first_px_hrs",
                              500, sp$lab),
                  error = function(e) { cat("失败：", conditionMessage(e), "\n"); NULL })
  if (!is.null(out)) { print(out); res_list[[sp$lab]] <- out }
}
if (length(res_list) > 0) {
  res_all <- rbindlist(res_list)
  cat("\n== 补跑汇总 ==\n"); print(res_all)
  fwrite(res_all, file.path(dir_out, "N2c_结果汇总.csv"))
}
sink()
cat("运行完毕，请上传 N2c_补跑结果.txt 和 N2c_结果汇总.csv\n")

