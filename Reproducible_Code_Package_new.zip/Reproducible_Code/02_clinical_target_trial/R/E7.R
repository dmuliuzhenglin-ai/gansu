# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E7 - VTE 中介分析 (MIMIC): 早预防 -> VTE减少 -> 死亡减少?
# 方法: 自然直接/间接效应 (NDE/NIE), 回归法 (Imai 式)
#   暴露 A=≤48h 预防; 中介 M=新发 VTE; 结局 Y=院内死亡
#   模型: M ~ A + X (logistic); Y ~ A + M + A:M + X (logistic)
#   NDE = E[Y(1, M(0))] - E[Y(0, M(0))];  NIE = E[Y(1,M(1))] - E[Y(1,M(0))]
#   bootstrap 200 按患者聚类
# 用法: source(file.path(PATHS$clinical, "步骤E7-中介分析.R"), encoding="UTF-8")   约 10 分钟
# ============================================================

library(data.table)
options(error = NULL); set.seed(2026)
dir_out <- PATHS$clinical
B <- 200

# 自动探测 MIMIC 队列 (需含 VTE 结局列)
f_mimic <- file.path(PATHS$clinical, "M1_分析队列.csv")
if (!file.exists(f_mimic)) {
  for (fc in list.files(dir_out, pattern = "\\.csv$", full.names = TRUE)) {
    hd <- tolower(names(fread(fc, nrows = 2)))
    if (all(c("first_px_hrs", "hosp_mort") %in% hd) && any(grepl("vte", hd))) { f_mimic <- fc; break }
  }
}
cat("MIMIC 队列文件:", f_mimic, "\n")
dt <- fread(f_mimic)
nn <- tolower(names(dt))
vte_col <- names(dt)[grepl("vte", nn) & !grepl("prior", nn)][1]
cat("VTE 结局列:", vte_col, " 发生率:", round(100*mean(dt[[vte_col]], na.rm=TRUE), 2), "%\n")

if (!"female" %in% names(dt) && "gender" %in% names(dt))
  dt[, female := as.integer(gender %in% c("F","Female"))]
gcs_col <- names(dt)[grepl("gcs", nn)][1]
if (!is.na(gcs_col) && gcs_col != "gcs") setnames(dt, gcs_col, "gcs")

xvars <- intersect(c("age","female","gcs","mech_vent","neurosx","sbp","hr",
                     "platelet","hemoglobin","creatinine","glucose",
                     "hypertension","diabetes","ckd","heart_failure","malignancy","liver",
                     "prior_vte","prior_stroke"), names(dt))
for (v in xvars) if (any(is.na(dt[[v]]))) dt[is.na(get(v)), (v) := median(dt[[v]], na.rm = TRUE)]

dt[, A := as.integer(!is.na(first_px_hrs) & first_px_hrs <= 48)]
dt[, M := as.integer(get(vte_col) == 1)]
dt[, Y := as.integer(hosp_mort == 1)]
cat("暴露(≤48h):", sum(dt$A), " 中介(VTE):", sum(dt$M), " 结局(死亡):", sum(dt$Y), "\n")

med_fit <- function(d) {
  fm <- glm(reformulate(c("A", xvars), response = "M"), data = d, family = binomial)
  fy <- glm(reformulate(c("A", "M", "A:M", xvars), response = "Y"), data = d, family = binomial)
  # 标准化预测
  d1 <- copy(d)[, A := 1]; d0 <- copy(d)[, A := 0]
  pm1 <- predict(fm, newdata = d1, type = "response")
  pm0 <- predict(fm, newdata = d0, type = "response")
  py <- function(dd, mval) {
    dd2 <- copy(dd)[, M := mval]
    predict(fy, newdata = dd2, type = "response")
  }
  # E[Y(a, M(a'))] = sum_m E[Y|a,m] * P(M=m|a')
  E <- function(a_val, ap_val) {
    da <- copy(d)[, A := a_val]
    pm <- if (ap_val == 1) pm1 else pm0
    mean(py(da, 1) * pm + py(da, 0) * (1 - pm))
  }
  e11 <- E(1,1); e00 <- E(0,0); e10 <- E(1,0)
  c(NDE = e10 - e00, NIE = e11 - e10, TE = e11 - e00)
}

pt <- med_fit(dt)
cat(sprintf("\n点估计: 总效应 TE = %+.2fpp;  NDE(直接) = %+.2fpp;  NIE(经VTE) = %+.2fpp;  中介比例 = %.1f%%\n",
            100*pt["TE"], 100*pt["NDE"], 100*pt["NIE"], 100*pt["NIE"]/pt["TE"]))

uids <- unique(dt$subject_id)
boot <- replicate(B, {
  db <- dt[subject_id %in% sample(uids, length(uids), TRUE)]
  tryCatch(med_fit(db), error = function(e) c(NDE=NA, NIE=NA, TE=NA))
})
ci <- apply(boot, 1, quantile, c(.025,.975), na.rm = TRUE)
res <- data.table(
  effect = c("总效应 TE", "自然直接效应 NDE(不经VTE)", "自然间接效应 NIE(经VTE)", "中介比例"),
  estimate = c(100*pt["TE"], 100*pt["NDE"], 100*pt["NIE"], 100*pt["NIE"]/pt["TE"]),
  lo = c(100*ci[1,"TE"], 100*ci[1,"NDE"], 100*ci[1,"NIE"], NA),
  hi = c(100*ci[2,"TE"], 100*ci[2,"NDE"], 100*ci[2,"NIE"], NA),
  unit = c("pp","pp","pp","%")
)
print(res)
fwrite(res, file.path(dir_out, "E7_中介分析结果.csv"))
cat("/n完成 -> [clinical output directory]/E7_中介分析结果.csv/n")
cat("解读: NIE 显著 -> VTE 通路解释了部分获益; NIE 近零且 NDE 显著 -> 获益主要通过其他机制(制动/全身炎症等)\n")
