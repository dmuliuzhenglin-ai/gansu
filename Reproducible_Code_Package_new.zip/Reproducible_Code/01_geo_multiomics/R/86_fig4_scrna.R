# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 86_fig4_scrna.R
# Figure 4. Single-cell composition across the three scRNA-seq datasets
# (brain perilesional tissue, blood vs hematoma effluent, and PBMC by treatment)
# and hub-gene localisation across cell types in the brain dataset.
source(file.path(PATHS$project, "01_code/80_fig_theme.R"))
r <- file.path(PATHS$project, "02_results")

comp_plot <- function(file, grp_labels, title) {
  d <- read.csv(file.path(r, file), check.names = FALSE)
  colnames(d) <- c("group", "cell_type", "prop")
  d$group <- if (is.null(grp_labels)) d$group else
    unname(grp_labels[d$group])
  d$group <- factor(d$group, levels = rev(unique(d$group)))
  ggplot(d, aes(prop, group, fill = cell_type)) +
    geom_col(width = .62) +
    scale_fill_manual(values = pal_cell, name = "Cell type") +
    scale_x_continuous(labels = scales::percent_format(accuracy = 1)) +
    labs(x = "Cell fraction", y = NULL, title = title) +
    fig_theme + theme(legend.position = "none")
}
pA <- comp_plot("GSE266873_composition_phase.csv",
                c("early_<=12h" = "Early (<=12h)", "late_>12h" = "Late (>12h)"),
                "Perilesional tissue (GSE266873)")
pB <- comp_plot("GSE166638_composition_source.csv", NULL,
                "Blood vs hematoma effluent (GSE166638)")
pC <- comp_plot("GSE313043_composition_treatment.csv", NULL,
                "PBMC by treatment (GSE313043)")

# ---- D: hub localisation in brain tissue ---------------------------------
hp <- read.csv(file.path(r, "GSE266873_hub_pct_expressing.csv"),
               check.names = FALSE, row.names = 1)
key <- c("IL1R2","FCGR3B","KCNJ15","CXCL8","ACSL1","ALOX5AP","FCER1G",
         "CD74","HLA-DRA","ADM","UPP1","FKBP5")
key <- intersect(key, rownames(hp))
m <- as.matrix(hp[key, , drop = FALSE])
d <- data.frame(gene = factor(rownames(m), levels = rev(rownames(m))),
                m, check.names = FALSE) |>
  tidyr::pivot_longer(-gene, names_to = "cell_type", values_to = "pct")
pD <- ggplot(d, aes(cell_type, gene, fill = pct)) +
  geom_tile(colour = "white", linewidth = .3) +
  scale_fill_gradient(low = "#FBEEE6", high = "#922B21",
                      labels = scales::percent_format(), name = "Cells\nexpressing") +
  geom_text(aes(label = round(pct * 100)), size = 2) +
  labs(x = NULL, y = NULL, title = "Hub-gene localisation (GSE266873)") +
  fig_theme + theme(axis.text.x = element_text(angle = 30, hjust = 1, size = 7))

# shared cell-type legend across all three composition panels
all_types <- unique(c(
  read.csv(file.path(r, "GSE266873_composition_phase.csv"))$Var2,
  read.csv(file.path(r, "GSE166638_composition_source.csv"))$Var2,
  read.csv(file.path(r, "GSE313043_composition_treatment.csv"))$Var2))
leg_plot <- ggplot(data.frame(x = 1, cell_type = all_types),
                   aes(x, fill = cell_type)) + geom_bar() +
  scale_fill_manual(values = pal_cell, name = "Cell type") +
  theme(legend.position = "bottom", legend.direction = "horizontal",
        legend.text = element_text(size = 7))
shared_leg <- cowplot::get_legend(leg_plot)

pA <- pA + labs(tag = "A"); pB <- pB + labs(tag = "B")
pC <- pC + labs(tag = "C"); pD <- pD + labs(tag = "D")
grid <- patchwork::wrap_plots(pA, pB, pC, pD, ncol = 2) &
  theme(plot.tag = element_text(face = "bold", size = 10),
        plot.tag.position = c(.02, .98))
fig4 <- patchwork::wrap_plots(grid, shared_leg, ncol = 1,
                              heights = c(1, .13))
save_pdf(fig4, "Figure4_singlecell", 180, 185)
