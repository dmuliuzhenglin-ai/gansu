# E-values: validate against archived inputs, then compute on deterministic RRs
suppressMessages(library(EValue))

run_ev <- function(res) {
  for (i in seq_len(nrow(res))) {
    r <- evalues.RR(res$RR[i], res$lo[i], res$hi[i], rare = FALSE)
    ev_p  <- r["E-values", "point"]
    ev_ci <- r["E-values", "upper"]
    cat(sprintf("%s [%s]: RR=%.4f (%.4f-%.4f) -> E-value point=%.2f, CI bound=%.2f\n",
                res$outcome[i], res$method[i], res$RR[i], res$lo[i],
                res$hi[i], ev_p, ev_ci))
  }
}

old <- data.frame(
  outcome = c("hosp_mort", "hosp_mort", "mort90", "mort90"),
  method = c("IPCW", "AIPW", "IPCW", "AIPW"),
  RR = c(0.7115, 0.7538, 0.7130, 0.8201),
  lo = c(0.6378, 0.6462, 0.6565, 0.7300),
  hi = c(0.7851, 0.8794, 0.7668, 0.9213))
cat("=== validation: archived inputs (expect 2.16/1.86, 1.98/1.53, 2.15/1.93, 1.74/1.39) ===\n")
run_ev(old)

new <- data.frame(
  outcome = c("hosp_mort", "hosp_mort", "mort90", "mort90"),
  method = c("IPCW", "AIPW", "IPCW", "AIPW"),
  RR = c(0.7727, 0.7233, 0.7683, 0.7962),
  lo = c(0.6881, 0.6208, 0.7039, 0.7092),
  hi = c(0.8559, 0.8427, 0.8317, 0.8938))
cat("\n=== deterministic pipeline RRs ===\n")
run_ev(new)
