# --- shared path configuration; edit config_paths.py for your local machine ---
import os as _os, sys as _sys
for _cf in ("config_paths.py", "../../config_paths.py", "../config_paths.py", "../../../config_paths.py"):
    if _os.path.exists(_cf):
        _d = _os.path.dirname(_os.path.abspath(_cf))
        if _d not in _sys.path:
            _sys.path.insert(0, _d)
        import config_paths as _cp
        PATHS = _cp.PATHS
        break
# -*- coding: utf-8 -*-
"""Extract haematology / liver labs from MIMIC-IV labevents for the ICH cohort."""
import os
import pandas as pd

LAB = ros.path.join(PATHS["mimic"], "hosp/labevents.csv.gz")
OUTDIR = ros.path.join(PATHS["project"], "05_bridge_immune/00_data")
os.makedirs(OUTDIR, exist_ok=True)
OUT = os.path.join(OUTDIR, "labs_subset.csv.gz")

IDS = [51133, 52769, 53157, 51244, 51245,
       52075, 53159, 51256,
       52074, 51253, 51254,
       51301,
       50862, 53085, 53138,
       50885, 53089]

COLS = ["subject_id", "hadm_id", "itemid", "charttime", "valuenum", "valueuom"]

chunks = []
reader = pd.read_csv(
    LAB,
    usecols=COLS,
    chunksize=2_000_000,
    dtype={"subject_id": "float64", "hadm_id": "float64", "itemid": "float64",
           "valuenum": "float64", "valueuom": "object", "charttime": "object"},
    compression="gzip",
    on_bad_lines="skip",
    engine="c",
)
total = 0
for i, ch in enumerate(reader):
    total += len(ch)
    sub = ch[ch["itemid"].isin(IDS)]
    if len(sub):
        chunks.append(sub)
    if i % 5 == 0:
        print("chunk", i, "rows scanned", total, "kept", sum(len(c) for c in chunks), flush=True)

lab = pd.concat(chunks, ignore_index=True)
lab["charttime"] = pd.to_datetime(lab["charttime"], errors="coerce")
lab = lab.sort_values(["subject_id", "charttime"])
lab.to_csv(OUT, index=False, compression="gzip")

print("TOTAL scanned:", total)
print("KEPT:", len(lab))
lab["itemid"] = lab["itemid"].astype("int32")
print(lab.groupby(["itemid", "valueuom"]).size().to_string())
print("SAVED:", OUT)
