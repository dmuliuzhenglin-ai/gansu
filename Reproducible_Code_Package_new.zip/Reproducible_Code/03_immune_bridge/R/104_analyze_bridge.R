# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
## 104_analyze_bridge.R
## 淋巴细胞绝对值 / NLR / 单核% 的分窗轨迹 + 暴露后净变化 + IPTW + ALBI
## 输出：轨迹表、混合模型、加权窗口差、ALBI 关联、MIMIC 横断面验证

suppressPackageStartupMessages({
  library(data.table)
  library(lme4)
  library(sandwich)
})

dir_in  <- file.path(PATHS$project, "05_bridge_immune/01_data")
dir_out <- file.path(PATHS$project, "05_bridge_immune/02_results")
dir.create(dir_out, recursive = TRUE, showWarnings = FALSE)

long <- fread(file.path(dir_in, "eicu_bridge_long.csv"), encoding = "UTF-8")
long[, metric := factor(metric, levels = c("alc", "nlr", "mono_pct"))]
long <- long[metric %in% c("alc", "nlr", "mono_pct")]

## ---------- 1. 基线值 + 协变量缺失填补 ----------
bl <- long[win == "W0", .(stay_id, metric, base = value)]
long <- merge(long, bl, by = c("stay_id", "metric"), all.x = TRUE)

covs <- c("age", "gcs", "mech_vent", "neurosx", "platelet", "creatinine",
          "hemoglobin", "ckd", "liver", "los_icu_hrs", "hosp_mort")
for (v in setdiff(covs, "hosp_mort")) {
  med <- median(long[[v]], na.rm = TRUE)
  long[is.na(get(v)), (v) := med]
}
long[, mech_vent := as.numeric(mech_vent)]
long[, neurosx := as.numeric(neurosx)]
long[, ckd := as.numeric(ckd)]
long[, liver := as.numeric(liver)]

## ---------- 2. 倾向评分（每个 stay 一行） ----------
per_stay <- unique(long[, .(stay_id, early, hospitalid, age, gcs, mech_vent, neurosx,
                            platelet, creatinine, hemoglobin, ckd, liver)])
ps_fit <- glm(early ~ age + gcs + mech_vent + neurosx + platelet + creatinine +
                hemoglobin + ckd + liver, data = per_stay, family = binomial)
per_stay[, ps := fitted(ps_fit)]
per_stay[, w_raw := fifelse(early == 1, 1 / ps, 1 / (1 - ps))]
per_stay[, w := w_raw / mean(w_raw)]
qs <- quantile(per_stay$w, c(0.01, 0.99))
per_stay[, w := pmin(pmax(w, qs[1]), qs[2])]
per_stay[, w := w / mean(w)]
cat("PS overlap: early mean ps =", round(mean(per_stay$ps[per_stay$early == 1]), 3),
    " delayed mean ps =", round(mean(per_stay$ps[per_stay$early == 0]), 3), "\n")
fwrite(per_stay[, .(stay_id, early, ps, w)], file.path(dir_out, "eicu_ps_weights.csv"))

long <- merge(long, per_stay[, .(stay_id, w, ps)], by = "stay_id")
long[, win_f := factor(win, levels = c("W0", "W24", "W48", "W72"))]

## ---------- 3. 描述性轨迹（组 × 窗口 加权均值 + 95% CI） ----------
traj <- long[, {
  wm <- weighted.mean(value, w)
  ws <- sqrt(sum(w * (value - wm)^2, na.rm = TRUE) / sum(w))
  se <- ws / sqrt(.N)
  .(n = .N, n_stay = uniqueN(stay_id), est = wm, sd = ws,
    lo = wm - 1.96 * se, hi = wm + 1.96 * se)
}, by = .(metric, win_f, early)]
fwrite(traj, file.path(dir_out, "eicu_trajectory.csv"))
print(traj)

## ---------- 4. 混合效应模型：组 × 时间交互 ----------
mm_res <- list()
for (m in c("alc", "nlr", "mono_pct")) {
  d <- long[metric == m & !is.na(base)]
  if (nrow(d) < 50) next
  fit <- try(lmer(
    value ~ early * win_f + base + age + gcs + mech_vent + neurosx + platelet +
      creatinine + (1 | stay_id) + (1 | hospitalid),
    data = d, weights = w,
    control = lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 2e5))
  ), silent = TRUE)
  if (inherits(fit, "try-error")) {
    cat("LMER FAIL:", m, "\n"); next
  }
  co <- summary(fit)$coefficients
  ci <- confint(fit, method = "Wald", level = 0.95)
  tab <- data.table(metric = m, term = rownames(co), est = co[, 1], se = co[, 2])
  tab[, p := 2 * pnorm(-abs(est / se))]
  ci_dt <- data.table(term = rownames(ci), lo = ci[, 1], hi = ci[, 2])
  tab <- merge(tab, ci_dt, by = "term", all.x = TRUE)
  mm_res[[m]] <- tab
}
mm <- rbindlist(mm_res, fill = TRUE)
fwrite(mm, file.path(dir_out, "eicu_mixed_model.csv"))
print(mm[grepl("early", term)])

## ---------- 5. 暴露后净变化 Δ（W48 − W0），调整 + bootstrap ----------
wide <- dcast(long[metric %in% c("alc", "nlr", "mono_pct")],
              stay_id + metric + early + w + age + gcs + mech_vent + neurosx +
                platelet + creatinine + hospitalid ~ win, value.var = "value")
delta <- wide[!is.na(W0) & !is.na(W48), .(
  n = .N, n_early = sum(early),
  d_early = weighted.mean((W48 - W0)[early == 1], w[early == 1]),
  d_delay = weighted.mean((W48 - W0)[early == 0], w[early == 0])
), by = metric]

set.seed(7)
delta_ci <- delta[, {
  d <- wide[metric == .BY$metric & !is.na(W0) & !is.na(W48)]
  bs <- replicate(500, {
    h <- sample(unique(d$hospitalid), length(unique(d$hospitalid)), replace = TRUE)
    dd <- rbindlist(lapply(h, function(x) d[hospitalid == x]))
    if (sum(dd$early == 1) < 5) return(NA_real_)
    weighted.mean((dd$W48 - dd$W0)[dd$early == 1], dd$w[dd$early == 1]) -
      weighted.mean((dd$W48 - dd$W0)[dd$early == 0], dd$w[dd$early == 0])
  })
  ci <- quantile(bs, c(0.025, 0.975), na.rm = TRUE)
  .(diff = weighted.mean((d$W48 - d$W0)[d$early == 1], d$w[d$early == 1]) -
           weighted.mean((d$W48 - d$W0)[d$early == 0], d$w[d$early == 0]),
    diff_lo = ci[1], diff_hi = ci[2])
}, by = metric]
delta <- merge(delta, delta_ci, by = "metric")
fwrite(delta, file.path(dir_out, "eicu_delta.csv"))
print(delta)

## ---------- 6. ALBI ----------
b <- fread(file.path(dir_in, "eicu_bridge_baseline.csv"), encoding = "UTF-8")
b <- merge(b, per_stay[, .(stay_id, w, ps)], by = "stay_id")
b[, hosp_mort := as.integer(hosp_mort)]
b_albi <- b[!is.na(albi)]
cat("ALBI n =", nrow(b_albi), " early", sum(b_albi$early), "\n")

albi_group <- b_albi[, .(n = .N,
                         mean = weighted.mean(albi, w),
                         sd = sqrt(sum(w * (albi - weighted.mean(albi, w))^2) / sum(w))),
                     by = early]
albi_group[, early_lab := fcase(early == 0, "delayed", early == 1, "early")]
print(albi_group)

## ALBI 与住院死亡：加权 logistic
logit_fit <- glm(hosp_mort ~ albi + early + age + gcs + mech_vent, data = b_albi,
                 family = binomial, weights = w)
lo_co <- summary(logit_fit)$coefficients
albi_or <- data.table(term = rownames(lo_co), est = lo_co[, 1], se = lo_co[, 2], p = lo_co[, 4])
albi_or[, OR := exp(est)]
albi_or[, `:=`(OR_lo = exp(est - 1.96 * se), OR_hi = exp(est + 1.96 * se))]
print(albi_or)

## ALBI 与暴露后 ALC 的关联（W48）
w48 <- long[metric == "alc" & win == "W48"]
w48 <- merge(w48, b_albi[, .(stay_id, albi)], by = "stay_id")
cor_albi <- if (nrow(w48) > 20) cor.test(w48$albi, w48$value, method = "spearman") else NULL
if (!is.null(cor_albi)) {
  cat("ALBI vs W48 ALC: rho =", round(unname(cor_albi$estimate), 3),
      "p =", signif(cor_albi$p.value, 3), "n =", nrow(w48), "\n")
}

albi_out <- rbind(
  albi_group[, .(analysis = "albi_by_group", term = early_lab, est = mean,
                 se = NA_real_, p = NA_real_, OR = NA_real_, OR_lo = NA_real_, OR_hi = NA_real_)],
  albi_or[, .(analysis = "albi_mortality", term, est, se, p, OR, OR_lo, OR_hi)]
)
fwrite(albi_out, file.path(dir_out, "albi_results.csv"))

## ---------- 7. MIMIC 横断面验证 ----------
ml <- fread(file.path(dir_in, "bridge_long.csv"), encoding = "UTF-8")
ml <- ml[metric %in% c("alc", "nlr", "mono_pct")]
mimic_cc <- ml[, .(n = .N, mean = mean(value, na.rm = TRUE),
                   sd = sd(value, na.rm = TRUE)), by = .(metric, win, early)]
fwrite(mimic_cc, file.path(dir_out, "mimic_crosssec.csv"))
print(mimic_cc)

mb <- fread(file.path(dir_in, "bridge_baseline.csv"), encoding = "UTF-8")
mb[, hosp_mort := as.integer(hosp_mort)]
mb_albi <- mb[!is.na(albi)]
if (nrow(mb_albi) > 50) {
  f2 <- glm(hosp_mort ~ albi + early + anchor_age + gcs_total, data = mb_albi, family = binomial)
  s2 <- summary(f2)$coefficients
  cat("\nMIMIC ALBI->mortality (per 1 unit):\n")
  print(round(cbind(OR = exp(s2[, 1]), lo = exp(s2[, 1] - 1.96 * s2[, 2]),
                    hi = exp(s2[, 1] + 1.96 * s2[, 2]), p = s2[, 4]), 3))
}
cat("\nDONE\n")
