# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 72_relink_methyl.R
# Refine methylation-expression linking using single-evidence DEGs too.
suppressPackageStartupMessages(library(dplyr))
resdir <- file.path(PATHS$project, "02_results")
m <- readRDS(file.path(resdir, "GSE179759_methylation.rds"))
cs <- read.csv(file.path(resdir, "cross_section_consensus.csv"))
link <- m$gene_meth %>%
  left_join(cs %>% select(gene, n_up, n_down, consensus),
            by = c("gene_symbol" = "gene"))
link$link_type <- case_when(
  link$regulation == "hypo"  & link$consensus == "consensus_up"   ~ "hypomethylation_up_consensus",
  link$regulation == "hyper" & link$consensus == "consensus_down" ~ "hypermethylation_down_consensus",
  link$regulation == "hypo"  & link$n_up >= 1 & link$n_down == 0  ~ "hypomethylation_up_single",
  link$regulation == "hyper" & link$n_down >= 1 & link$n_up == 0  ~ "hypermethylation_down_single",
  TRUE ~ NA_character_)
write.csv(link, file.path(resdir, "methyl_expression_link.csv"), row.names = FALSE)
cat("supported methylation-expression links:\n")
print(link[!is.na(link$link_type),
      c("gene_symbol","regulation","consensus","link_type","mean_delta_beta")],
      row.names = FALSE)
cat("\nrelink done\n")
