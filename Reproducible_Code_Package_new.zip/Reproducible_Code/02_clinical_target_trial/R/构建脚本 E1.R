# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E1b - E1 队列数据清洗补丁
# 修: ① gcs 非法值(-3 等)置 NA  ② mech_vent NA -> 0  ③ age 字符 -> 数值("> 89"=91)
# 用法: source(file.path(PATHS$clinical, "eICU步骤1b.R"), encoding="UTF-8")
# ============================================================

library(data.table)
dir_out <- PATHS$clinical

out <- fread(file.path(dir_out, "E1_分析队列.csv"))
cat("读入:", nrow(out), "行\n")

# ① GCS 合法范围 3-15
bad_gcs <- sum(out$gcs < 3 | out$gcs > 15, na.rm = TRUE)
out[gcs < 3 | gcs > 15, gcs := NA_integer_]
cat("① 非法 GCS 置 NA:", bad_gcs, "例;  现 GCS 缺失:", sum(is.na(out$gcs)), "\n")

# ② mech_vent: NA(不在通气名单且 intubated 缺失) -> 0
out[is.na(mech_vent), mech_vent := 0L]
cat("② mech_vent=1:", sum(out$mech_vent == 1), sprintf("(%.1f%%)", 100*mean(out$mech_vent == 1)), "\n")

# ③ age: "> 89" -> 91, 其余转数值
out[, age_num := suppressWarnings(as.numeric(age))]
out[age == "> 89", age_num := 91]
cat("③ age 转换后缺失:", sum(is.na(out$age_num)), " 中位数:", median(out$age_num, na.rm = TRUE), "\n")
out[, age := NULL]
setnames(out, "age_num", "age")

# 体检: 关键列完整性
cat("\n关键列缺失率:\n")
for (v in c("gcs","platelet","hemoglobin","creatinine","glucose","pt_sec","sbp","hr","first_px_hrs"))
  cat(sprintf("  %-12s %.1f%%\n", v, 100*mean(is.na(out[[v]]))))
cat("\nGCS 分布: ≤8:", sum(out$gcs <= 8, na.rm = TRUE),
    " 9-12:", sum(out$gcs %in% 9:12, na.rm = TRUE),
    " 13-15:", sum(out$gcs >= 13, na.rm = TRUE), "\n")

fwrite(out, file.path(dir_out, "E1_分析队列.csv"))
cat("/n已覆盖写回 [clinical output directory]/E1_分析队列.csv/n")

