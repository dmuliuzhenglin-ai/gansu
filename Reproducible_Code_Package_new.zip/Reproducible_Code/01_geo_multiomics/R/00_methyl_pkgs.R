# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 查本地已安装的甲基化注释相关包
ip <- rownames(installed.packages())
hit <- grep("Methyl|EPIC|minfi|mnp|Illumina", ip, value = TRUE, ignore.case = TRUE)
cat("installed methylation-related packages:\n"); print(hit)
# BiocManager 可用性
cat("\nBiocManager:", requireNamespace("BiocManager", quietly = TRUE), "\n")
cat("BiocVersion repos:\n"); print(options()$repos)
