# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E8b - 血肿扩大 NLP 修正版
# 修: radiology 无 exam_name 列 -> 从 text 开头 400 字符识别头颅 CT
# 用法: source(file.path(PATHS$clinical, "步骤E8b-血肿扩大NLP修正版.R"), encoding="UTF-8")  约 5-10 分钟
# ============================================================

library(data.table)
options(error = NULL); set.seed(2026)
dir_out   <- PATHS$clinical
dir_note  <- PATHS$note
dir_mimic <- PATHS$mimic

dt <- fread(file.path(PATHS$clinical, "01_分析队列.csv"))
cat("ICH 队列:", nrow(dt), "\n")
dt[, A := as.integer(!is.na(first_px_hrs) & first_px_hrs <= 48)]

rad <- fread(file.path(dir_note, "radiology.csv.gz"))
rad <- rad[subject_id %in% dt$subject_id]
cat("ICH 患者放射报告总数:", nrow(rad), " 覆盖患者:", uniqueN(rad$subject_id), "\n")

# ---- 从正文开头识别头颅 CT ----
hdr <- tolower(substr(rad$text, 1, 400))
ct_pat <- "ct (scan )?(of the )?(head|brain)|head ct|brain ct|ct head|ct brain|head without (iv )?contrast|non-?contrast (ct )?(head|brain)|crani"
head_ct <- rad[grepl(ct_pat, hdr)]
cat("识别为头颅 CT 的报告:", nrow(head_ct), " 覆盖患者:", uniqueN(head_ct$subject_id), "\n")
# 抽样打印 3 条报告开头核对识别正确性
cat("\n---- 头颅CT识别核对(开头80字符) ----\n")
for (i in seq_len(min(3, nrow(head_ct))))
  cat("[", i, "] ", gsub("\\s+", " ", substr(head_ct$text[i], 1, 80)), "\n")

# ---- 扩大判定 ----
pos_pat <- "interval increase|hematoma expansion|expansion of (the )?hematoma|increased (size|volume) of (the )?(hematoma|hemorrhage)|worsening (of )?(the )?(hemorrhage|hematoma)|enlarg(ed|ing) (hematoma|hemorrhage)|rebleed|re-bleed|new (area of )?hemorrhage"
neg_pat <- "no (significant )?interval|stable|unchanged|decreased|resolv|improv|no (new|acute|expansion|increase)"
head_ct[, expand := as.integer(grepl(pos_pat, text, ignore.case = TRUE) &
                                 !grepl(neg_pat, text, ignore.case = TRUE))]
cat("\n判定为扩大的报告数:", sum(head_ct$expand == 1),
    sprintf("(%.1f%% of reports)\n", 100*mean(head_ct$expand)))

cat("\n---- 阳性报告片段抽样(人工校验用) ----\n")
pos <- head_ct[expand == 1]
for (i in seq_len(min(5, nrow(pos)))) {
  tt <- pos$text[i]
  m <- regexpr(pos_pat, tt, ignore.case = TRUE)
  if (m > 0) cat("...", gsub("\\s+", " ", substr(tt, max(1, m-120), m + 160)), "...\n\n")
}

# ---- 时间对齐 ----
head_ct[, rpt_time := as.POSIXct(charttime)]
dt[, intime := as.POSIXct(intime)]
key <- dt[, .(subject_id, intime, first_px_hrs, A)]
head_ct <- merge(head_ct, key, by = "subject_id", allow.cartesian = TRUE, sort = FALSE)
head_ct[, rpt_hrs := as.numeric(difftime(rpt_time, intime, units = "hours"))]
head_ct[, anchor := fifelse(A == 1 & !is.na(first_px_hrs), first_px_hrs, 48)]
post <- head_ct[rpt_hrs > anchor]
cat("锚点后的头颅CT报告:", nrow(post), " 覆盖患者:", uniqueN(post$subject_id), "\n")
exp_rate <- post[, .(expanded = as.integer(any(expand == 1))), by = subject_id]
dt <- merge(dt, exp_rate, by = "subject_id", all.x = TRUE, sort = FALSE)
dt[is.na(expanded), expanded := 0L]

# ---- 比较 ----
tab <- table(dt$A, dt$expanded)
cat("\n血肿扩大率: 早预防组", sum(dt$A==1 & dt$expanded==1), "/", sum(dt$A==1),
    sprintf("(%.1f%%) vs 对照组", 100*mean(dt$expanded[dt$A==1])),
    sum(dt$A==0 & dt$expanded==1), "/", sum(dt$A==0),
    sprintf("(%.1f%%)\n", 100*mean(dt$expanded[dt$A==0])))
print(tab)
if (all(dim(tab) == c(2, 2))) {
  print(fisher.test(tab))
  xvars <- intersect(c("age","gender","gcs_total","mech_vent","sbp","platelet","inr"), names(dt))
  dd <- copy(dt)
  if ("gender" %in% xvars) dd[, gender := as.integer(gender %in% c("F","Female"))]
  for (v in xvars) if (is.numeric(dd[[v]]) && any(is.na(dd[[v]]))) dd[is.na(get(v)), (v) := median(dd[[v]], na.rm = TRUE)]
  fit <- glm(reformulate(c("A", xvars), response = "expanded"), data = dd, family = binomial)
  ci <- suppressMessages(confint(fit))
  cat(sprintf("\n调整后 OR(早预防 vs 对照): %.2f (%.2f, %.2f)\n",
              exp(coef(fit)["A"]), exp(ci["A",1]), exp(ci["A",2])))
} else cat("!! 列联表维度不足, 跳过统计检验\n")
fwrite(data.table(early_n = sum(dt$A==1), early_exp = sum(dt$A==1 & dt$expanded==1),
                  ctrl_n = sum(dt$A==0), ctrl_exp = sum(dt$A==0 & dt$expanded==1)),
       file.path(dir_out, "E8_血肿扩大NLP.csv"))
cat("/n完成 -> [clinical output directory]/E8_血肿扩大NLP.csv/n")

