# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 统计 series matrix 表达表行 ID 类型
f <- file.path(PATHS$project, "00_data/GSE43618/GSE43618_series_matrix.txt.gz")
con <- gzfile(f); lines <- readLines(con); close(con)
tb_start <- grep("!series_matrix_table_begin", lines)
tb_end <- grep("!series_matrix_table_end", lines)
data_lines <- lines[(tb_start + 2):(tb_end - 1)]   # skip header
ids <- sub("^\"([^\"]+)\".*", "\\1", data_lines)
cat("total data rows:", length(ids), "\n")
cat("dmr rows:", sum(grepl("^dmr", ids)), "\n")
cat("hsa rows:", sum(grepl("^hsa", ids)), "\n")
cat("other:", sum(!grepl("^(dmr|hsa)", ids)), "\n")
print(head(ids[grepl("^hsa", ids)], 8))
