﻿$src = os.path.join(PATHS["project"], "04_manuscript/Manuscript_Frontiers_Immunology.docx")
$pdf = os.path.join(PATHS["project"], "04_manuscript/Manuscript_Frontiers_Immunology_preview.pdf")
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$doc = $word.Documents.Open($src, $false, $true)
$doc.ExportAsFixedFormat($pdf, 17)
$doc.Close($false)
$word.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
if (Test-Path $pdf) { "PDF OK: " + (Get-Item $pdf).Length }
