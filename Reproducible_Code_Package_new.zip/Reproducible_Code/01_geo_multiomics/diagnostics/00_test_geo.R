# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 00_test_geo.R - 验证 GEOquery https 下载通道
options(timeout = 600)
dest <- file.path(PATHS$project, "00_data")
dir.create(dest, recursive = TRUE, showWarnings = FALSE)

t0 <- Sys.time()
g <- GEOquery::getGEO("GSE125512", destdir = dest, GSEMatrix = TRUE,
                      getGPL = FALSE, AnnotGPL = FALSE)
cat("elapsed:", round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1), "s\n")
es <- g[[1]]
cat("class:", class(es), "\n")
cat("dim:", nrow(Biobase::exprs(es)), "probes x", ncol(Biobase::exprs(es)), "samples\n")
cat("pheno vars:\n")
print(colnames(Biobase::pData(es)))
cat("\nfirst 6 pData columns preview:\n")
print(head(Biobase::pData(es)[, 1:min(6, ncol(Biobase::pData(es)))]))
cat("\nGEO data OK\n")
