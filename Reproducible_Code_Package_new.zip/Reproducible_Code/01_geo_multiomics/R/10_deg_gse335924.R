# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 10_deg_gse335924.R
# GSE335924 (PBMC, RNA-seq): ICH (n=28) vs hypertension controls without ICH (sh, n=25)
# edgeR quasi-likelihood pipeline
suppressPackageStartupMessages({
  library(readxl); library(edgeR); library(dplyr)
})

root <- PATHS$project
xlsx <- file.path(root, "00_data/GSE335924/GSE335924_expression.xlsx")
resdir <- file.path(root, "02_results"); figdir <- file.path(root, "03_figures")

# ---- 1. read counts ----
raw <- as.data.frame(readxl::read_excel(xlsx, sheet = "expression_table",
                                        .name_repair = "minimal"))
count_cols <- grep("_COUNT$", names(raw), value = TRUE)
cnt <- as.matrix(raw[, count_cols])
# sample IDs drop the _COUNT suffix; group from prefix
sids <- sub("_COUNT$", "", count_cols)
colnames(cnt) <- sids
grp <- ifelse(grepl("^ICH", sids), "ICH", "sh")
group <- factor(grp, levels = c("sh", "ICH"))   # reference = hypertension control
rownames(cnt) <- make.unique(ifelse(!is.na(raw$name) & raw$name != "",
                                   raw$name, raw$GeneID))
cat("samples:", table(group), "\ngenes before filter:", nrow(cnt), "\n")

# ---- 2. DGEList, filter, normalize ----
y <- DGEList(counts = cnt, group = group)
keep <- filterByExpr(y, group = group)
y <- y[keep, , keep.lib.sizes = FALSE]
y <- calcNormFactors(y, method = "TMM")
cat("genes after filter:", nrow(y), "\n")

# ---- 3. design & QL fit ----
design <- model.matrix(~group)
y <- estimateDisp(y, design)
fit <- glmQLFit(y, design, robust = TRUE)
qlf <- glmQLFTest(fit, coef = "groupICH")
tt <- topTags(qlf, n = Inf, sort.by = "PValue")$table
tt$gene <- rownames(tt)
tt <- tt[, c("gene", "logFC", "logCPM", "F", "PValue", "FDR")]

# ---- 4. call DEGs ----
tt$regulation <- "NS"
tt$regulation[tt$FDR < 0.05 & tt$logFC >= 1]  <- "up"
tt$regulation[tt$FDR < 0.05 & tt$logFC <= -1] <- "down"
cat("DEG counts:\n"); print(table(tt$regulation))

write.csv(tt, file.path(resdir, "GSE335924_DEG_all.csv"), row.names = FALSE)
saveRDS(list(dge = y, fit = fit, qlf = qlf, degs = tt),
        file.path(resdir, "GSE335924_edgeR.rds"))

# ---- 5. volcano data (plot in a dedicated figure script) ----
sig <- subset(tt, regulation != "NS")
write.csv(sig, file.path(resdir, "GSE335924_DEG_significant.csv"),
          row.names = FALSE)
cat("\ntop 15 DEGs:\n")
print(head(tt[order(tt$FDR), ], 15), row.names = FALSE)
cat("\nGSE335924 DEG done\n")
