# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 68_reannotate_313043.R
# Re-annotate the already-integrated GSE313043 object without re-running
# harmony/UMAP. Adaptive lineages are scored first with specific markers so T
# and B cells are no longer absorbed by the broad monocyte rule.
suppressPackageStartupMessages(library(Seurat))
options(future.globals.maxSize = 20 * 1024^3)
root <- PATHS$project
resdir <- file.path(root, "02_results")
sobj <- readRDS(file.path(resdir, "GSE313043_seurat.rds"))

expr_data <- GetAssayData(sobj, layer = "data")
clusters <- sobj$seurat_clusters; clv <- levels(clusters)
posfrac <- function(genes) {
  genes <- intersect(genes, rownames(expr_data))
  sapply(clv, function(cl) {
    cells <- which(clusters == cl)
    mean(colSums(expr_data[genes, cells, drop = FALSE] > 0) > 0)
  })
}
pf <- as.data.frame(list(
  tcell = posfrac(c("CD3D","CD3E","TRAC")),
  bcell = posfrac(c("CD79A","CD79B","MS4A1")),
  nk    = posfrac(c("GNLY","NKG7","KLRF1")),
  neut  = posfrac(c("FCGR3B","CSF3R","CXCR2","S100A12")),
  dc    = posfrac(c("FCER1A","CLEC10A","CST3")),
  mono  = posfrac(c("CD14","FCGR3A","S100A8"))))
rownames(pf) <- clv; print(round(pf, 2))

annot <- apply(pf, 1, function(r) {
  if (r["tcell"] >= .5) "T_cells"
  else if (r["bcell"] >= .5) "B_cells"
  else if (r["nk"] >= .6 && r["tcell"] < .5) "NK_cells"
  else if (r["neut"] >= .5) "neutrophils"
  else if (r["dc"] >= .5) "dendritic_cells"
  else if (r["mono"] >= .5) "monocytes"
  else "unassigned"
})
sobj$cell_type <- unname(annot[as.character(clusters)])
cat("\ncorrected cell type counts:\n"); print(table(sobj$cell_type))

Idents(sobj) <- "cell_type"
mk <- FindAllMarkers(sobj, only.pos = TRUE, min.pct = .25,
                     logfc.threshold = .5, verbose = FALSE)
write.csv(mk, file.path(resdir, "GSE313043_celltype_markers.csv"),
          row.names = FALSE)

comp_tx <- as.data.frame(prop.table(table(sobj$treatment, sobj$cell_type),
                                    margin = 1))
write.csv(comp_tx, file.path(resdir, "GSE313043_composition_treatment.csv"),
          row.names = FALSE)
comp_day <- as.data.frame(prop.table(table(sobj$day, sobj$cell_type),
                                     margin = 1))
write.csv(comp_day, file.path(resdir, "GSE313043_composition_day.csv"),
          row.names = FALSE)

# hub localisation with corrected labels
lists <- readRDS(file.path(resdir, "consensus_gene_lists.rds"))
w <- readRDS(file.path(resdir, "GSE335924_WGCNA.rds"))
hub <- unique(c(head(lists$cs_up, 60), head(lists$cs_dn, 30),
                head(w$gene_tab$gene[w$gene_tab$module == 1], 20)))
hub <- intersect(hub, rownames(sobj))
pct <- sapply(unique(sobj$cell_type), function(ct) {
  cells <- which(sobj$cell_type == ct)
  rowMeans(expr_data[hub, cells, drop = FALSE] > 0)
})
write.csv(as.data.frame(pct), file.path(resdir,
          "GSE313043_hub_pct_expressing.csv"))
saveRDS(sobj, file.path(resdir, "GSE313043_seurat.rds"))
cat("\nGSE313043 re-annotation done\n")
