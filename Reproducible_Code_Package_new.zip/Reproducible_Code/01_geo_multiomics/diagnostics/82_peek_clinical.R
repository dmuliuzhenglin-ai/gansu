# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 探查临床结果文件字段
c <- PATHS$clinical_src
peek <- function(f) {
  cat("\n##########", f, "##########\n")
  fp <- file.path(c, f)
  if (!file.exists(fp)) { cat("(missing)\n"); return(invisible()) }
  d <- read.csv(fp, check.names = FALSE)
  cat("dim:", dim(d), "\n"); print(d)
}
peek("02_结果汇总.csv")
peek("02b_结果汇总.csv")
peek("01_primary_summary.csv")
peek("Table4_MIMIC_GCS分层.csv")
peek("03_亚组CATE.csv")
peek("04_敏感性汇总.csv")
peek("03_ml_summary.csv")
peek("22_ML分析汇总.csv")
peek("E2_结果汇总.csv")
peek("E2b_结果汇总.csv")
peek("N2_结果汇总.csv")
