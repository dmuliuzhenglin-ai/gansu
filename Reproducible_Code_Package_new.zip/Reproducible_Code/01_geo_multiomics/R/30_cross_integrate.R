# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 30_cross_integrate.R
# Cross-dataset DEG integration across four bulk transcriptome studies.
# Two evidence families:
#   (1) cross-sectional disease vs healthy control (335924 PBMC; 163256 monos/neuts)
#   (2) longitudinal later vs early (296792 72h/7day; 125512 second)
suppressPackageStartupMessages(library(dplyr))
root <- PATHS$project
resdir <- file.path(root, "02_results")

# ---- 1. harmonised long table of significant DEGs ----
d335 <- read.csv(file.path(resdir, "GSE335924_DEG_all.csv"))
d335 <- d335 %>% filter(regulation %in% c("up","down")) %>%
  transmute(dataset="GSE335924", evidence="cross_section",
            unit="GSE335924_PBMC", gene, logFC, FDR,
            direction=regulation)

d296 <- read.csv(file.path(resdir, "GSE296792_DEG_all.csv"))
d296 <- d296 %>% filter(regulation %in% c("up","down")) %>%
  transmute(dataset="GSE296792", evidence="longitudinal",
            unit=paste0("GSE296792_", contrast), gene, logFC,
            FDR=adj.P.Val, direction=regulation)

d125 <- read.csv(file.path(resdir, "GSE125512_DEG_all.csv"))
d125 <- d125 %>% filter(regulation %in% c("up","down")) %>%
  transmute(dataset="GSE125512", evidence="longitudinal",
            unit="GSE125512_second_vs_first", gene, logFC, FDR,
            direction=regulation)

d163 <- read.csv(file.path(resdir, "GSE163256_DEG_baseline.csv"))
d163 <- d163 %>% filter(regulation %in% c("up","down")) %>%
  transmute(dataset="GSE163256", evidence="cross_section",
            unit=paste0("GSE163256_", cell), gene, logFC, FDR,
            direction=regulation)

long <- bind_rows(d335, d163, d296, d125)
write.csv(long, file.path(resdir, "cross_DEG_long.csv"), row.names=FALSE)
cat("total significant DEG rows:", nrow(long), "\n")
print(table(long$unit, long$direction))

# ---- 2. consensus per evidence family ----
build_consensus <- function(dat) {
  units <- sort(unique(dat$unit))
  # one direction call per gene-unit (a gene appears once per unit)
  wide <- expand.grid(gene = sort(unique(dat$gene)),
                      unit = units, stringsAsFactors = FALSE)
  wide <- wide %>%
    left_join(dat %>% select(gene, unit, direction), by = c("gene","unit"))
  sm <- wide %>% group_by(gene) %>%
    summarise(n_units = length(units),
              n_up   = sum(direction == "up", na.rm = TRUE),
              n_down = sum(direction == "down", na.rm = TRUE),
              .groups = "drop") %>%
    mutate(consensus = case_when(
      n_up >= 2 & n_down == 0  ~ "consensus_up",
      n_down >= 2 & n_up == 0  ~ "consensus_down",
      n_up >= 1 | n_down >= 1  ~ "single_evidence",
      TRUE                     ~ "none"))
  sm %>% arrange(desc(n_up), desc(n_down))
}

cs <- build_consensus(long %>% filter(evidence == "cross_section"))
lg <- build_consensus(long %>% filter(evidence == "longitudinal"))
write.csv(cs, file.path(resdir, "cross_section_consensus.csv"), row.names=FALSE)
write.csv(lg, file.path(resdir, "longitudinal_consensus.csv"), row.names=FALSE)

cat("\n--- cross-sectional consensus (ICH vs HC) ---\n"); print(table(cs$consensus))
cat("\n--- longitudinal consensus (later vs early) ---\n"); print(table(lg$consensus))

cat("\nconsensus UP (cross-section):\n")
print(head(cs$gene[cs$consensus=="consensus_up"], 30))
cat("\nconsensus DOWN (cross-section):\n")
print(head(cs$gene[cs$consensus=="consensus_down"], 30))
cat("\nconsensus UP (longitudinal):\n")
print(head(lg$gene[lg$consensus=="consensus_up"], 30))

# save gene lists for enrichment
saveRDS(list(
  cs_up = cs$gene[cs$consensus=="consensus_up"],
  cs_dn = cs$gene[cs$consensus=="consensus_down"],
  lg_up = lg$gene[lg$consensus=="consensus_up"],
  lg_dn = lg$gene[lg$consensus=="consensus_down"]),
  file.path(resdir, "consensus_gene_lists.rds"))
cat("\ncross integration done\n")
