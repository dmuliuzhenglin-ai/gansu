# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 查看两个 rds 结构以复用表达矩阵
r296 <- readRDS(file.path(PATHS$project, "02_results/GSE296792_limma.rds"))
cat("GSE296792 rds:\n"); print(names(r296))
for (k in names(r296)) {
  cat("---", k, ":", class(r296[[k]]), "\n")
  if (is.matrix(r296[[k]])) cat("dim:", dim(r296[[k]]), "\n")
  if (is.data.frame(r296[[k]])) cat("dim:", dim(r296[[k]]), "cols:",
                                    head(names(r296[[k]]), 8), "\n")
}
