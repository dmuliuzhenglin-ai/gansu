# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R",
                "../../../config_paths.R", "../../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# Reproduction test: does the published forest (ATE -0.0568, n=1857,
# GCS <8 CATE -0.1595) come from an adherent-only analysis set?
suppressMessages({
  library(data.table); library(glmnet); library(grf)
})
set.seed(2026)
dir_mimic <- PATHS$mimic
dir_clin  <- PATHS$clinical

dat <- fread(file.path(dir_clin, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"), select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"), select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, race4 := fcase(grepl("WHITE", race, ignore.case = TRUE), "White",
                     grepl("BLACK", race, ignore.case = TRUE), "Black",
                     grepl("ASIAN", race, ignore.case = TRUE), "Asian", default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4 := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")
gcs_raw <- dat$gcs_total
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, paste0(num_vars, "_miss")),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]

G <- 48
cl <- rbind(dat[, .(stay_id, subject_id, src_row = .I, arm = "early", first_px_hrs)],
            dat[, .(stay_id, subject_id, src_row = .I, arm = "delayed", first_px_hrs)])
cl[, t_div := fifelse(!is.na(first_px_hrs) & first_px_hrs <= G, first_px_hrs, G)]
cl[, adherent := fcase(arm == "early" & !is.na(first_px_hrs) & first_px_hrs <= G, 1L,
                       arm == "delayed" & (is.na(first_px_hrs) | first_px_hrs > G), 1L,
                       default = 0L)]
cl[, Y := as.integer(dat[["hosp_mort"]][src_row])]
cl[, t_ev := dat[["death_hrs"]][src_row]]
cl[, ev_before_div := as.integer(!is.na(t_ev) & t_ev <= t_div)]

cat(sprintf("DIAG adherent total=%d early=%d delayed=%d\n",
            sum(cl$adherent), sum(cl$adherent[cl$arm == "early"]),
            sum(cl$adherent[cl$arm == "delayed"])))
cat(sprintf("DIAG ev_before_div total=%d\n", sum(cl$ev_before_div)))
cat(sprintf("DIAG unemployed (neither)=%d\n", sum(cl$adherent == 0 & cl$ev_before_div == 0)))

Xall <- X_mm[cl$src_row, , drop = FALSE]
arm_all <- as.integer(cl$arm == "early")
p_all <- rep(NA_real_, nrow(cl))
for (a in 0:1) {
  idx <- which(arm_all == a)
  fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx], family = "binomial", nfolds = 5)
  p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE], s = "lambda.min", type = "response"))
}
p_all <- pmax(p_all, 0.01)
stab <- ave(cl$adherent, cl$arm, FUN = mean)
w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
w_all[cl$ev_before_div == 1] <- 1
pos <- cl$adherent == 1 & cl$ev_before_div == 0
qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])

run_set <- function(label, keep) {
  X <- Xall[keep, , drop = FALSE]; Y <- cl$Y[keep]; W <- arm_all[keep]
  w <- w_all[keep]; clu <- cl$subject_id[keep]
  cf <- causal_forest(X, Y, W, sample.weights = w, clusters = clu, num.trees = 2000, seed = 2026)
  a <- average_treatment_effect(cf)
  src <- cl$src_row[keep]; g <- dat$gcs_total[src]
  cat(sprintf("\n[%s] n=%d ate=%.4f (se %.4f)\n", label, length(Y), a[1], a[2]))
  for (nm in c("legacy", "prespec")) {
    bins <- if (nm == "legacy") list(lt8 = g < 8, b812 = g >= 8 & g <= 12, ge13 = g >= 13)
            else list(g38 = g >= 3 & g <= 8, g912 = g >= 9 & g <= 12, g1315 = g >= 13 & g <= 15)
    for (b in names(bins)) {
      i <- which(bins[[b]])
      e <- average_treatment_effect(cf, subset = i)
      cat(sprintf("  %-8s %-8s n=%4d cate=%+.4f (%.4f to %.4f)\n",
                  nm, b, length(i), e[1], e[1] - 1.96 * e[2], e[1] + 1.96 * e[2]))
    }
  }
}

run_set("adherent_only", which(cl$adherent == 1))
run_set("adherent_plus_dead", which(cl$adherent == 1 | cl$ev_before_div == 1))
cat("\ndone\n")
