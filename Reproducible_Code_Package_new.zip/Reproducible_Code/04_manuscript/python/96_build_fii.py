# --- shared path configuration; edit config_paths.py for your local machine ---
import os as _os, sys as _sys
for _cf in ("config_paths.py", "../../config_paths.py", "../config_paths.py",
            "../../../config_paths.py", "../../../../config_paths.py"):
    if _os.path.exists(_cf):
        _d = _os.path.dirname(_os.path.abspath(_cf))
        if _d not in _sys.path:
            _sys.path.insert(0, _d)
        import config_paths as _cp
        PATHS = _cp.PATHS
        break
# -*- coding: utf-8 -*-
"""
96_build_fii.py
Build a Frontiers in Immunology submission DOCX from Manuscript_integrated.docx.

Differences from the IJMS build (94_build_ijms.py):
- Immunology-first Results: multi-omics myeloid program (3.1-3.8) precedes the
  clinical target-trial evidence (3.9-3.12); Methods moved before Results
  (Frontiers order: Introduction -> Materials and methods -> Results ->
  Discussion -> Conclusion).
- Figures renumbered by first citation: 1 transcriptome, 2 network/immune,
  3 single-cell, 4 epigenetic/miRNA, 5 concept map, 6 cohort flow,
  7 clinical effects. Supplementary S1-S4 unchanged.
- Tables: Table 1-4 in main text with captions and footnotes restored;
  the three-database overview becomes Supplementary Table S1.
- In-text citations converted from superscript numerals to [n].
- Frontiers-style numbered references.

Deterministic and re-runnable.
"""
import copy
import csv
import re
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ---------------------------------------------------------------- paths
ROOT = PATHS["project"]
SRC = ROOT + r"\04_manuscript\Manuscript_integrated.docx"
OUT = ROOT + r"\04_manuscript\Manuscript_Frontiers_Immunology.docx"
FIG = ROOT + r"\03_figures"
OLDM = ROOT + r"\04_manuscript\_old_media"

src = Document(SRC)
sp = src.paragraphs
doc = Document()

# ---------------------------------------------------------------- styles
NORMAL_FONT = "Times New Roman"
HEADING_COLOR = RGBColor(0x1F, 0x1F, 0x1F)


def set_base_style():
    st = doc.styles["Normal"]
    st.font.name = NORMAL_FONT
    st.font.size = Pt(10.5)
    rpr = st.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for k in ("ascii", "hAnsi", "eastAsia"):
        rfonts.set(qn("w:" + k), NORMAL_FONT)
    for hname, sz in [("Heading 1", 13), ("Heading 2", 11.5)]:
        hs = doc.styles[hname]
        hs.font.name = NORMAL_FONT
        hs.font.size = Pt(sz)
        hs.font.bold = True
        hs.font.color.rgb = HEADING_COLOR
        hrpr = hs.element.get_or_add_rPr()
        hf = hrpr.find(qn("w:rFonts"))
        if hf is None:
            hf = OxmlElement("w:rFonts")
            hrpr.append(hf)
        for theme_attr in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
            if hf.get(qn("w:" + theme_attr)) is not None:
                del hf.attrib[qn("w:" + theme_attr)]
        for k in ("ascii", "hAnsi", "eastAsia"):
            hf.set(qn("w:" + k), NORMAL_FONT)


set_base_style()


# ---------------------------------------------------------------- helpers
def h1(text):
    p = doc.add_paragraph(style="Heading 1")
    p.add_run(text)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    return p


def h2(text):
    p = doc.add_paragraph(style="Heading 2")
    p.add_run(text)
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    return p


def body(text, justify=True):
    p = doc.add_paragraph(style="Normal")
    p.add_run(text)
    if justify:
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(4)
    return p


def center(text, bold=False, size=None):
    p = doc.add_paragraph(style="Normal")
    r = p.add_run(text)
    r.bold = bold
    if size:
        r.font.size = Pt(size)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p


def add_figure(path, width_cm=15.5):
    p = doc.add_paragraph(style="Normal")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    p.add_run().add_picture(path, width=Cm(width_cm))
    return p


def caption(text):
    p = doc.add_paragraph(style="Normal")
    r = p.add_run(text)
    r.font.size = Pt(9)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(10)
    return p


def small_note(text):
    p = doc.add_paragraph(style="Normal")
    r = p.add_run(text)
    r.font.size = Pt(8.5)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(1)
    return p


def table_caption(text):
    """Table caption placed ABOVE the table."""
    p = doc.add_paragraph(style="Normal")
    r = p.add_run(text)
    r.font.size = Pt(9)
    r.bold = True
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(3)
    return p


def add_table(src_index, cap_text, notes, cap_below=None):
    """Place caption, table and footnotes together, in that order, at the anchor."""
    cap_p = table_caption(cap_text)
    tbl_xml = copy.deepcopy(src.tables[src_index]._tbl)
    cap_p._p.addnext(tbl_xml)
    # repeat the header row when the table breaks across pages
    first_row = tbl_xml.findall(qn("w:tr"))[0]
    trpr = first_row.find(qn("w:trPr"))
    if trpr is None:
        trpr = OxmlElement("w:trPr")
        first_row.insert(0, trpr)
    th = OxmlElement("w:tblHeader")
    trpr.append(th)
    anchor = tbl_xml
    for n in list(notes) + list(cap_below or []):
        np_ = small_note(n)
        anchor.addnext(np_._p)
        anchor = np_._p
    return tbl_xml

# ---------------------------------------------------------------- Supplementary Table S2
RES_DIR = ROOT + r"\05_bridge_immune\02_results"
DAT_DIR = ROOT + r"\05_bridge_immune\01_data"

METRIC_LABEL = {
    "alc": "ALC (K/uL)",
    "nlr": "NLR",
    "mono_pct": "Monocytes (%)",
}


def fmt_n(v):
    try:
        return "{:,}".format(int(float(v)))
    except (TypeError, ValueError):
        return str(v)
WIN_LABEL = {"W0": "0-24 h", "W24": "24-48 h", "W48": "48-72 h", "W72": "72-96 h"}


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def fmt_p(v):
    if v in ("", "NA", None):
        return "-"
    p = float(v)
    if p < 0.0001:
        return "<0.0001"
    if p < 0.001:
        return "%.4f" % p
    return "%.3f" % p


def fmt_ci(est, lo, hi, sign=False):
    f = "%+.2f" if sign else "%.2f"
    return (f + " (%.2f to %.2f)") % (float(est), float(lo), float(hi))


def s2_row(tbl, cells, bold=False, fill=None, merge=False):
    row = tbl.add_row()
    rc = row.cells
    if merge:
        rc[0].merge(rc[-1])
        targets = [rc[0]]
    else:
        targets = list(rc)
    for i, txt in enumerate(cells):
        if i >= len(targets):
            break
        cell = targets[i]
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.space_after = Pt(1)
        p.paragraph_format.first_line_indent = Cm(0)
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 0 else WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(txt))
        r.font.size = Pt(8)
        r.bold = bold
        if fill is not None:
            tcPr = cell._tc.get_or_add_tcPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:val"), "clear")
            shd.set(qn("w:fill"), fill)
            tcPr.append(shd)
    return row


def build_table_s2():
    """Supplementary Table S2, generated from the bridge-analysis result files."""
    cap_p = table_caption(
        "Table S2. Peripheral-blood leukocyte trajectories, exposure-time interactions and the "
        "albumin-bilirubin gradient in the eICU-CRD cohort, with a cross-sectional comparison in "
        "MIMIC-IV.")
    tbl = doc.add_table(rows=0, cols=6)
    tbl.style = "Table Grid"
    tbl.autofit = False
    cap_p._p.addnext(tbl._tbl)
    s2_row(tbl, ["Measure", "Window", "Group", "n", "Estimate (95% CI)", "P"], bold=True,
           fill="EDEDED")
    trpr = OxmlElement("w:trPr")
    trpr.append(OxmlElement("w:tblHeader"))
    tbl.rows[0]._tr.insert(0, trpr)

    traj = read_csv(RES_DIR + r"\eicu_trajectory.csv")
    mixed = read_csv(RES_DIR + r"\eicu_mixed_model.csv")
    delta = read_csv(RES_DIR + r"\eicu_delta.csv")
    albi = read_csv(RES_DIR + r"\albi_results.csv")
    cross = read_csv(RES_DIR + r"\mimic_crosssec.csv")
    base = read_csv(DAT_DIR + r"\eicu_bridge_baseline.csv")

    s2_row(tbl, ["A. Trajectories in eICU-CRD (inverse-probability-weighted means)"],
           bold=True, fill="F2F2F2", merge=True)
    for m in ("alc", "nlr", "mono_pct"):
        for w in ("W0", "W24", "W48", "W72"):
            for e, g in (("1", "Early"), ("0", "Delayed")):
                r = [x for x in traj if x["metric"] == m and x["win_f"] == w
                     and x["early"] == e][0]
                s2_row(tbl, [METRIC_LABEL[m], WIN_LABEL[w], g,
                             fmt_n(r["n"]), fmt_ci(r["est"], r["lo"], r["hi"]), "-"])

    s2_row(tbl, ["B. Exposure-time interaction (reference: window 0-24 h)"],
           bold=True, fill="F2F2F2", merge=True)
    for m in ("alc", "nlr", "mono_pct"):
        for w in ("W24", "W48", "W72"):
            r = [x for x in mixed if x["metric"] == m and x["term"] == "early:win_f" + w][0]
            s2_row(tbl, [METRIC_LABEL[m], WIN_LABEL[w],
                         "Early \u00d7 window", "-",
                         fmt_ci(r["est"], r["lo"], r["hi"], True), fmt_p(r["p"])])

    s2_row(tbl, ["C. Change from baseline to 48-72 h (48 h minus 0 h, cluster bootstrap)"],
           bold=True, fill="F2F2F2", merge=True)
    for r in delta:
        s2_row(tbl, [METRIC_LABEL[r["metric"]], "48 h - 0 h", "Early - delayed",
                     "%s (%s)" % (fmt_n(r["n"]), fmt_n(r["n_early"])),
                     fmt_ci(r["diff"], r["diff_lo"], r["diff_hi"], True), "-"])

    s2_row(tbl, ["D. Albumin-bilirubin (ALBI) score in eICU-CRD"],
           bold=True, fill="F2F2F2", merge=True)
    vals = [float(x["albi"]) for x in base if x["albi"] not in ("", "NA")]
    n_early_albi = sum(1 for x in base
                       if x["early"] == "1" and x["albi"] not in ("", "NA"))
    n_delay_albi = sum(1 for x in base
                       if x["early"] == "0" and x["albi"] not in ("", "NA"))
    for g, n_g in (("Early", n_early_albi), ("Delayed", n_delay_albi)):
        r = [x for x in albi if x["analysis"] == "albi_by_group"
             and x["term"].lower() == g.lower()][0]
        s2_row(tbl, ["ALBI score", "Baseline", g, fmt_n(n_g), "%.2f" % float(r["est"]), "-"])

    import numpy as np
    rows = [(float(x["albi"]), int(float(x["hosp_mort"]))) for x in base
            if x["albi"] not in ("", "NA") and x["hosp_mort"] not in ("", "NA")]
    vals = [v for v, _ in rows]
    q1, q2 = np.quantile(vals, [1 / 3, 2 / 3])
    def _m(v):
        return ("%.2f" % v).replace("-", "\u2212")

    terr = [("T1: \u2264 %s" % _m(q1), [t for t in rows if t[0] <= q1]),
            ("T2: %s to %s" % (_m(q1), _m(q2)),
             [t for t in rows if q1 < t[0] <= q2]),
            ("T3: > %s" % _m(q2), [t for t in rows if t[0] > q2])]
    for lab, subset in terr:
        n_k = len(subset)
        d_k = sum(m for _, m in subset)
        s2_row(tbl, ["In-hospital mortality", "Baseline", lab, fmt_n(n_k),
                     "%.1f%%" % (100.0 * d_k / n_k), "-"])

    r = [x for x in albi if x["analysis"] == "albi_mortality" and x["term"] == "albi"][0]
    s2_row(tbl, ["ALBI, adjusted odds ratio per unit", "Baseline", "All stays", "1,209",
                 fmt_ci(r["OR"], r["OR_lo"], r["OR_hi"]), fmt_p(r["p"])])
    s2_row(tbl, ["ALBI vs 72-96 h lymphocyte count (Spearman rho)", "72-96 h", "All stays",
                 "418", "-0.18", "0.0002"])

    s2_row(tbl, ["E. Cross-sectional comparison in MIMIC-IV at the first window"],
           bold=True, fill="F2F2F2", merge=True)
    for m in ("alc", "nlr", "mono_pct"):
        for e, g in (("1", "Early"), ("0", "Delayed")):
            rows = [x for x in cross if x["metric"] == m and x["win"] == "W0"
                    and x["early"] == e]
            if not rows:
                continue
            r = rows[0]
            s2_row(tbl, [METRIC_LABEL[m], "0-24 h", g, fmt_n(r["n"]),
                         "%.2f (SD %.2f)" % (float(r["mean"]), float(r["sd"])), "-"])

    widths = [Cm(4.3), Cm(1.5), Cm(3.3), Cm(1.8), Cm(3.2), Cm(1.6)]
    for c, w in zip(tbl.columns, widths):
        for cell in c.cells:
            cell.width = w

    notes = [
        "Values are means with analytic 95% confidence intervals unless stated otherwise. P values "
        "in panel B are for the exposure-by-window interaction term of linear mixed models with "
        "stay-level and hospital-level random intercepts, adjusted for the baseline value, age, "
        "Glasgow Coma Scale, mechanical ventilation, neurosurgical procedure, platelet count, "
        "creatinine, hemoglobin, chronic kidney disease and liver disease, and weighted by "
        "stabilized inverse-probability-of-treatment weights truncated at the 1st and 99th percentiles.",
        "Window 0-24 h covers -6 to 24 h after ICU admission and contributes the value closest to "
        "time zero; each later window covers the preceding 24 h and contributes the mean of the "
        "available values. Time zero is ICU admission.",
        "Absolute lymphocyte count in eICU-CRD was derived as the white-cell count (K/uL) multiplied "
        "by the lymphocyte percentage, because eICU-CRD does not report an absolute lymphocyte count "
        "directly. MIMIC-IV contributed a directly measured absolute count.",
        "In panel C, n is the number of stays with paired samples at both windows and the number in "
        "parentheses is the number of early-prophylaxis stays among them.",
        "ALBI = (0.66 \u00d7 log10 total bilirubin [mg/dL]) - (0.085 \u00d7 albumin [g/dL]). Tertile cut-points "
        "are the 33rd and 67th percentiles of the 1,209 stays with both ALBI and mortality (T1, "
        "lowest tertile; T3, highest); the odds ratio is adjusted for age, Glasgow Coma Scale and "
        "mechanical ventilation.",
        "Panel E reports unweighted mean (SD) in MIMIC-IV; later windows had fewer than 35 "
        "early-prophylaxis stays and were therefore not analyzed longitudinally.",
    ]
    anchor = tbl._tbl
    for n in notes:
        np_ = small_note(n)
        anchor.addnext(np_._p)
        anchor = np_._p
    return tbl

# ---------------------------------------------------------------- figure maps
# source call-out -> new numbering, keyed by the SOURCE paragraph section
MECH_FIG_MAP = {
    "Figure 2": "Figure 1",
    "Figure 3": "Figure 2",
    "Figure 4": "Figure 3",
    "Figure 5": "Figure 4",
    "Figure 6": "Figure 5",
}
CLINICAL_FIG_MAP = {
    "Figure 1": "Figure 6",   # cohort flow
    "Figure 2": "Figure S1",  # subgroup CATE forest -> supplementary
    "Figure 3": "Figure S2",  # grace-period timing gradient -> supplementary
    "Figure S1": "Figure S3", # dose-response
    "Figure S2": "Figure S4", # all-estimator forest
}


def renumber(text, mp):
    def repl(m):
        return mp.get(re.sub(r"\s+", " ", m.group(0)), m.group(0))
    return re.sub(r"Figure\s*S?\d+", repl, text)


def emit(idx, fig_map=None):
    """Copy a source paragraph; superscript citations -> [n]; renumber figures."""
    srcp = sp[idx]
    style_name = srcp.style.name
    if style_name in ("Heading 1", "Heading 2"):
        text = renumber(srcp.text, fig_map) if fig_map else srcp.text
        return h1(text) if style_name == "Heading 1" else h2(text)

    p = doc.add_paragraph(style="Normal")
    for r in srcp.runs:
        t = r.text
        if not t:
            continue
        if r.font.superscript and t.strip():
            t = "[" + t.strip() + "]"
        elif fig_map is not None:
            t = renumber(t, fig_map)
        nr = p.add_run(t)
        nr.bold = r.bold
        nr.italic = r.italic
        if r.font.size:
            nr.font.size = r.font.size
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(4)
    return p


def emit_strip(idx, prefix):
    """Emit a source paragraph with a leading label removed."""
    srcp = sp[idx]
    text = srcp.text
    if text.startswith(prefix):
        text = text[len(prefix):].lstrip()
    p = doc.add_paragraph(style="Normal")
    p.add_run(text)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(4)
    return p


# ---------------------------------------------------------------- new texts
NEW_TITLE = ("Immunodepressive myeloid reprogramming after intracerebral hemorrhage: "
             "multi-omics mechanisms and a three-database target trial of early "
             "venous thromboembolism prophylaxis")

NEW_ABSTRACT = (
    "Intracerebral hemorrhage (ICH) triggers a systemic immune response whose molecular "
    "architecture and clinical relevance remain poorly defined, and whether early "
    "pharmacological venous thromboembolism (VTE) prophylaxis modifies that response is "
    "unknown. We integrated a multi-omics analysis of nine human GEO accessions with a "
    "target trial emulation of early (within 48 h) versus delayed prophylaxis in three "
    "critical care databases (MIMIC-IV, n=2,080; eICU-CRD, n=2,580; NWICU, n=558). "
    "Across four bulk transcriptomic cohorts, ICH produced a conserved program of "
    "neutrophil and monocyte activation coupled to suppression of antigen presentation, "
    "with MHC class II genes (HLA-DRA, HLA-DQB1, CD74) and their transactivator CIITA "
    "among the most consistently downregulated transcripts. Consensus over-representation "
    "analysis separated this program into an inflammatory arm (neutrophil degranulation, "
    "Toll-like receptor and NF-kB signalling) and an immunodepressive arm (MHC class II "
    "antigen presentation, T-cell co-stimulation and immunoglobulin gene sets). A "
    "co-expression module enriched for myeloid and interferon genes tracked the ICH state, "
    "immune deconvolution localized the shift to neutrophils and monocytes, and single-cell "
    "transcriptomes from three independent datasets placed the hub genes in neutrophils, "
    "microglia and endothelial cells rather than lymphocytes. Gene-level methylation and "
    "an exploratory microRNA network provided additional but non-conclusive regulatory "
    "support. In the emulated trial, early prophylaxis was associated with lower in-hospital "
    "mortality (MIMIC-IV risk difference -4.2 percentage points, 95% CI -6.0 to -2.4; "
    "eICU -3.5, -7.1 to -0.6) without increased hematoma expansion, and the benefit was "
    "concentrated in patients with Glasgow Coma Scale 3-8, although recorded VTE did not "
    "decrease and a null instrumental-variable estimate, together with residual confounding, "
    "precludes a causal reading. Routine differential counts, available for up to 2,405 ICU "
    "stays, showed a transient neutrophil-dominant peak at 24-48 h and, in the early group, "
    "lymphocyte counts that rose toward the delayed-group level after 48 h, without evidence "
    "of a persistent immunodepressive shift. The two lines of evidence jointly motivate one "
    "testable proposition: early prophylaxis may limit hematoma-driven amplification of an "
    "immunodepressive myeloid program, which prospective monocyte HLA-DR profiling can now "
    "address directly.")

NEW_KEYWORDS = ("intracerebral hemorrhage; immunosuppression; myeloid cells; MHC class II; "
                "single-cell RNA sequencing; multi-omics; venous thromboembolism; "
                "target trial emulation")

CAP = {
    1: ("Figure 1. Consensus transcriptomic response to intracerebral hemorrhage. Per-unit "
        "differentially expressed gene counts, cross-sectional and longitudinal consensus "
        "log-fold changes, and consensus over-representation across GO and KEGG. DEG, "
        "differentially expressed gene; FC, fold change; GO, Gene Ontology; KEGG, Kyoto "
        "Encyclopedia of Genes and Genomes."),
    2: ("Figure 2. Co-expression and immune deconvolution. WGCNA module-trait correlations, "
        "module-1 hub genes, and ssGSEA immune shifts. WGCNA, weighted gene co-expression "
        "network analysis; ssGSEA, single-sample gene set enrichment analysis; kME, "
        "eigengene connectivity."),
    3: ("Figure 3. Single-cell composition across three datasets and hub-gene localisation "
        "across cell types. scRNA-seq, single-cell RNA sequencing."),
    4: ("Figure 4. Gene-level methylation, methylation-expression links, and the exploratory "
        "microRNA regulatory network. DMP, differentially methylated probe; miRNA, "
        "microRNA."),
    5: ("Figure 5. Integrated mechanistic concept map linking the clinical effect to cellular "
        "and molecular programmes."),
    6: ("Figure 6. Cohort flow diagram across the three databases (MIMIC-IV, eICU-CRD v2.0, "
        "NWICU), showing eligibility, exclusions and final analytic cohorts. ICU, intensive "
        "care unit; ICH, intracerebral hemorrhage; VTE, venous thromboembolism."),
    7: ("Figure 7. Clinical effect of early versus delayed prophylaxis across the three "
        "databases: inverse-probability-weighted risk differences and risk ratios for "
        "in-hospital mortality, GCS strata, and multi-method robustness. IPCW, "
        "inverse-probability-of-censoring weighting; RD, risk difference; RR, risk ratio."),
    8: ("Figure 8. Peripheral immune trajectories after early versus delayed prophylaxis and "
        "the prognostic gradient of the albumin-bilirubin (ALBI) score. Inverse-probability-"
        "weighted means with 95% confidence intervals for absolute lymphocyte count (A), "
        "neutrophil-to-lymphocyte ratio (B) and monocyte fraction (C) across 24-h windows from "
        "ICU admission (eICU-CRD). Absolute lymphocyte count was derived as white-cell count "
        "multiplied by lymphocyte percentage. (D) In-hospital mortality by baseline ALBI "
        "tercile; bars show proportions with Wilson 95% confidence intervals. NLR, "
        "neutrophil-to-lymphocyte ratio; ALBI, albumin-bilirubin score."),
    "S1": ("Figure S1. Exploratory subgroup treatment-effect estimates (conditional average "
           "treatment effects from a causal forest fitted to the clone set, MIMIC-IV; 2,303 "
           "retained clones from 2,080 patients). Points are risk differences in percentage "
           "points (early minus delayed); horizontal lines are 95% confidence intervals. GCS "
           "strata are the pre-specified 3-8, 9-12 and 13-15 bins used in Table 3; n counts "
           "retained clones, and one patient can contribute up to two. These estimates are "
           "model-based, were not used for inference, and do not reproduce the Hajek-weighted "
           "inverse-probability estimates in Table 3, which are the pre-specified analysis."),
    "S2": ("Figure S2. Timing gradient of the prophylaxis effect across grace periods (24, "
           "48, 72 h) in the three databases, comparing IPCW Horvitz-Thompson and "
           "cross-fitted AIPW estimators. AIPW, augmented inverse-probability weighting."),
    "S3": ("Figure S3. Dose-response association by timing of the first prophylactic dose "
           "(hours since ICU admission) in eICU-CRD and NWICU. Points are risk differences "
           "in percentage points; bars are 95% confidence intervals."),
    "S4": ("Figure S4. Forest plot of in-hospital mortality risk differences across databases "
           "and estimators (48-h grace period), including overlap weighting and "
           "transportability-standardized estimates. ATO, average treatment effect in the "
           "overlap."),
}

FIG_FILE = {
    1: FIG + r"\Figure2_transcriptome.png",
    2: FIG + r"\Figure3_network_immune.png",
    3: FIG + r"\Figure4_singlecell.png",
    4: FIG + r"\Figure5_epigenetic_network.png",
    5: FIG + r"\Figure6_concept_map.png",
    6: OLDM + r"\image1.png",
    7: FIG + r"\Figure1_clinical_effects.png",
    8: FIG + r"\Figure8_immune_trajectory.png",
}
SFIG_FILE = {
    "S1": FIG + r"\FigureS1_subgroup_cate.png",
    "S2": OLDM + r"\image3.png",
    "S3": OLDM + r"\image4.png",
    "S4": FIG + r"\FigureS4_forest.png",
}

# ---------------------------------------------------------------- references
REFS = [
 "van Asch CJ, Luitse MJ, Rinkel GJ, van der Tweel I, Algra A, Klijn CJ. Incidence, case fatality, and functional outcome of intracerebral haemorrhage over time, according to age, sex, and ethnic origin: a systematic review and meta-analysis. Lancet Neurol. (2010) 9:167-176.",
 "Ding D, Sekar P, Moomaw CJ, Comeau ME, James ML, Testai F, et al. Venous thromboembolism in patients with spontaneous intracerebral hemorrhage: a multicenter study. Neurosurgery (2019) 84:E304-E310.",
 "Lacut K, Bressollette L, Le Gal G, Etienne E, De Tinteniac A, Renault A, et al. Prevention of venous thrombosis in patients with acute intracerebral hemorrhage. Neurology (2005) 65:865-869.",
 "Al-Shahi Salman R, Frantzias J, Lee RJ, Lyden PD, Battey TWK, Ayres AM, et al. Absolute risk and predictors of the growth of acute spontaneous intracerebral haemorrhage: a systematic review and meta-analysis of individual patient data. Lancet Neurol. (2018) 17:885-894.",
 "Greenberg SM, Ziai WC, Cordonnier C, Dowlatshahi D, Francis B, Goldstein JN, et al. 2022 Guideline for the management of patients with spontaneous intracerebral hemorrhage: a guideline from the American Heart Association/American Stroke Association. Stroke (2022) 53:e282-e361.",
 "Nyquist P, Bautista C, Jichici D, Burns J, Chhangani S, DeFilippis M, et al. Prophylaxis of venous thrombosis in neurocritical care patients: an evidence-based guideline. Neurocrit. Care (2016) 24:47-60.",
 "Dickmann U, Voth E, Schicha H, Henze T, Prange H, Emrich D. Heparin therapy, deep-vein thrombosis and pulmonary embolism after intracerebral hemorrhage. Klin. Wochenschr. (1988) 66:1182-1183.",
 "Boeer A, Voth E, Henze T, Prange HW. Early heparin therapy in patients with spontaneous intracerebral haemorrhage. J. Neurol. Neurosurg. Psychiatry (1991) 54:466-467.",
 "Orken DN, Kenangil G, Ozkurt H, Guner C, Gundogdu L, Basak M, et al. Prevention of deep venous thrombosis and pulmonary embolism in patients with acute intracerebral hemorrhage. Neurologist (2009) 15:329-331.",
 "Tetri S, Hakala J, Juvela S, Saloheimo P, Pyhtinen J, Rusanen H, et al. Safety of low-dose subcutaneous enoxaparin for the prevention of venous thromboembolism after primary intracerebral haemorrhage. Thromb. Res. (2008) 123:206-212.",
 "Prabhakaran S, Herbers P, Khoury J, Adeoye O, Khatri P, Ferioli S, et al. Is prophylactic anticoagulation for deep venous thrombosis common practice after intracerebral hemorrhage? Stroke (2015) 46:369-375.",
 "Cherian LJ, Smith EE, Schwamm LH, Fonarow GC, Schulte PJ, Xian Y, et al. Current practice trends for use of early venous thromboembolism prophylaxis after intracerebral hemorrhage. Neurosurgery (2018) 82:85-92.",
 "Hernán MA, Robins JM. Using big data to emulate a target trial when a randomized trial is not available. Am. J. Epidemiol. (2016) 183:758-764.",
 "Hernán MA, Sauer BC, Hernandez-Diaz S, Platt R, Shrier I. Specifying a target trial prevents immortal time bias and other self-inflicted injuries in observational analyses. J. Clin. Epidemiol. (2016) 79:70-75.",
 "Maringe C, Benitez Majano S, Exarchakou A, Smith M, Rachet B, Belot A, et al. Reflection on modern methods: trial emulation in the presence of immortal-time bias. Int. J. Epidemiol. (2020) 49:1719-1729.",
 "Dahabreh IJ, Hernán MA. Extending inferences from a randomized trial to a target population. Eur. J. Epidemiol. (2019) 34:719-722.",
 "Johnson AEW, Bulgarelli L, Shen L, Gayles J, Shammout A, Horng S, et al. MIMIC-IV, a freely accessible electronic health record dataset. Sci. Data (2023) 10:1.",
 "Pollard TJ, Johnson AEW, Raffa JD, Celi LA, Mark RG, Badawi A. The eICU Collaborative Research Database, a freely available multi-center database for critical care research. Sci. Data (2018) 5:180178.",
 "Moukheiber D, Temps W, Molgi B, Li Y, Lu A, Nannapaneni P, et al. Northwestern ICU (NWICU) Database (Version 0.1.0). PhysioNet (2024). https://doi.org/10.13026/s84w-1829.",
 "Johnson AEW, Pollard TJ, Horng S, Celi LA, Mark R. MIMIC-IV-Note: Deidentified Free-Text Clinical Notes (Version 2.2). PhysioNet (2023). Available online: https://physionet.org/content/mimic-iv-note/2.2/ (accessed 20 November 2026).",
 "Hernán MA, Robins JM. Causal Inference: What If. Chapman & Hall/CRC: Boca Raton, FL, USA (2020).",
 "Li F, Morgan KL, Zaslavsky AM. Balancing covariates via propensity score weighting. J. Am. Stat. Assoc. (2018) 113:390-400.",
 "Westreich D, Edwards JK, Lesko CR, Stuart E, Cole SR. Transportability of trial results using inverse odds of sampling weights. Am. J. Epidemiol. (2017) 186:1010-1014.",
 "Imai K, Keele L, Tingley D. A general approach to causal mediation analysis. Psychol. Methods (2010) 15:309-334.",
 "Ianosi B, Gaasch M, Rass V, Huber L, Hackl W, Kofler M, et al. Early thrombosis prophylaxis with enoxaparin is not associated with hematoma expansion in patients with spontaneous intracerebral hemorrhage. Eur. J. Neurol. (2019) 26:333-341.",
 "Paciaroni M, Agnelli G, Venti M, Alberti A, Acciarresi M, Caso V. Efficacy and safety of anticoagulants in the prevention of venous thromboembolism in patients with acute cerebral hemorrhage: a meta-analysis of controlled studies. J. Thromb. Haemost. (2011) 9:893-898.",
 "Chi G, Lee JJ, Sheng S, Marszalek J, Chuang ML. Systematic review and meta-analysis of thromboprophylaxis with heparins following intracerebral hemorrhage. Thromb. Haemost. (2022) 122:1159-1168.",
 "Li H, Wu Z, Zhang H, Qiu B, Wang Y. Low-molecular-weight heparin in the prevention of venous thromboembolism among patients with acute intracerebral hemorrhage: a meta-analysis. PLoS One (2024) 19:e0311858.",
 "Paciaroni M, Agnelli G, Alberti A, Becattini C, Guercini F, Martini G, et al. PREvention of VENous Thromboembolism in Hemorrhagic Stroke Patients - PREVENTIHS Study: a randomized controlled trial and a systematic review and meta-analysis. Eur. Neurol. (2020) 83:566-575.",
 "Chen H, Ji J, Zhang H, Nie E, Lan Q. Early pharmacologic venous thromboembolism prophylaxis and in-hospital mortality in ICU patients with intracerebral hemorrhage. Front. Neurol. (2026) 17:1849021.",
 "Yang ZX, Li ZX, Zhao TQ, Yu K, Zhang L, Xia X. Early pharmacological venous thromboembolism prophylaxis reduces lower limb deep vein thrombosis in surgical patients with severe hypertensive intracerebral hemorrhage. Front. Neurol. (2026) 17:1800147.",
 "Salvagni FP, Palavani LB, Ferreira MY, Andreão FF, dos Santos BB, Jimenez LAC, et al. Timing matters: ultra-early and early versus late thromboprophylaxis following spontaneous intracerebral hemorrhage: a systematic review and meta-analysis. Neurosurg. Rev. (2024) 47:393.",
 "Zhou Y, Wang G, Xue C, He G, Zhang Y, He F, et al. Effect of heparin for the prevention of venous thromboembolism in patients with spontaneous intracranial cerebral hemorrhage: a meta-analysis. Ther. Adv. Drug Saf. (2024) 15:20420986241253469.",
 "Chinese Clinical Trial Registry. ChiCTR2500113625: Prevention of Venous Thromboembolism in Patients with Intracerebral Hemorrhage (POWER) (2025). Available online: http://www.chictr.org.cn/showprojEN.html?proj=297895 (accessed 20 November 2026).",
 "Johnson PJ, Berhane S, Kagebayashi C, Satomura S, Teng M, Reeves HL, et al. Assessment of liver function in patients with hepatocellular carcinoma: a new evidence-based approach - the ALBI grade. J. Clin. Oncol. (2015) 33:550-558.",
 "Meisel C, Schwab JM, Prass K, Meisel A, Dirnagl U. Central nervous system injury-induced immune deficiency syndrome. Nat. Rev. Neurosci. (2005) 6:775-786.",
 "Dirnagl U, Klehmet J, Braun JS, Harms H, Meisel C, Ziemssen T, et al. Stroke-induced immunodepression: experimental evidence and clinical relevance. Stroke (2007) 38:770-773.",
 "Giede-Jeppe A, Bobinger T, Gerner ST, Sembill JA, Sprügel MI, Beuscher VD, et al. Neutrophil-to-lymphocyte ratio is an independent predictor for in-hospital mortality in spontaneous intracerebral hemorrhage. Cerebrovasc. Dis. (2017) 44:26-34.",
]

# renumber so that the list follows the order of first appearance in the text
REFS = REFS[:24] + [REFS[34], REFS[35], REFS[36], REFS[37]] + REFS[24:34]
assert len(REFS) == 38
CITE_MAP = {25: 29, 26: 30, 27: 31, 28: 32, 29: 33, 30: 34, 31: 35,
            32: 36, 33: 37, 34: 38, 35: 25, 36: 26, 37: 27, 38: 28}
CITE_RE = re.compile(r"\[(\d+(?:[,\-]\d+)*)\]")

def _cite_repl(m):
    keep, nums = [], set()
    for t in m.group(1).split(","):
        t = t.strip()
        if "-" in t:
            a, b = [int(x) for x in t.split("-")]
            if b <= 24:
                keep.append(t)
            else:
                nums.update(range(a, b + 1))
        else:
            nums.add(int(t))
    mapped = sorted(CITE_MAP.get(x, x) for x in nums)
    out, i = [], 0
    while i < len(mapped):
        j = i
        while j + 1 < len(mapped) and mapped[j + 1] == mapped[j] + 1:
            j += 1
        out.append(str(mapped[i]) if j == i else "%d-%d" % (mapped[i], mapped[j]))
        i = j + 1
    return "[" + ",".join(keep + out) + "]"

def finalize_citations():
    for p in doc.paragraphs:
        if p.text.startswith("[") and p.text[1:3].strip().rstrip("]").isdigit():
            continue
        for r in p.runs:
            if "[" in r.text and r.text.strip():
                r.text = CITE_RE.sub(_cite_repl, r.text)
    for tb in doc.tables:
        for row in tb.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:
                        if "[" in r.text:
                            r.text = CITE_RE.sub(_cite_repl, r.text)


def _apply(p, k, v):
    """Replace inside a run when possible, otherwise rewrite the whole paragraph."""
    if k not in p.text:
        return
    if any(k in r.text for r in p.runs):
        for r in p.runs:
            if k in r.text:
                r.text = r.text.replace(k, v)
        return
    if not p.runs:
        return
    new = p.text.replace(k, v)
    p.runs[0].text = new
    for r in p.runs[1:]:
        r.text = ""


def finalize_text():
    SPELL = [("meta-analyzes", "meta-analyses"), ("Meta-analyzes", "Meta-analyses"),
             ("analyzes", "analyses"), ("Analyzes", "Analyses"),
             ("centerd", "centered"), ("Centerd", "Centered"),
             ("defence", "defense"), ("haemorrhage", "hemorrhage"), ("programmes", "programs"),
             ("programme", "program"), ("signalling", "signaling"),
             ("analysed", "analyzed"), ("analysing", "analyzing"),
             ("localisation", "localization"), ("localises", "localizes"),
             ("localised", "localized"), ("localise", "localize"),
             ("randomised", "randomized"), ("characterised", "characterized"),
             ("summarised", "summarized"), ("recognised", "recognized"),
             ("modelling", "modeling"), ("catalogued", "cataloged"),
             ("labelled", "labeled"), ("favour", "favor"), ("centred", "centered"),
             ("centres", "centers"),
             ("utilisation", "utilization"), ("optimise", "optimize"),
             ("normalise", "normalize"), ("prioritised", "prioritized"),
             ("immunodepressive", "immunosuppressive"),
             ("Immunodepressive", "Immunosuppressive"),
             ("Nine human GEO datasets were integrated: four bulk blood cohorts (GSE335924, "
              "GSE296792, GSE125512, GSE163256), three single-cell cohorts (GSE266873, "
              "GSE166638, GSE313043), one EPIC methylation cohort (GSE179759) and two miRNA "
              "datasets.",
              "Nine human GEO accessions were integrated, spanning four bulk blood cohorts "
              "(GSE335924, GSE296792, GSE125512, GSE163256), three single-cell cohorts "
              "(GSE266873, GSE166638, GSE313043), one EPIC methylation cohort (GSE179759) and "
              "two miRNA datasets (GSE43618 and the miRNA arm of GSE296792, the latter shared "
              "with its bulk arm)."),
             ("That gradient is an indication signal rather than a treatment effect",
              "That gradient reflects confounding by indication rather than a treatment effect")]
    FIX = [("Localisation", "Localization"), ("organising", "organizing"),
           ("disease and gender", "disease and sex"),
           ("cheap, routinely measured", "inexpensive, routinely measured"),
           ("a inexpensive", "an inexpensive"),
           ("on the full MIMIC-IV cohort", "on the MIMIC-IV cohort"),
           ("First, a causal forest confirmed that the association was concentrated in patients "
            "with GCS 3-8 (CATE -24.9 pp, 95% CI -32.7 to -17.1), with no association in GCS "
            "9-15 (-1.5 pp, -4.0 to +1.0).",
            "First, a causal forest placed the largest conditional benefit in patients with "
            "deep coma (GCS <8: CATE -16.0 pp, 95% CI -25.7 to -6.2), with the effect "
            "attenuating across the milder GCS strata (GCS 8-12: -7.4 pp, -12.0 to -2.7; "
            "GCS >=13: +1.0 pp, -1.2 to +3.2) (Figure S1)."),
           ("(Table 3, Figure S1).", "(Table 3)."),
           ("GCS ranked first among 44 candidate effect modifiers by variable importance "
            "(0.329, more than three times the second-ranked covariate).",
            "GCS ranked first among 44 candidate effect modifiers by variable importance "
            "(0.205, about 1.8 times the second-ranked covariate, platelet count)."),
           ("Results for 24-h and 72-h grace periods and for 90-day mortality were "
            "directionally consistent (Table 2).",
            "At a 24-h grace period, the association was larger (IPCW -12.5 pp, 95% CI "
            "-14.1 to -11.0), whereas at 72 h the two estimators diverged (IPCW +3.5 pp, "
            "+2.1 to +5.0; AIPW -8.4 pp, -11.4 to -5.4); 90-day mortality estimates were "
            "directionally consistent (Table 2)."),
           ("p<0.001", "p < 0.001"), ("p=0.001", "p = 0.001"), ("p=0.0002", "p = 0.0002"),
           ("n=", "n = "),
           ("All analysis code (R scripts) is provided as Supplementary File 1.",
            "Analysis code is available from the corresponding author on reasonable request."),
           ("ChiCTR297895", "ChiCTR2500113625"),
           ("early low-molecular-weight heparin versus best medical therapy",
            "low-molecular-weight heparin started at 48-72 h versus best medical therapy"),
           ("immunodeposition", "immunodepression"),
           ("tercile", "tertile"),
           ("ran the other way at baseline", "showed the opposite pattern at baseline"),
           ("gave a cleaner prognostic signal", "showed a stronger prognostic gradient"),
           ('>=18 years',
            '≥18 years'),
           ('GCS >=13',
            'GCS ≥13'),
           ('GCS <= 8',
            'GCS ≤8'),
           ('|delta beta| >= 0.15',
            '|delta beta| ≥ 0.15'),
           ('4.59x10^-9',
            '4.59 × 10⁻⁹'),
           ('5.67x10^-9',
            '5.67 × 10⁻⁹'),
           ('2,425 dataset-level differential expression events',
            '2,425 dataset-level differentially expressed entries'),
           ('44 candidate effect modifiers',
            '44 candidate covariate terms'),
           ('Reporting follows STROBE guidance and recommendations for target trial emulation studies.',
            'Reporting follows STROBE guidance and the target-trial emulation recommendations of Hernán and colleagues [13-15].'),
           ('In-hospital VTE was more frequently recorded under early prophylaxis in MIMIC-IV (AIPW RR 1.44, 1.01-2.04), consistent with surveillance-related ascertainment.',
            'The weighted absolute risk of in-hospital death in MIMIC-IV was 14.2% with early prophylaxis and 18.4% with delayed prophylaxis. In-hospital VTE was more frequently recorded under early prophylaxis in MIMIC-IV (AIPW RR 1.44, 1.01-2.04), consistent with surveillance-related ascertainment.'),
           ('These results indicate that the mortality association is driven by receipt of prophylaxis itself rather than by earlier initiation.',
            'These results suggest that the mortality association is dominated by receipt of prophylaxis rather than by its timing. The within-treated contrast was not powered to exclude a modest timing effect, and the dose-response gradient reported below argues that the earliest initiation windows carry additional benefit.'),
           ('Patients who went on to receive early prophylaxis entered with lower lymphocyte counts',
            'In eICU-CRD, patients who went on to receive early prophylaxis entered with lower lymphocyte counts'),
           ('the sicker patients were both more likely to be treated early and more likely to be lymphopenic.',
            'at these sites the sicker patients were both more likely to be treated early and more likely to be lymphopenic.'),
           ('The albumin-bilirubin (ALBI) score [28] showed a stronger prognostic gradient.',
            'The albumin-bilirubin (ALBI) score [28], which combines albumin, a negative acute-phase reactant, with total bilirubin, showed a stronger prognostic gradient.'),
           ('It does establish that the immune state described in the GEO cohorts has an inexpensive, routinely measured correlate, and that early prophylaxis was not accompanied by a deepening of that state.',
            'It does show that the lymphocyte count and its ratio to neutrophils move in the direction predicted by the GEO data, and that early prophylaxis was not accompanied by a deepening of the immunosuppressive shift. Neither quantity substitutes for monocyte HLA-DR measurement, and the ALBI gradient is reported as an exploratory prognostic observation rather than as an immune marker.'),
           ('In three independent ICU databases analyzed with a common target-trial-emulation design, early pharmacological VTE prophylaxis after spontaneous ICH was associated with lower in-hospital mortality, with consistent inverse-probability-weighted and augmented estimates and the largest absolute benefit in patients with GCS 3-8. The sensitivity analyses address different potential sources of bias and are summarized below.',
            'The clinical signal is not uniform across the three databases, and what the emulation identifies is an association, not an effect. Early pharmacological VTE prophylaxis after spontaneous ICH was associated with lower in-hospital mortality in MIMIC-IV and eICU, with the largest absolute benefit in patients with GCS 3-8, whereas the NWICU inverse-probability estimate was null. The sensitivity analyses probe different sources of bias and are summarized below.'),
           ('and no association after 36-48 h.',
            'and no association when initiation was deferred beyond 36 h.'),
           ('The instrumental variable analysis was underpowered but, with a strong instrument (first-stage F = 352), its confidence interval excludes a large harmful effect and overlaps the primary estimates.',
            'The instrumental variable analysis was underpowered and its point estimate was null (+1.9 pp), but with a strong instrument (first-stage F = 352) the confidence interval excludes a large harmful effect and overlaps the primary estimates; a null result of this width does not contradict the primary estimate, but it argues against reading the risk difference as a precise causal effect.'),
           ('Since our initial analyses, an independent landmark cohort study using the same MIMIC-IV database reported a similar association',
            'An independent cohort study using the same MIMIC-IV database reported a similar association'),
           ('These results support the pre-specified GCS-stratified finding rather than a chance subgroup effect.',
            'These results are consistent with the pre-specified GCS-stratified finding, although the forest was fitted on the same data and cannot by itself exclude a chance subgroup effect.'),
           ('susceptible to infection in the days after hemorrhage, while',
            'susceptible to infection in the days after hemorrhage [25,26], while'),
           ('This study has limitations. Residual confounding cannot be excluded despite consistent estimates across estimators and instruments.',
            'This study has limitations. Residual confounding cannot be excluded despite consistent estimates across estimators and instruments, and its direction is known: in MIMIC-IV the early group was less severely affected at baseline (GCS 11.0 vs 9.7; mechanical ventilation 18.1% vs 31.4%), so the imbalance that survives weighting would inflate rather than mask the estimated benefit. The instrumental-variable point estimate was null, and the agreement across three databases therefore describes the consistency of an association rather than its magnitude.'),
           ('Machine-learning analyses share the same unmeasured-confounding limitation as the primary analysis and are reported as robustness checks rather than causal estimates.',
            'Machine-learning analyses share the same unmeasured-confounding limitation as the primary analysis and are reported as robustness checks rather than causal estimates. No formal correction was applied across the exploratory subgroup, timing-window and machine-learning analyses; only the GCS strata were pre-specified.'),
           ('was associated with lower in-hospital mortality across three independent databases, without an observed increase in hematoma expansion. The benefit was concentrated in patients with GCS 3-8 and appeared attributable to receipt of prophylaxis rather than to timing alone.',
            'was associated with lower in-hospital mortality in MIMIC-IV and eICU, without an observed increase in hematoma expansion. Recorded VTE did not fall, the instrumental-variable estimate was null and the NWICU inverse-probability estimate was also null, so the association cannot be attributed to thromboprophylaxis alone and its magnitude is probably inflated by selection. The benefit was concentrated in patients with GCS 3-8 and was dominated by receipt of prophylaxis rather than by timing.'),
           ('Analysis code is available from the corresponding author on reasonable request.',
            'Analysis code is provided as a supplementary code archive (Reproducible_Code), and de-identified analysis extracts are available from the corresponding author on reasonable request.'),
           ('Figure S4: estimator forest plot.',
            'Figure S4: estimator forest plot. Code archive: analysis scripts (R and Python) for the multi-omics, target-trial and immune-bridge analyses.'),
           ('The concordance across two analytic frameworks in the same data, together with our '
            'cross-database replication, lends support to the direction of the association.',
            'The contribution relative to that report is three-database replication under one '
            'protocol, a bias-oriented sensitivity programme that returned a null '
            'instrumental-variable estimate, and a transcriptomic-cellular layer that the '
            'single-database analysis did not examine; concordance in direction supports the '
            'association without establishing its size.'),
           ('To test whether the GCS-stratified heterogeneity was data-driven rather than '
            'pre-specified, we fitted a causal forest',
            'As an exploratory check on whether the GCS-stratified heterogeneity was '
            'data-driven, we fitted a causal forest'),
           ('and >=13', 'and \u226513'),
           ('The association appeared to be driven primarily by receipt of prophylaxis itself rather than by earlier initiation:',
            'The association was dominated by receipt of prophylaxis;'),
           ('IPCW RD -5.8 pp, 95% CI -7.5 to -4.1; RR 0.71, 0.64-0.79; AIPW -6.2 pp, -9.4 to -3.1',
            'IPCW RD -4.2 pp, 95% CI -6.0 to -2.4; RR 0.77, 0.69-0.86; AIPW -7.3 pp, -10.4 to -4.2'),
           ('E-value analysis (2.16/1.86)', 'E-value analysis (1.91/1.61)'),
           ('The NWICU point estimate was larger (-16.9 pp, -20.7 to -13.9; AIPW -13.2 pp, -17.8 to -8.7) and is examined below.',
            'The NWICU inverse-probability estimate was null under the deterministic rerun (-0.1 pp, -0.8 to +0.9; AIPW -12.5 pp, -17.5 to -7.6) and is examined below.'),
           ('The transportability analysis provides one explanation for the between-database differences in point estimates. The NWICU estimate, which was larger than those in MIMIC-IV and eICU, decreased under overlap weighting and, after standardization to the MIMIC-IV case mix, was compatible with the identically specified MIMIC-IV reference (-6.8 pp in both). These findings suggest that the observed heterogeneity reflects differences in case mix rather than inconsistency of the underlying association.',
            'The transportability analysis provides one explanation for the between-database differences in point estimates. In NWICU the augmented and overlap-weighted estimates were protective (ATO -11.4 pp), and after standardization to the MIMIC-IV case mix the estimate was -6.8 pp with a wide confidence interval, directionally aligned with the MIMIC-IV and eICU estimates. These findings indicate that the NWICU null inverse-probability estimate is estimator-sensitive rather than evidence of no association, and that part of the between-database heterogeneity reflects case mix.'),
           ('The instrumental-variable point estimate was null, and the agreement across three databases therefore describes the consistency of an association rather than its magnitude.',
            'The instrumental-variable point estimate was null, and the NWICU inverse-probability estimate was also null, so the evidence describes an association that is estimator- and database-sensitive rather than a consistent magnitude.'),
           ('In NWICU, the 48-h estimate decreased from -16.9 to -11.4 pp, indicating that part of the larger NWICU estimate is attributable to patients with extreme censoring propensities (Table 4).',
            'In NWICU, the 48-h overlap-weighted estimate (-11.4 pp) was more protective than the primary inverse-probability estimate (-0.1 pp), indicating estimator sensitivity to patients with extreme censoring propensities (Table 4).'),
           ('In three independent ICU databases, early pharmacological VTE prophylaxis (within 48 h) after spontaneous ICH was associated with lower in-hospital mortality, with the largest benefit in patients with GCS 3-8.',
            'In two of the three ICU databases (MIMIC-IV and eICU), early pharmacological VTE prophylaxis (within 48 h) after spontaneous ICH was associated with lower in-hospital mortality, with the largest benefit in patients with GCS 3-8; the NWICU inverse-probability estimate was null.')]
    for p in doc.paragraphs:
        if p.style.name == "Heading 1" and p.text.strip() == "References":
            break
        for k, v in SPELL + FIX:
            _apply(p, k, v)



# ================================================================ FRONT MATTER
center(NEW_TITLE, bold=True, size=15)
center("Zhenglin Liu, Jian Yin*", size=11)
center("Department of Neurosurgery, The Second Affiliated Hospital of Dalian Medical University, "
       "467 Zhongshan Road, Shahekou, Dalian 116023, Liaoning, China", size=10)
center("* Correspondence: Jian Yin, MD; jyin@dmu.edu.cn; Tel.: +86 17709876333; "
       "ORCID: 0000-0002-5167-9821", size=10)
doc.add_paragraph(style="Normal")

h2("Abstract")
body(NEW_ABSTRACT)
body("Keywords: " + NEW_KEYWORDS, justify=False)

# ================================================================ 1 INTRODUCTION
h1("1. Introduction")
for i in range(20, 24):
    emit(i)

# ================================================================ 2 METHODS (Frontiers order)
h1("2. Materials and methods")
h2("2.1. Data sources")
emit(26)
h2("2.2. Target trial specification")
for i in range(28, 33):
    emit(i)
h2("2.3. Statistical analysis")
emit(34)
h2("2.4. Supplementary analyses")
for i in range(36, 43):
    emit(i)
body("Unmeasured confounding and negative controls. E-values were computed from the risk "
     "ratio and its confidence limit to quantify the minimum strength of association that "
     "an unmeasured confounder would need with both prophylaxis and outcome to explain the "
     "estimate. Two negative-control outcomes that prophylactic heparin cannot plausibly "
     "affect, pressure ulcer and aspiration pneumonia, were analysed with the same 48-h "
     "emulation; a design free of systematic bias should return a null association for "
     "these outcomes.")
h2("2.5. Multi-omics mechanistic analysis")
emit(44)
h2("2.6. Immune-bridge analysis")
body("We asked whether the two axes identified in the transcriptomic data were visible in "
     "routine laboratory records. For eICU-CRD we extracted white-cell counts and "
     "lymphocyte and neutrophil percentages from the laboratory table in 24-h windows after "
     "ICU admission; the absolute lymphocyte count was derived as the white-cell count "
     "multiplied by the lymphocyte percentage because eICU-CRD does not report an absolute "
     "count. The first window extended from 6 h before to 24 h after admission and "
     "contributed the value closest to time zero; each later window covered the preceding "
     "24 h and contributed the mean of the values available. MIMIC-IV contributed a "
     "directly measured absolute count for the subset of stays with a five-part "
     "differential. Window-specific comparisons used linear mixed models with stay-level "
     "and hospital-level random intercepts, adjusted for the baseline value, age, GCS, "
     "mechanical ventilation, neurosurgical procedure, platelet count, creatinine, "
     "hemoglobin, chronic kidney disease and liver disease, and weighted by stabilized "
     "inverse-probability-of-treatment weights truncated at the 1st and 99th percentiles; "
     "the reported P values are for the exposure-by-window interaction term. A "
     "cross-sectional comparison in MIMIC-IV used unweighted means and standard deviations. "
     "The albumin-bilirubin (ALBI) score was computed from the earliest available albumin "
     "and total bilirubin values [35], categorized into tertiles, related to in-hospital "
     "mortality by logistic regression adjusted for age, GCS and mechanical ventilation, "
     "and correlated with the 72-96 h lymphocyte count by Spearman rank correlation. These "
     "analyses are descriptive and were not designed to estimate a treatment effect, so "
     "their estimand differs from that of the emulated trial.")

# ================================================================ 3 RESULTS
h1("3. Results")

# --- 3.1 rationale and data landscape
h2("3.1. Rationale and data landscape")
emit(61, MECH_FIG_MAP)

# --- 3.2 consensus transcriptomic program
h2("3.2. A consensus myeloid and immunoregulatory program across ICH transcriptomes")
for i in range(63, 66):
    emit(i, MECH_FIG_MAP)
add_figure(FIG_FILE[1])
caption(CAP[1])

# --- 3.3 enrichment
h2("3.3. Functional enrichment separates inflammatory activation from adaptive suppression")
emit(67, MECH_FIG_MAP)

# --- 3.4 co-expression module
h2("3.4. A co-expression module couples the ICH state to myeloid signalling")
emit(69, MECH_FIG_MAP)
add_figure(FIG_FILE[2])
caption(CAP[2])

# --- 3.5 deconvolution
h2("3.5. Immune deconvolution quantifies the cellular shift")
emit(71, MECH_FIG_MAP)

# --- 3.6 single-cell
h2("3.6. Single-cell analysis localises hub genes to defined cell types")
for i in range(73, 76):
    emit(i, MECH_FIG_MAP)
add_figure(FIG_FILE[3])
caption(CAP[3])

# --- 3.7 methylation
h2("3.7. Gene-level methylation and its link to expression")
emit(77, MECH_FIG_MAP)
add_figure(FIG_FILE[4])
caption(CAP[4])

# --- 3.8 miRNA
h2("3.8. An exploratory microRNA regulatory network")
emit(79, MECH_FIG_MAP)

# --- 3.9 integrated synthesis
h2("3.9. Integrated mechanistic synthesis")
emit(81, MECH_FIG_MAP)
add_figure(FIG_FILE[5])
caption(CAP[5])

# --- 3.10 cohort characteristics
h2("3.10. Cohort characteristics and prophylactic timing in three databases")
emit(47, CLINICAL_FIG_MAP)
add_figure(FIG_FILE[6])
caption(CAP[6])
add_table(
    0,
    "Table 1. Baseline characteristics of the MIMIC-IV cohort by prophylaxis timing (48-h threshold).",
    [sp[159].text, sp[160].text, sp[161].text, sp[162].text],
)

# --- 3.11 primary effect
h2("3.11. Early prophylaxis and in-hospital mortality")
for i in (49, 50):
    emit(i, CLINICAL_FIG_MAP)
body("Figure 7 displays the corresponding risk differences and risk ratios across "
     "databases, estimators and outcome definitions.")
add_figure(FIG_FILE[7])
caption(CAP[7])
def _set_tc_text(tc, val):
    paras = tc.findall(qn("w:p"))
    for extra in paras[1:]:
        tc.remove(extra)
    p0 = paras[0]
    runs = p0.findall(qn("w:r"))
    for extra in runs[1:]:
        p0.remove(extra)
    if not runs:
        r0 = OxmlElement("w:r")
        p0.append(r0)
    else:
        r0 = runs[0]
    for t in r0.findall(qn("w:t")):
        r0.remove(t)
    t = OxmlElement("w:t")
    t.set(qn("xml:space"), "preserve")
    t.text = val
    r0.append(t)


def _rewrite_t2_base_rows(tbl_xml):
    # MIMIC 48-h rows copied from the source table carry the archived (non-reproducible)
    # estimates; rewrite the RD and RR cells to the deterministic pipeline values.
    trs = tbl_xml.findall(qn("w:tr"))
    edits = [
        (13, {3: ("-16.9 (-20.7, -13.9)", "-0.1 (-0.8, +0.9)"),
              4: ("-", "1.00 (0.97, 1.04)")}),
        (14, {3: ("-13.2 (-17.8, -8.7)", "-12.5 (-17.5, -7.6)")}),
        (1, {3: ("-5.8 (-7.5, -4.1)", "-4.2 (-6.0, -2.4)"),
             4: ("0.71 (0.64, 0.79)", "0.77 (0.69, 0.86)")}),
        (2, {3: ("-6.2 (-9.4, -3.1)", "-7.3 (-10.4, -4.2)"),
             4: ("0.75 (0.65, 0.88)", "0.72 (0.62, 0.84)")}),
        (3, {3: ("-7.8 (-9.7, -6.1)", "-5.9 (-7.8, -4.1)"),
             4: ("0.71 (0.66, 0.77)", "0.77 (0.70, 0.83)")}),
    ]
    for ri, cell_edits in edits:
        tcs = trs[ri].findall(qn("w:tc"))
        for ci, (old, new) in cell_edits.items():
            cur = "".join(t.text or "" for t in tcs[ci].findall(".//" + qn("w:t")))
            assert cur == old, (ri, ci, cur)
            _set_tc_text(tcs[ci], new)


def _append_t2_rows(tbl_xml):
    trs = tbl_xml.findall(qn("w:tr"))
    anchor_tr = trs[4]      # last MIMIC row (48-h VTE); new rows go after it
    template_tr = trs[1]    # a MIMIC data row, supplies the formatting
    rows_data = [
        ("MIMIC-IV", "24 h", "IPCW-HT", "-12.5 (-14.1, -11.0)", "0.42 (0.37, 0.47)", "In-hospital mortality"),
        ("MIMIC-IV", "24 h", "AIPW", "-6.2 (-11.2, -1.2)", "0.75 (0.57, 0.98)", "In-hospital mortality"),
        ("MIMIC-IV", "72 h", "IPCW-HT", "+3.5 (+2.1, +5.0)", "1.23 (1.14, 1.35)", "In-hospital mortality"),
        ("MIMIC-IV", "72 h", "AIPW", "-8.4 (-11.4, -5.4)", "0.71 (0.62, 0.81)", "In-hospital mortality"),
    ]
    for rd in rows_data:
        new_tr = copy.deepcopy(template_tr)
        for tc, val in zip(new_tr.findall(qn("w:tc")), rd):
            _set_tc_text(tc, val)
        anchor_tr.addnext(new_tr)
        anchor_tr = new_tr


_t2_xml = add_table(
    2,
    "Table 2. Estimated effect of early versus delayed pharmacological prophylaxis, 48-h grace period.",
    [sp[165].text, sp[166].text, sp[167].text],
)
_append_t2_rows(_t2_xml)
_rewrite_t2_base_rows(_t2_xml)

# --- 3.12 GCS strata
h2("3.12. Pre-specified Glasgow Coma Scale-stratified analysis")
emit(51, CLINICAL_FIG_MAP)
add_table(
    3,
    "Table 3. GCS-stratified in-hospital mortality estimates (48-h grace period).",
    [sp[170].text, sp[171].text],
)

# --- 3.13 supplementary clinical analyses
h2("3.13. Supplementary causal analyses")
for i in range(53, 59):
    emit(i, CLINICAL_FIG_MAP)
body("Unmeasured confounding and negative controls. The E-value for the MIMIC-IV "
     "in-hospital mortality association (RR 0.77) was 1.91, and 1.61 for its confidence "
     "limit, so an unmeasured confounder would need to be associated with both prophylaxis "
     "and mortality by a risk ratio of at least 1.61 to explain the observed association; "
     "the corresponding values for 90-day mortality were 1.93 and 1.70. Under the primary "
     "IPCW estimator neither negative-control outcome was associated with early "
     "prophylaxis (pressure ulcer -0.1 pp, 95% CI -0.6 to +0.6; aspiration pneumonia "
     "-0.1 pp, -1.4 to +1.1), whereas the AIPW estimates for these outcomes were positive "
     "(+1.6 and +4.9 pp); we therefore treat AIPW as a corroborative rather than a primary "
     "estimator.")
add_table(
    4,
    "Table 4. Summary of supplementary causal analyses.",
    [sp[174].text, sp[175].text],
)
def _rewrite_t4(tbl_xml):
    trs = tbl_xml.findall(qn("w:tr"))
    t4_edits = [
        (4, {2: ('-6.8 pp (-20.7, +7.8) / +3.5 pp (-8.0, +17.0); MIMIC-IV reference -6.8 pp',
                 '-6.8 pp (-20.7, +7.8) / +3.5 pp (-8.0, +17.0)'),
             3: ('NWICU estimate coincides with the MIMIC-IV reference after standardization',
                 'NWICU standardized estimate directionally aligned with the MIMIC-IV/eICU estimates; wide CI')}),
    ]
    for ri, cell_edits in t4_edits:
        tcs = trs[ri].findall(qn("w:tc"))
        for ci, (old, new) in cell_edits.items():
            cur = "".join(t.text or "" for t in tcs[ci].findall(".//" + qn("w:t")))
            assert cur == old, (ri, ci, cur)
            _set_tc_text(tcs[ci], new)
_t4_xml = doc.tables[3]._tbl
_rewrite_t4(_t4_xml)

# --- 3.14 peripheral immune trajectories (new analysis)
h2("3.14. Peripheral immune trajectories and the albumin-bilirubin gradient")
body("The mechanistic work pointed to two axes that can be read in blood: myeloid "
     "expansion and lymphocyte suppression [36,37]. We asked whether either axis is "
     "visible in the routine laboratory record (Supplementary Table S2 lists every "
     "window-specific estimate). In eICU-CRD, differential counts were "
     "available for 2,405 stays at admission and 1,160 at 72-96 h, and an absolute "
     "lymphocyte count could be derived for 1,653 and 628 of them; the count was computed "
     "as the white-cell count times the lymphocyte percentage. "
     "MIMIC-IV contributed 425 stays with a directly measured absolute count.")
body("Patients who went on to receive early prophylaxis entered with lower lymphocyte "
     "counts (1.26 vs 1.55 K/uL) and a higher neutrophil-to-lymphocyte ratio (NLR; 10.5 "
     "vs 8.1) than those in whom prophylaxis was delayed. That gradient is an indication "
     "signal rather than a treatment effect: the sicker patients were both more likely to "
     "be treated early and more likely to be lymphopenic. Between 24 and 48 h the early "
     "group developed a transient neutrophil-dominant peak (NLR 14.1 vs 9.0; interaction "
     "+3.16, 95% CI 1.93 to 4.39; p<0.001) that resolved by 72-96 h. Lymphocyte counts rose "
     "after 48 h and converged with the delayed group (interaction at 72-96 h +0.24 K/uL, "
     "95% CI 0.14 to 0.34; p<0.001). Monocyte fractions were marginally lower at 24-48 h "
     "(-0.54 percentage points, 95% CI -0.87 to -0.21; p=0.001) and then identical. Change "
     "from baseline to 48-72 h did not reach significance for any marker (lymphocytes "
     "+0.15 K/uL, 95% CI -0.11 to 0.36), and only 42 early-prophylaxis patients contributed "
     "paired samples.")
body("MIMIC-IV ran the other way at baseline (lymphocytes 1.58 vs 1.42 K/uL), which we "
     "read as further evidence that the two databases selected different patients rather "
     "than as a biological contradiction. NLR is already a recognised outcome marker in "
     "ICH [38], so the trajectories in Figure 8 are phenotype-level description, not a "
     "causal chain.")
body("The albumin-bilirubin (ALBI) score [35] gave a cleaner prognostic signal. Baseline "
     "ALBI was nearly identical between groups (-3.07 vs -3.17), yet in-hospital mortality "
     "rose from 16.1% in the lowest tercile to 31.5% in the highest (adjusted OR 1.81 per "
     "unit, 95% CI 1.33 to 2.48; n=1,209). ALBI also correlated weakly with the 72-96 h "
     "lymphocyte count (Spearman rho -0.18, p=0.0002, n=418). In MIMIC-IV the mortality "
     "association pointed the same way but was not significant (OR 1.15, 95% CI 0.73 to "
     "1.81; n=551).")
body("None of this links the same patients across the clinical and transcriptomic layers. "
     "It does establish that the immune state described in the GEO cohorts has a cheap, "
     "routinely measured correlate, and that early prophylaxis was not accompanied by a "
     "deepening of that state.")
add_figure(FIG_FILE[8])
caption(CAP[8])

# ================================================================ 4 DISCUSSION
h1("4. Discussion")
emit(84)
for i in (85, 86, 87):
    emit(i)
emit(88)
emit(89)
h2("Clinical findings in context")
NEW_096 = ("Machine-learning analyses were exploratory rather than confirmatory. First, a "
           "causal forest fitted to the same clone set (2,303 retained clones from 2,080 "
           "patients) did not resolve the subgroup pattern: conditional effects were imprecise "
           "and no GCS stratum reached significance (GCS 3-8: -4.3 pp, 95% CI -9.5 to +0.9; "
           "GCS 9-12: -0.5 pp, -5.0 to +4.0; GCS 13-15: +0.9 pp, -1.3 to +3.1) (Figure S1), "
           "and GCS was not the top-ranked covariate in that fit (rank 9 of 44 by variable "
           "importance; platelet count ranked first). We therefore define the severity gradient "
           "by the pre-specified inverse-probability-weighted strata in Table 3 rather than by "
           "the forest, whose clone-level fit does not reproduce the Hajek-weighted primary "
           "estimate. The gradient in Table 3 is consistent with a recent cohort of surgically "
           "treated patients with severe hypertensive ICH (GCS \u22648), in which early "
           "prophylaxis reduced DVT without increasing rebleeding or mortality [31]. Second, "
           "within the population who received prophylaxis, early versus late initiation showed "
           "no association with mortality (ATE -0.2 pp, 95% CI -3.4 to +2.9), indicating that "
           "the mortality association is driven by receipt of prophylaxis itself rather than by "
           "timing alone, in line with the UFH-restricted estimate (+0.8 pp) and consistent with "
           "two recent meta-analyses reporting no difference between early and late initiation "
           "[32,33]. Third, TMLE and SuperLearner-based propensity weighting yielded estimates "
           "in the same direction as the primary analysis (TMLE -16.7 pp, 95% CI -18.7 to "
           "-14.7; SuperLearner IPW -17.4 pp, -20.5 to -14.3; propensity scores correlated "
           "0.895 with the primary logistic model), indicating that results are not sensitive "
           "to the choice of propensity or outcome model. These observational machine-learning "
           "estimates use a different estimand from the target-trial framework and are not "
           "directly comparable to the primary IPCW estimate; they are reported for direction "
           "and robustness only.")
for i in range(90, 99):
    if i == 96:
        body(NEW_096)
    else:
        emit(i)

# ================================================================ 5 CONCLUSION
h1("5. Conclusion")
emit(100)

# ================================================================ DECLARATIONS
h1("Declarations")
h2("Ethics statement")
emit_strip(102, "Ethics approval and consent to participate.")
h2("Consent for publication")
emit_strip(103, "Consent for publication.")
h2("Data availability statement")
emit(105)
h2("Author contributions")
emit_strip(108, "Authors' contributions.")
h2("Funding")
emit_strip(107, "Funding.")
h2("Conflict of interest")
emit_strip(106, "Competing interests.")
h2("Acknowledgments")
emit_strip(109, "Acknowledgements.")

# ================================================================ REFERENCES
finalize_citations()
finalize_text()
h1("References")
for n, r in enumerate(REFS, start=1):
    p = doc.add_paragraph(style="Normal")
    p.add_run("[%d] %s" % (n, r))
    p.paragraph_format.space_after = Pt(2)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

# ================================================================ SUPPLEMENTARY
h1("Supplementary material")
body("The following supplementary material is available for this article. "
     "Table S1: overview of the three contributing databases and analytic cohorts. "
     "Table S2: peripheral-blood leukocyte trajectories, exposure-time interactions and the "
     "albumin-bilirubin gradient. "
     "Figure S1: exploratory subgroup treatment effects. Figure S2: timing gradient across grace periods. "
     "Figure S3: dose-response by first-dose timing. Figure S4: estimator forest plot. "
     "Code archive: analysis scripts (R and Python) for the multi-omics, target-trial and "
     "immune-bridge analyses.",
     justify=False)
add_table(
    1,
    "Table S1. Overview of the three contributing databases and analytic cohorts.",
    [],
)
build_table_s2()
for k in ["S1", "S2", "S3", "S4"]:
    add_figure(SFIG_FILE[k], width_cm=15)
    doc.paragraphs[-1].paragraph_format.keep_with_next = True
    caption(CAP[k])

# --- 表格行禁止跨页断行（否则单元格内数字会被页边界截断）
for _tb in doc.tables:
    for _tr in _tb._tbl.findall(qn("w:tr")):
        _trpr = _tr.find(qn("w:trPr"))
        if _trpr is None:
            _trpr = OxmlElement("w:trPr")
            _tr.insert(0, _trpr)
        if _trpr.find(qn("w:cantSplit")) is None:
            _trpr.append(OxmlElement("w:cantSplit"))

doc.save(OUT)
wc = len(NEW_ABSTRACT.split())
print("SAVED:", OUT)
print("paragraphs:", len(doc.paragraphs), "tables:", len(doc.tables), "abstract_words:", wc)
