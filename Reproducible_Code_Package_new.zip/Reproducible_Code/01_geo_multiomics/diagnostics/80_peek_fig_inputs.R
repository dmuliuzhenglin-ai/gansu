# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 探查图表所需核心结果的结构
r <- file.path(PATHS$project, "02_results")
show <- function(f, n = 6) {
  cat("\n##########", f, "##########\n")
  d <- read.csv(file.path(r, f), check.names = FALSE)
  cat("dim:", dim(d), "\n"); print(head(d, n))
}
show("consensus_ORA.csv", 8)
show("cross_section_consensus.csv", 5)
show("longitudinal_consensus.csv", 5)
show("GSE335924_WGCNA_module_trait.csv")
show("GSE335924_WGCNA_hubs.csv")
show("GSE335924_immune_diff.csv")
show("GSE296792_immune_diff.csv")
show("GSE179759_DMR_gene_level.csv")
show("methyl_expression_link.csv")
show("GSE266873_composition_phase.csv")
show("GSE166638_composition_source.csv")
show("GSE313043_composition_treatment.csv")
show("miRNA_mRNA_network.csv", 5)
