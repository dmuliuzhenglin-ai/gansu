# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# ========================================================================
# File        : 21_supp_analyses.R
# Purpose     : 转投前补充分析
#   A. E-value 重算（用 02b 真实 RR）
#   B. MICE 多重插补后重跑主分析（G=48，IPCW + AIPW）
#   C. UFH vs LMWH 亚组主分析（按首次皮下预防用药类型分组）
#   D. 阴性对照结局（压疮 / 吸入性肺炎；预期 RD≈0）
# Inputs      : [clinical output directory]/01_分析队列.csv, _rx_prep.csv, _dx_prep.csv,
#               MIMIC admissions/patients (death time)
# Outputs     : [clinical output directory]/21_补充分析汇总.csv + 21_补充分析结果.txt
# ========================================================================
rm(list = ls())
suppressMessages({
  library(data.table)
  library(glmnet)
  library(ranger)
  library(mice)
  library(EValue)
})
set.seed(2026)

dir_mimic <- PATHS$mimic
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "21_补充分析结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

dat <- fread(file.path(dir_out, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]

# ----------------------------------------------------------------
# 0. 预处理（同2b-v5 / 04：死亡时间 + 协变量矩阵）
# ----------------------------------------------------------------
cat("== 0. 预处理 ==\n")
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"),
               select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"),
               select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs   := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, death90_hrs := as.numeric(as.Date(dod) - as.Date(intime)) * 24]

dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")

# 缺失统计
miss_cnt <- sapply(num_vars, function(v) sum(is.na(dat[[v]])))
cat("数值协变量缺失计数：\n"); print(miss_cnt)

# 基准矩阵：中位数填补 + 缺失指示符（同主分析口径）
make_X <- function(dt) {
  d <- copy(dt)
  for (v in num_vars) {
    d[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
    med <- median(d[[v]], na.rm = TRUE)
    d[is.na(get(v)), (v) := med]
  }
  miss_vars <- paste0(num_vars, "_miss")
  for (v in bin_vars) d[is.na(get(v)), (v) := FALSE]
  x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                           collapse = " + ")))
  model.matrix(x_formula, data = d)[, -1, drop = FALSE]
}
X_mm <- make_X(dat)
cat("队列：", nrow(dat), "条stay；基准协变量：", ncol(X_mm), "维\n\n")

# ----------------------------------------------------------------
# 通用克隆 + SL + 分析函数（同04架构）
# ----------------------------------------------------------------
build_clones <- function(dt, G, evar) {
  ev <- dt[[evar]]
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early")],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed")])
  cl[, px := rep(ev, 2)]
  cl[, t_div := fifelse(!is.na(px) & px <= G, px, G)]
  cl[, adherent := fcase(
    arm == "early"   & !is.na(px) & px <= G, 1L,
    arm == "delayed" & (is.na(px) | px > G), 1L,
    default = 0L)]
  cl
}

fit_sl <- function(x, y) {
  y <- as.integer(y)
  K <- 5
  folds <- sample(rep(1:K, length.out = length(y)))
  cv_err <- c(glmnet = Inf, ranger = Inf)
  pred_oof <- list(glmnet = rep(NA_real_, length(y)),
                   ranger = rep(NA_real_, length(y)))
  for (k in 1:K) {
    tr <- folds != k; te <- folds == k
    fit_g <- tryCatch(cv.glmnet(x[tr, , drop = FALSE], y[tr], family = "binomial",
                                nfolds = 3), error = function(e) NULL)
    if (!is.null(fit_g)) {
      pred_oof$glmnet[te] <- as.numeric(predict(fit_g, x[te, , drop = FALSE],
                                                s = "lambda.min", type = "response"))
    }
    fit_r <- tryCatch(ranger(x = as.data.frame(x[tr, , drop = FALSE]),
                             y = factor(y[tr], levels = c(0, 1)),
                             probability = TRUE, num.trees = 300),
                      error = function(e) NULL)
    if (!is.null(fit_r)) {
      pr <- predict(fit_r, data = as.data.frame(x[te, , drop = FALSE]))$predictions
      pc <- if ("1" %in% colnames(pr)) "1" else colnames(pr)[ncol(pr)]
      pred_oof$ranger[te] <- pr[, pc]
    }
  }
  for (nm in names(cv_err)) {
    p <- pred_oof[[nm]]
    ok <- !is.na(p)
    if (sum(ok) > 0 && length(unique(y[ok])) > 1)
      cv_err[nm] <- mean((y[ok] - p[ok])^2)
  }
  best <- names(which.min(cv_err))
  list(best = best,
       glmnet = cv.glmnet(x, y, family = "binomial", nfolds = 5),
       ranger = ranger(x = as.data.frame(x), y = factor(y, levels = c(0, 1)),
                       probability = TRUE, num.trees = 500))
}
predict_sl <- function(fit, x) {
  if (fit$best == "glmnet") {
    as.numeric(predict(fit$glmnet, x, s = "lambda.min", type = "response"))
  } else {
    pr <- predict(fit$ranger, data = as.data.frame(x))$predictions
    pc <- if ("1" %in% colnames(pr)) "1" else colnames(pr)[ncol(pr)]
    pr[, pc]
  }
}

analyze_one <- function(dt, X, G, yvar, tvar, evar, n_boot = 300, label = "") {
  cat("[stage]", label, "构建克隆 G =", G, "\n")
  cl <- build_clones(dt, G, evar)
  cl[, Y := as.integer(dt[[yvar]][src_row])]
  tv <- dt[[tvar]][cl$src_row]
  cl[, ev_before_div := as.integer(!is.na(tv) & tv <= t_div)]
  Xall <- X[cl$src_row, , drop = FALSE]
  arm_all <- as.integer(cl$arm == "early")
  n_arm <- nrow(dt)

  cat("[stage]", label, "依从模型\n")
  p_all <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_all == a)
    fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                       family = "binomial", nfolds = 5)
    p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                     s = "lambda.min", type = "response"))
  }
  p_all <- pmax(p_all, 0.01)
  stab <- ave(cl$adherent, cl$arm, FUN = mean)
  w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
  w_all[cl$ev_before_div == 1] <- 1
  pos <- cl$adherent == 1 & cl$ev_before_div == 0
  qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
  w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])

  kept <- cl$adherent == 1 | cl$ev_before_div == 1
  ht_est <- function(wv, arm_v, Y_v) {
    r_e <- sum(wv[arm_v == 1] * Y_v[arm_v == 1]) / n_arm
    r_d <- sum(wv[arm_v == 0] * Y_v[arm_v == 0]) / n_arm
    c(r_e, r_d, r_e - r_d, r_e / r_d)
  }
  pt <- ht_est(w_all[kept], arm_all[kept], cl$Y[kept])
  subj <- cl$subject_id
  usubj <- unique(subj)
  idx_list <- split(seq_len(nrow(cl)), subj)
  boot_mat <- matrix(NA_real_, n_boot, 4)
  colnames(boot_mat) <- c("risk_early", "risk_delayed", "RD", "RR")
  for (b in 1:n_boot) {
    bs <- sample(usubj, replace = TRUE)
    bi <- unlist(idx_list[as.character(bs)])
    if (length(unique(cl$adherent[bi])) < 2) next
    p_b <- rep(NA_real_, length(bi))
    ok <- TRUE
    for (a in 0:1) {
      ia <- which(arm_all[bi] == a)
      fit_b <- tryCatch(cv.glmnet(Xall[bi[ia], , drop = FALSE], cl$adherent[bi][ia],
                                  family = "binomial", nfolds = 3),
                        error = function(e) NULL)
      if (is.null(fit_b)) { ok <- FALSE; break }
      p_b[ia] <- as.numeric(predict(fit_b, Xall[bi[ia], , drop = FALSE],
                                    s = "lambda.min", type = "response"))
    }
    if (!ok) next
    p_b <- pmax(p_b, 0.01)
    stab_b <- ave(cl$adherent[bi], arm_all[bi], FUN = mean)
    w_b <- ifelse(cl$adherent[bi] == 1, stab_b / p_b, 1)
    w_b[cl$ev_before_div[bi] == 1] <- 1
    posb <- cl$adherent[bi] == 1 & cl$ev_before_div[bi] == 0
    qsb <- quantile(w_b[posb], c(0.01, 0.99), na.rm = TRUE)
    w_b[posb] <- pmin(pmax(w_b[posb], qsb[1]), qsb[2])
    kept_b <- cl$adherent[bi] == 1 | cl$ev_before_div[bi] == 1
    arm_b <- arm_all[bi][kept_b]
    w_kb <- w_b[kept_b]
    Y_kb <- cl$Y[bi][kept_b]
    boot_mat[b, ] <- c(sum(w_kb[arm_b == 1] * Y_kb[arm_b == 1]) / n_arm,
                       sum(w_kb[arm_b == 0] * Y_kb[arm_b == 0]) / n_arm, NA, NA)
    boot_mat[b, 3] <- boot_mat[b, 1] - boot_mat[b, 2]
    boot_mat[b, 4] <- boot_mat[b, 1] / boot_mat[b, 2]
  }
  ci_rd <- quantile(boot_mat[, 3], c(0.025, 0.975), na.rm = TRUE)
  ci_rr <- quantile(boot_mat[, 4], c(0.025, 0.975), na.rm = TRUE)

  cat("[stage]", label, "结局模型(SL交叉拟合)\n")
  M <- 5
  ofolds <- sample(rep(1:M, length.out = nrow(cl)))
  mu1 <- mu0 <- phat <- rep(NA_real_, nrow(cl))
  for (m in 1:M) {
    tr <- ofolds != m; te <- ofolds == m
    for (a in 0:1) {
      tr_a <- tr & arm_all == a & cl$adherent == 1
      if (sum(tr_a) < 50 || length(unique(cl$Y[tr_a])) < 2) next
      fit_o <- fit_sl(Xall[tr_a, , drop = FALSE], cl$Y[tr_a])
      pr <- predict_sl(fit_o, Xall[te, , drop = FALSE])
      if (a == 1) mu1[te] <- pr else mu0[te] <- pr
    }
    for (a in 0:1) {
      tr_a <- tr & arm_all == a
      fit_a <- cv.glmnet(Xall[tr_a, , drop = FALSE], cl$adherent[tr_a],
                         family = "binomial", nfolds = 3)
      pp <- as.numeric(predict(fit_a, Xall[te & arm_all == a, , drop = FALSE],
                               s = "lambda.min", type = "response"))
      phat[te & arm_all == a] <- pp
    }
  }
  phat <- pmax(phat, 0.01)
  in_arm <- arm_all == 1
  aug_w <- ifelse(cl$ev_before_div == 1, 1,
                  ifelse(cl$adherent == 1, 1 / phat, 0))
  aipw1 <- mu1 + in_arm * aug_w * (cl$Y - mu1)
  aipw0 <- mu0 + (!in_arm) * aug_w * (cl$Y - mu0)
  psi <- aipw1 - aipw0
  rd_aipw <- mean(psi)
  Dc <- tapply(psi - rd_aipw, subj, sum)
  se_rd <- sqrt(sum(Dc^2)) / length(psi)
  rr_aipw <- mean(aipw1) / mean(aipw0)
  se_logrr <- se_rd / max(abs(rd_aipw), 1e-6) * abs(log(rr_aipw))
  ci_rd_a <- c(rd_aipw - 1.96 * se_rd, rd_aipw + 1.96 * se_rd)
  ci_rr_a <- c(exp(log(rr_aipw) - 1.96 * se_logrr), exp(log(rr_aipw) + 1.96 * se_logrr))

  data.table(
    label = label, G = G, outcome = yvar, exposure = evar,
    n_stay = n_arm, n_kept = sum(cl$adherent == 1 | cl$ev_before_div == 1),
    ipcw_risk_early = round(pt[1], 4), ipcw_risk_delayed = round(pt[2], 4),
    ipcw_RD = round(pt[3], 4), ipcw_RD_lo = round(ci_rd[1], 4),
    ipcw_RD_hi = round(ci_rd[2], 4),
    ipcw_RR = round(pt[4], 3), ipcw_RR_lo = round(ci_rr[1], 3),
    ipcw_RR_hi = round(ci_rr[2], 3),
    aipw_RD = round(rd_aipw, 4), aipw_RD_lo = round(ci_rd_a[1], 4),
    aipw_RD_hi = round(ci_rd_a[2], 4), aipw_RR = round(rr_aipw, 3),
    aipw_RR_lo = round(ci_rr_a[1], 3), aipw_RR_hi = round(ci_rr_a[2], 3)
  )
}

results <- list()

# ----------------------------------------------------------------
# A. E-value 重算（真实 RR 来自 02b_结果汇总.csv）
# ----------------------------------------------------------------
cat("\n== A. E-value（基于02b真实RR） ==\n")
res2b <- fread(file.path(dir_out, "02b_结果汇总.csv"))
ev_tab <- res2b[grace_h == 48 & outcome %in% c("hosp_mort", "mort90"),
                .(outcome, method, RR, RR_lo, RR_hi)]
for (i in seq_len(nrow(ev_tab))) {
  rr <- ev_tab$RR[i]; lo <- ev_tab$RR_lo[i]; hi <- ev_tab$RR_hi[i]
  ev_p <- evalues.RR(rr, lo, hi, rare = FALSE)
  ev_tab[i, `:=`(Evalue_point = round(ev_p["point"], 2),
                 Evalue_ci_hi = round(ev_p["lower"], 2))]
  cat(sprintf("%s [%s]: RR=%.3f (%.3f-%.3f) -> E-value 点估计=%.2f, CI上限=%.2f\n",
              ev_tab$outcome[i], ev_tab$method[i], rr, lo, hi,
              ev_tab$Evalue_point[i], ev_tab$Evalue_ci_hi[i]))
}
results[["A_Evalue"]] <- ev_tab

# ----------------------------------------------------------------
# B. MICE 多重插补后重跑主分析
# ----------------------------------------------------------------
cat("\n== B. MICE 多重插补（G=48, hosp_mort + mort90） ==\n")
# 插补数值变量（仅缺失率>0的变量）
mis_vars <- num_vars[sapply(num_vars, function(v) sum(is.na(dat[[v]])) > 0)]
cat("需插补变量：", paste(mis_vars, collapse = ", "), "\n")
# 构建插补用data.frame
# 【关键1】first_px_hrs 的 NA 表示"从未用预防药"（延迟臂定义），death_hrs 的 NA
# 表示"未死亡"（分叉前事件判定），二者都不能插补；插补后按行序 merge 回。
# 【关键2】stay_id 是唯一键（subject_id 有重复住院），插补矩阵不含任何 ID，
#          complete() 保持行序，插补后按行序赋予 stay_id 与原列。
imp_df <- dat[, c("hosp_mort", "mort90", num_vars, bin_vars, cat_vars), with = FALSE]
imp_df[, gender_f := as.factor(gender_f)]
imp_df[, race4 := as.factor(race4)]
imp_df[, insurance := as.factor(insurance)]
imp_df[, admission_type := as.factor(admission_type)]
for (v in bin_vars) imp_df[[v]] <- as.integer(imp_df[[v]])
imp_df[["hosp_mort"]] <- as.integer(imp_df[["hosp_mort"]])
imp_df[["mort90"]] <- as.integer(imp_df[["mort90"]])

set.seed(2026)
mi <- mice(imp_df, m = 5, maxit = 5, method = "pmm", printFlag = FALSE)
res_mi <- list()
for (mi_i in 1:5) {
  d_mi <- as.data.table(complete(mi, mi_i))
  # 按行序赋予标识列与不可插补列（complete 保持行序）
  d_mi[, stay_id := dat$stay_id]
  d_mi[, subject_id := dat$subject_id]
  d_mi[, hadm_id := dat$hadm_id]
  d_mi[, intime := dat$intime]
  d_mi[, first_px_hrs := dat$first_px_hrs]
  d_mi[, death_hrs := dat$death_hrs]
  d_mi[, death90_hrs := dat$death90_hrs]
  d_mi[, exposure_48h := dat$exposure_48h]
  d_mi[, vte := dat$vte]
  d_mi[, icu_mort := dat$icu_mort]
  d_mi[, race4 := factor(race4, levels = levels(dat$race4))]
  d_mi[, gender_f := factor(gender_f, levels = levels(dat$gender_f))]
  d_mi[, insurance := factor(insurance, levels = levels(dat$insurance))]
  d_mi[, admission_type := factor(admission_type, levels = levels(dat$admission_type))]
  X_mi <- make_X(d_mi)
  res_mi[[mi_i]] <- analyze_one(d_mi, X_mi, 48, "hosp_mort", "death_hrs",
                                "first_px_hrs", n_boot = 150,
                                label = paste0("MICE-imp", mi_i, "-hosp_mort"))
  cat("  [MICE imp", mi_i, "hosp_mort] IPCW RD =", res_mi[[mi_i]]$ipcw_RD,
      " AIPW RD =", res_mi[[mi_i]]$aipw_RD, "\n")
}
# 简单Rubin合并（点估计取均值，方差=组内+组间）
rd_ipcw_mi <- sapply(res_mi, function(x) x$ipcw_RD)
rd_aipw_mi <- sapply(res_mi, function(x) x$aipw_RD)
rr_ipcw_mi <- sapply(res_mi, function(x) x$ipcw_RR)
rr_aipw_mi <- sapply(res_mi, function(x) x$aipw_RR)
se_ipcw_mi <- sapply(res_mi, function(x) (x$ipcw_RD_hi - x$ipcw_RD_lo) / (2 * 1.96))
se_aipw_mi <- sapply(res_mi, function(x) (x$aipw_RD_hi - x$aipw_RD_lo) / (2 * 1.96))
rubin <- function(est, se) {
  m <- length(est)
  W <- mean(se^2); B <- var(est)
  T <- W + (1 + 1 / m) * B
  c(est = mean(est), lo = mean(est) - 1.96 * sqrt(T), hi = mean(est) + 1.96 * sqrt(T))
}
rub_ipcw <- rubin(rd_ipcw_mi, se_ipcw_mi)
rub_aipw <- rubin(rd_aipw_mi, se_aipw_mi)
cat(sprintf("MICE合并 IPCW RD = %.4f (%.4f-%.4f)   AIPW RD = %.4f (%.4f-%.4f)\n",
            rub_ipcw[1], rub_ipcw[2], rub_ipcw[3], rub_aipw[1], rub_aipw[2], rub_aipw[3]))
results[["B_MICE"]] <- data.table(
  label = "MICE合并(G48, hosp_mort)", outcome = "hosp_mort",
  ipcw_RD = round(rub_ipcw[1], 4), ipcw_RD_lo = round(rub_ipcw[2], 4),
  ipcw_RD_hi = round(rub_ipcw[3], 4),
  aipw_RD = round(rub_aipw[1], 4), aipw_RD_lo = round(rub_aipw[2], 4),
  aipw_RD_hi = round(rub_aipw[3], 4))

# ----------------------------------------------------------------
# C. UFH vs LMWH 亚组（按首次皮下预防用药类型分组）
# ----------------------------------------------------------------
cat("\n== C. UFH vs LMWH 亚组（G=48, hosp_mort） ==\n")
rxp <- fread(file.path(dir_out, "_rx_prep.csv"))
rxp[, drug_l := tolower(drug)]
rxp[, drug_type := fifelse(grepl("enoxaparin|dalteparin|lovenox", drug_l), "LMWH",
                           fifelse(grepl("heparin", drug_l), "UFH", NA_character_))]
rxp[, starttime := as.POSIXct(starttime)]
rxp <- merge(rxp, dat[, .(hadm_id, intime)], by = "hadm_id", all.x = TRUE, sort = FALSE)
rxp[, hrs := as.numeric(difftime(starttime, intime, units = "hours"))]
rxp <- rxp[hrs >= 0 & !is.na(drug_type)]
first_by_type <- rxp[, .(first_hrs = min(hrs)), by = .(hadm_id, drug_type)]
# 首次预防用药类型
first_all <- first_by_type[order(hadm_id, first_hrs)]
first_type <- first_all[, .SD[1], by = hadm_id]
setnames(first_type, c("hadm_id", "first_type", "first_hrs"))
dat <- merge(dat, first_type, by = "hadm_id", all.x = TRUE, sort = FALSE)
cat("首次预防类型分布：\n")
print(dat[, .N, by = first_type])
cat("UFH亚组：首次预防=UFH 的 stay；LMWH亚组：首次预防=LMWH 的 stay\n")
# 亚组暴露时间 = 该类型的首次给药时间（亚组内重新定义）
dat[first_type == "UFH",  px_sub := first_hrs]
dat[first_type == "LMWH", px_sub := first_hrs]
sub_ufh  <- dat[first_type == "UFH"]
sub_lmwh <- dat[first_type == "LMWH"]
cat("UFH n =", nrow(sub_ufh), " 早期比例 =",
    round(mean(sub_ufh$px_sub <= 48, na.rm = TRUE), 3), "\n")
cat("LMWH n =", nrow(sub_lmwh), " 早期比例 =",
    round(mean(sub_lmwh$px_sub <= 48, na.rm = TRUE), 3), "\n")
X_ufh <- make_X(sub_ufh)
X_lmwh <- make_X(sub_lmwh)
res_ufh <- analyze_one(sub_ufh, X_ufh, 48, "hosp_mort", "death_hrs",
                       "px_sub", n_boot = 300, label = "C1-UFH亚组")
res_lmwh <- analyze_one(sub_lmwh, X_lmwh, 48, "hosp_mort", "death_hrs",
                        "px_sub", n_boot = 300, label = "C2-LMWH亚组")
print(res_ufh); print(res_lmwh)
results[["C_UFH"]]  <- res_ufh
results[["C_LMWH"]] <- res_lmwh

# ----------------------------------------------------------------
# D. 阴性对照结局（压疮 / 吸入性肺炎；G=48, 暴露=first_px_hrs）
# ----------------------------------------------------------------
cat("\n== D. 阴性对照结局（G=48, 暴露=早期肝素） ==\n")
dxp <- fread(file.path(dir_out, "_dx_prep.csv"))
for (oc in c("pressure_ulcer", "asp_pneumonia")) {
  oc_col <- paste0("neg_", oc)
  dat[, (oc_col) := as.integer(hadm_id %in% dxp[outcome == oc, hadm_id])]
  cat(sprintf("结局 %s：%d 例\n", oc_col, sum(dat[[oc_col]])))
  res_neg <- analyze_one(dat, X_mm, 48, oc_col, "death_hrs",
                         "first_px_hrs", n_boot = 300, label = paste0("D-", oc))
  print(res_neg)
  results[[paste0("D_", oc)]] <- res_neg
}

# ----------------------------------------------------------------
# 汇总输出
# ----------------------------------------------------------------
res_all <- rbindlist(results, fill = TRUE)
cat("\n== 汇总 ==\n")
print(res_all)
fwrite(res_all, file.path(dir_out, "21_补充分析汇总.csv"))
cat("\n结果已保存：21_补充分析结果.txt / 21_补充分析汇总.csv\n")
sink()
cat("运行完毕：[clinical output directory]/21_补充分析结果.txt/n")
