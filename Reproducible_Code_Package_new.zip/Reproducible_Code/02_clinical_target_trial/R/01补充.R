# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 步骤2：克隆-删失-加权 + AIPW/Super Learner 主分析
# 设计：目标试验模拟，时间零点=ICU入住
#   策略臂：早期（<=G小时启动VTE药物预防） vs 延迟/不用
#   宽限期 G：48h（主分析）、24h / 72h（敏感性）
#   结局：hosp_mort（主）、mort90、vte
#   估计量：IPCW-Hajek（主，自助法CI）+ 交叉拟合AIPW（双重稳健）
# 输入：[clinical output directory]/01_分析队列.csv（步骤1b修正版）
# 输出：[clinical output directory]/02_TTE主分析结果.txt + 02_结果汇总.csv
# 依赖：data.table, glmnet, ranger, sandwich
#   如未安装：install.packages(c("glmnet","ranger","sandwich"))
# ================================================================

rm(list = ls())
suppressMessages({
  library(data.table)
  library(glmnet)
  library(ranger)
  library(sandwich)
})
set.seed(2026)

dir_out <- PATHS$clinical
sink(file.path(dir_out, "02_TTE主分析结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

dat <- fread(file.path(dir_out, "01_分析队列.csv"))
cat("载入队列：", nrow(dat), "例 stay，",
    uniqueN(dat$subject_id), "名患者\n\n")

# ----------------------------------------------------------------
# 1. 协变量预处理：缺失填补 + 模型矩阵
# ----------------------------------------------------------------
cat("== 1. 协变量预处理 ==\n")
# 种族合并为四大类
dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")

# 连续变量：中位数填补 + 缺失指示
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
miss_vars <- paste0(num_vars, "_miss")
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]

x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1]
cat("模型矩阵维度：", nrow(X_mm), "x", ncol(X_mm), "\n\n")

# ----------------------------------------------------------------
# 2. 核心函数：构建克隆臂 + IPCW + 结局估计
# ----------------------------------------------------------------
# 克隆：每个stay复制到两个策略臂
# 早期臂：first_px_hrs <= G -> 依从(未删失)；否则在G时删失
# 延迟臂：first_px_hrs <= G -> 在用药时删失；否则依从
build_clones <- function(dt, G) {
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early",   first_px_hrs)],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed", first_px_hrs)])
  cl[, uncensored := fcase(
    arm == "early"   & !is.na(first_px_hrs) & first_px_hrs <= G, 1L,
    arm == "delayed" & (is.na(first_px_hrs) | first_px_hrs > G), 1L,
    default = 0L)]
  cl
}

# 离散Super Learner：5折CV在glmnet/ranger中选择，全数据重训
# 注：ranger训练子集可能出现单类别，需强制levels=c(0,1)并对预测列兜底
prob_col <- function(pred) {
  m <- pred$predictions
  if ("1" %in% colnames(m)) m[, "1"] else rep(mean(colnames(m) == "1"), nrow(m))
}
fit_sl <- function(X, y, w = NULL) {
  y <- as.integer(y)  # 逻辑值先转0/1，否则factor(levels=c(0,1))会全变NA
  K <- 5L
  folds <- sample(rep(1:K, length.out = length(y)))
  pred_glmnet <- pred_ranger <- rep(NA_real_, length(y))
  for (k in 1:K) {
    tr <- folds != k; te <- folds == k
    fit_g <- cv.glmnet(X[tr, ], y[tr], family = "binomial",
                       weights = if (is.null(w)) NULL else w[tr], nfolds = 5)
    pred_glmnet[te] <- as.numeric(predict(fit_g, X[te, ], s = "lambda.min", type = "response"))
    fit_r <- ranger(x = X[tr, ], y = factor(y[tr], levels = c(0, 1)), probability = TRUE,
                    case.weights = if (is.null(w)) NULL else w[tr],
                    num.trees = 300, min.node.size = 20)
    pred_ranger[te] <- prob_col(predict(fit_r, X[te, ]))
  }
  rmse <- function(p) sqrt(mean((y - p)^2))
  best <- if (rmse(pred_glmnet) <= rmse(pred_ranger)) "glmnet" else "ranger"
  if (best == "glmnet") {
    fit <- cv.glmnet(X, y, family = "binomial", weights = w, nfolds = 5)
  } else {
    fit <- ranger(x = X, y = factor(y, levels = c(0, 1)), probability = TRUE,
                  case.weights = w, num.trees = 500, min.node.size = 20)
  }
  list(model = fit, type = best)
}

predict_sl <- function(obj, X) {
  if (obj$type == "glmnet") {
    as.numeric(predict(obj$model, X, s = "lambda.min", type = "response"))
  } else {
    prob_col(predict(obj$model, X))
  }
}

# 单轮分析：给定宽限期G与结局变量名，返回双臂风险、RD、RR及诊断
analyze_one <- function(dt, X, G, yvar, n_boot = 500) {
  cl <- build_clones(dt, G)
  cl[, Y := dt[[yvar]][src_row]]
  cl <- cl[!is.na(Y)]
  Xc <- X[cl$src_row, ]  # 行与克隆严格对齐
  arm_bin <- as.integer(cl$arm == "early")
  
  # -- IPCW：每臂拟合依从模型（logistic，主分析用参数模型保证稳定） --
  w_trunc <- function(w, probs = c(0.01, 0.99)) {
    qs <- quantile(w[w > 0], probs = probs, na.rm = TRUE)
    pmin(pmax(w, qs[1]), qs[2])
  }
  p_uncen <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_bin == a)
    fit_c <- cv.glmnet(Xc[idx, ], cl$uncensored[idx], family = "binomial", nfolds = 5)
    p_uncen[idx] <- as.numeric(predict(fit_c, Xc[idx, ], s = "lambda.min", type = "response"))
  }
  p_uncen <- pmax(p_uncen, 0.01)
  # 稳定化权重：分子=臂内边际依从率
  stab <- ave(cl$uncensored, cl$arm, FUN = mean)
  w <- ifelse(cl$uncensored == 1, stab / p_uncen, 0)
  w <- w_trunc(w)
  
  # -- IPCW-Hajek 加权结局模型 --
  keep <- cl$uncensored == 1
  est_ipcw <- function(Yv, ab, wv) {
    r_e <- sum(wv[ab == 1] * Yv[ab == 1]) / sum(wv[ab == 1])
    r_d <- sum(wv[ab == 0] * Yv[ab == 0]) / sum(wv[ab == 0])
    c(risk_early = r_e, risk_delayed = r_d, RD = r_e - r_d, RR = r_e / r_d)
  }
  pt <- est_ipcw(cl$Y[keep], arm_bin[keep], w[keep])
  
  # 聚类自助法（按subject_id）
  subj <- cl$subject_id[keep]
  usubj <- unique(subj)
  boot_mat <- matrix(NA_real_, nrow = n_boot, ncol = 4)
  colnames(boot_mat) <- c("risk_early", "risk_delayed", "RD", "RR")
  Yk <- cl$Y[keep]; ak <- arm_bin[keep]; wk <- w[keep]
  idx_list <- split(seq_along(subj), subj)  # 预建患者->行索引，加速重抽样
  for (b in 1:n_boot) {
    bs <- sample(usubj, replace = TRUE)
    sel <- unlist(idx_list[as.character(bs)], use.names = FALSE)
    boot_mat[b, ] <- tryCatch(est_ipcw(Yk[sel], ak[sel], wk[sel]),
                              error = function(e) rep(NA_real_, 4))
  }
  ci <- apply(boot_mat, 2, quantile, probs = c(0.025, 0.975), na.rm = TRUE)
  
  # -- 交叉拟合 AIPW（双重稳健） --
  K <- 5L
  folds <- sample(rep(1:K, length.out = nrow(cl)))
  Q1 <- Q0 <- phat1 <- phat0 <- rep(NA_real_, nrow(cl))
  for (k in 1:K) {
    tr <- folds != k; te <- folds == k
    # 依从模型（SL）
    fit_c1 <- fit_sl(Xc[tr & arm_bin == 1, ], cl$uncensored[tr & arm_bin == 1])
    fit_c0 <- fit_sl(Xc[tr & arm_bin == 0, ], cl$uncensored[tr & arm_bin == 0])
    phat1[te] <- predict_sl(fit_c1, Xc[te, ])
    phat0[te] <- predict_sl(fit_c0, Xc[te, ])
    # 结局模型（SL，仅在未删失者上训练）
    tr_e <- tr & arm_bin == 1 & cl$uncensored == 1
    tr_d <- tr & arm_bin == 0 & cl$uncensored == 1
    fit_q1 <- fit_sl(Xc[tr_e, ], cl$Y[tr_e])
    fit_q0 <- fit_sl(Xc[tr_d, ], cl$Y[tr_d])
    Q1[te] <- predict_sl(fit_q1, Xc[te, ])
    Q0[te] <- predict_sl(fit_q0, Xc[te, ])
  }
  phat1 <- pmax(phat1, 0.01); phat0 <- pmax(phat0, 0.01)
  aipw_terms <- function(arm_val, Q, phat) {
    in_arm <- arm_bin == arm_val
    Q[in_arm] + (cl$uncensored[in_arm] == 1) / phat[in_arm] * (cl$Y[in_arm] - Q[in_arm])
  }
  t1 <- aipw_terms(1L, Q1, phat1)
  t0 <- aipw_terms(0L, Q0, phat0)
  psi1 <- mean(t1); psi0 <- mean(t0)
  # 聚类稳健IF方差（按subject）
  clu <- cl$subject_id[arm_bin == 1]
  if1 <- tapply(t1 - psi1, clu, sum)
  clu0 <- cl$subject_id[arm_bin == 0]
  if0 <- tapply(t0 - psi0, clu0, sum)
  all_subj <- union(names(if1), names(if0))
  s1 <- ifelse(all_subj %in% names(if1), if1[all_subj], 0)
  s0 <- ifelse(all_subj %in% names(if0), if0[all_subj], 0)
  n1 <- length(t1); n0 <- length(t0)
  M <- length(all_subj)  # 独立聚类数
  Dc <- s1 / n1 - s0 / n0
  se_rd <- sqrt(sum(Dc^2)) / M
  rd_a <- psi1 - psi0; rr_a <- psi1 / psi0
  ci_rd_a <- rd_a + c(-1, 1) * 1.96 * se_rd
  # RR的SE用delta法（log尺度）
  se_lnrr <- sqrt(sum((s1 / (n1 * psi1) - s0 / (n0 * psi0))^2)) / M
  ci_rr_a <- exp(log(rr_a) + c(-1, 1) * 1.96 * se_lnrr)
  
  # -- 诊断 --
  w_pos <- w[w > 0]
  ess <- sum(w_pos)^2 / sum(w_pos^2)
  list(
    point = c(pt, risk_early_aipw = psi1, risk_delayed_aipw = psi0,
              RD_aipw = rd_a, RR_aipw = rr_a),
    ci_boot = ci,
    ci_aipw = c(ci_rd_a, ci_rr_a),
    diag = c(n_uncensored = sum(keep), pct_censored = 100 * mean(!keep),
             w_max = max(w_pos), ess = ess)
  )
}

# ----------------------------------------------------------------
# 3. 主分析 + 敏感性分析循环
# ----------------------------------------------------------------
outcomes <- c("hosp_mort", "mort90", "vte")
out_label <- c(hosp_mort = "院内死亡", mort90 = "90天死亡", vte = "静脉血栓栓塞")
graces <- c(48, 24, 72)
results <- list(); ri <- 0L

for (G in graces) {
  cat("================================================\n")
  cat(sprintf("宽限期 G = %d 小时%s\n", G, ifelse(G == 48, "（主分析）", "（敏感性）")))
  cat("================================================\n")
  for (yv in outcomes) {
    cat(sprintf("\n-- 结局：%s --\n", out_label[yv]))
    res <- analyze_one(dat, X_mm, G, yv, n_boot = ifelse(G == 48, 500, 200))
    p <- res$point; cb <- res$ci_boot; ca <- res$ci_aipw; dg <- res$diag
    cat(sprintf("[IPCW]  早期风险 %.3f vs 延迟 %.3f | RD %.3f (%.3f, %.3f) | RR %.2f (%.2f, %.2f)\n",
                p["risk_early"], p["risk_delayed"],
                p["RD"], cb[1, "RD"], cb[2, "RD"],
                p["RR"], cb[1, "RR"], cb[2, "RR"]))
    cat(sprintf("[AIPW]  早期风险 %.3f vs 延迟 %.3f | RD %.3f (%.3f, %.3f) | RR %.2f (%.2f, %.2f)\n",
                p["risk_early_aipw"], p["risk_delayed_aipw"],
                p["RD_aipw"], ca[1], ca[2],
                p["RR_aipw"], ca[3], ca[4]))
    cat(sprintf("[诊断]  未删失 %d 例（删失 %.1f%%）| 最大权重 %.1f | 有效样本量 %.0f\n",
                dg["n_uncensored"], dg["pct_censored"], dg["w_max"], dg["ess"]))
    ri <- ri + 1L
    results[[ri]] <- data.table(
      grace_h = G, outcome = yv, method = rep(c("IPCW", "AIPW"), each = 1),
      risk_early = c(p["risk_early"], p["risk_early_aipw"]),
      risk_delayed = c(p["risk_delayed"], p["risk_delayed_aipw"]),
      RD = c(p["RD"], p["RD_aipw"]),
      RD_lo = c(cb[1, "RD"], ca[1]), RD_hi = c(cb[2, "RD"], ca[2]),
      RR = c(p["RR"], p["RR_aipw"]),
      RR_lo = c(cb[1, "RR"], ca[3]), RR_hi = c(cb[2, "RR"], ca[4]),
      n_uncensored = dg["n_uncensored"], ess = round(dg["ess"]))
  }
}

res_dt <- rbindlist(results)
fwrite(res_dt, file.path(dir_out, "02_结果汇总.csv"))

# ----------------------------------------------------------------
# 4. 主分析（G=48）加权后均衡性 SMD 表
# ----------------------------------------------------------------
cat("\n================================================\n")
cat("== 4. 加权后均衡性（G=48，SMD） ==\n")
cat("================================================\n")
cl48 <- build_clones(dat, 48)
arm_bin <- as.integer(cl48$arm == "early")
Xc <- X_mm[cl48$src_row, ]
p_uncen <- rep(NA_real_, nrow(cl48))
for (a in 0:1) {
  idx <- which(arm_bin == a)
  fit_c <- cv.glmnet(Xc[idx, ], cl48$uncensored[idx], family = "binomial", nfolds = 5)
  p_uncen[idx] <- as.numeric(predict(fit_c, Xc[idx, ], s = "lambda.min", type = "response"))
}
stab <- ave(cl48$uncensored, cl48$arm, FUN = mean)
w48 <- ifelse(cl48$uncensored == 1, stab / pmax(p_uncen, 0.01), 0)
qs48 <- quantile(w48[w48 > 0], c(0.01, 0.99))
pos48 <- w48 > 0
w48[pos48] <- pmin(pmax(w48[pos48], qs48[1]), qs48[2])
keep <- w48 > 0

smd_one <- function(x, a, w) {
  m1 <- weighted.mean(x[a == 1], w[a == 1]); m0 <- weighted.mean(x[a == 0], w[a == 0])
  s1 <- sqrt(weighted.mean((x[a == 1] - m1)^2, w[a == 1]))
  s0 <- sqrt(weighted.mean((x[a == 0] - m0)^2, w[a == 0]))
  sp <- sqrt((s1^2 + s0^2) / 2)
  if (sp == 0) return(0)
  (m1 - m0) / sp
}
smd_tab <- data.table(variable = colnames(X_mm),
                      SMD_weighted = sapply(seq_len(ncol(X_mm)),
                                            function(j) smd_one(Xc[keep, j], arm_bin[keep], w48[keep])))
smd_tab[, abs_SMD := abs(SMD_weighted)]
setorder(smd_tab, -abs_SMD)
cat("加权后 |SMD| > 0.1 的变量（理想应全部 < 0.1）：\n")
print(smd_tab[abs_SMD > 0.1])
cat(sprintf("\n最大|SMD| = %.3f\n", max(smd_tab$abs_SMD)))
fwrite(smd_tab, file.path(dir_out, "02_加权后SMD.csv"))

cat("\n结果已保存：02_结果汇总.csv / 02_加权后SMD.csv\n")
sink()
cat("运行完毕，请查看 [clinical output directory]/02_TTE主分析结果.txt/n")
