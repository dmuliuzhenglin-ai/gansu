# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 统计 C8 中各免疫细胞类型关键词命中的基因集数
Sys.setenv(http_proxy = "http://127.0.0.1:7897",
           https_proxy = "http://127.0.0.1:7897")
suppressPackageStartupMessages(library(msigdbr))
c8 <- msigdbr(species = "Homo sapiens", category = "C8")
gs <- unique(c8$gs_name)
kw <- list(
  B_cell     = "B_CELL|B_ CELL|PLASMA_CELL",
  T_cell_CD4 = "CD4",
  T_cell_CD8 = "CD8",
  T_cell_general = "T_CELL|T_REG|TREG",
  NK_cell    = "NK_CELL|NKT|NATURAL_KILLER",
  monocyte   = "MONOCYTE",
  macrophage = "MACROPHAGE",
  neutrophil = "NEUTROPHIL",
  dendritic  = "DENDRITIC",
  mast_cell  = "MAST_CELL")
for (k in names(kw)) cat(sprintf("%-14s %3d sets\n", k,
                                 sum(grepl(kw[[k]], gs))))
cat("\nexample neutrophil sets:\n")
print(grep("NEUTROPHIL", gs, value = TRUE)[1:10])
