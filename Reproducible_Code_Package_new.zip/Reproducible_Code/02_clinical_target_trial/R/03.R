# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 步骤3：因果森林HTE + 策略树（G=48主分析框架内）【v2 修正版】
# 修正1：HTE目标人群 = 存活到分叉点的患者（adherent==1 & ev_before_div==0）
#   理由：分叉前死亡的克隆不可能经历治疗效应，且其结局在两臂共享，
#   会把森林叶内对比（等价于叶内Hajek）拉向零 → v1中ATE被稀释至-0.014。
# 修正2：policytree的predict()返回动作编号而非标签，v1中
#   opt=="early"全为FALSE → 错误得出"推荐0%早期"。已修复标签映射。
# 依赖：data.table, glmnet, grf, policytree
#   安装：install.packages(c("grf", "policytree"))
# 输入：[clinical output directory]/01_分析队列.csv
# 输出：[clinical output directory]/03_HTE结果.txt + 03_亚组CATE.csv
#       + 03_变量重要性.csv + 03_变量重要性.png + 03_CATE分布.png
# ================================================================

rm(list = ls())
suppressMessages({
  library(data.table)
  library(glmnet)
  library(grf)
  library(policytree)
})
set.seed(2026)

dir_mimic <- PATHS$mimic
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "03_HTE结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

dat <- fread(file.path(dir_out, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]

# ----------------------------------------------------------------
# 0. 与步骤2b一致的预处理（死亡时间 + 协变量 + 克隆 + 权重）
# ----------------------------------------------------------------
cat("== 0. 重建分析框架（同步骤2b-v5） ==\n")
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"),
               select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"),
               select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs   := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, death90_hrs := as.numeric(as.Date(dod) - as.Date(intime)) * 24]

dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
miss_vars <- paste0(num_vars, "_miss")
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]

build_clones <- function(dt, G) {
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early",   first_px_hrs)],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed", first_px_hrs)])
  cl[, t_div := fifelse(!is.na(first_px_hrs) & first_px_hrs <= G, first_px_hrs, G)]
  cl[, adherent := fcase(
    arm == "early"   & !is.na(first_px_hrs) & first_px_hrs <= G, 1L,
    arm == "delayed" & (is.na(first_px_hrs) | first_px_hrs > G), 1L,
    default = 0L)]
  cl
}

# 构建G=48克隆与权重（结局：院内死亡）
G <- 48
cl <- build_clones(dat, G)
cl[, Y := as.integer(dat[["hosp_mort"]][src_row])]
cl[, t_ev := dat[["death_hrs"]][src_row]]
cl[, ev_before_div := as.integer(!is.na(t_ev) & t_ev <= t_div)]
cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
Xall <- X_mm[cl$src_row, , drop = FALSE]
arm_all <- as.integer(cl$arm == "early")
p_all <- rep(NA_real_, nrow(cl))
for (a in 0:1) {
  idx <- which(arm_all == a)
  fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                     family = "binomial", nfolds = 5)
  p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                   s = "lambda.min", type = "response"))
}
p_all <- pmax(p_all, 0.01)
stab <- ave(cl$adherent, cl$arm, FUN = mean)
w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
w_all[cl$ev_before_div == 1] <- 1
pos <- cl$adherent == 1 & cl$ev_before_div == 0
qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])

# HTE分析集：存活到分叉点的依从克隆（两策略下均走到了治疗决策点）
# 这是唯一可能"经历"治疗效应的人群；分叉前死亡者结局已被共享归因处理，
# 不应进入HTE估计（v1错误：用kept==1全量克隆导致ATE被稀释）
kidx <- which(cl$adherent == 1 & cl$ev_before_div == 0)
X_cf <- Xall[kidx, , drop = FALSE]
Y_cf <- cl$Y[kidx]
W_cf <- arm_all[kidx]
w_cf <- w_all[kidx]
clu_cf <- cl$subject_id[kidx]
cat("HTE分析集（存活到分叉点）：", length(Y_cf), "条克隆（早期", sum(W_cf == 1),
    "，延迟", sum(W_cf == 0), "）\n")

# 自检：同一人群上的加权Hajek风险差（森林ATE应与此接近）
hajek_rd <- sum(w_cf[W_cf == 1] * Y_cf[W_cf == 1]) / sum(w_cf[W_cf == 1]) -
  sum(w_cf[W_cf == 0] * Y_cf[W_cf == 0]) / sum(w_cf[W_cf == 0])
cat(sprintf("自检-该人群加权Hajek RD：%.4f（森林ATE应≈此值；步骤2b全人群IPCW-HT为-0.058）\n\n",
            hajek_rd))

# ----------------------------------------------------------------
# 1. 因果森林
# ----------------------------------------------------------------
cat("== 1. 因果森林（2000树，带权重与聚类） ==\n")
cf <- causal_forest(X_cf, Y_cf, W_cf,
                    sample.weights = w_cf, clusters = clu_cf,
                    num.trees = 2000, seed = 2026)
tau <- predict(cf)$predictions

# 森林ATE（在存活到分叉点人群中，应与上面Hajek自检值接近，约-0.05~-0.08）
ate_cf <- average_treatment_effect(cf)
cat(sprintf("因果森林ATE：%.4f (SE %.4f)  [对照：上方Hajek自检值；步骤2b全人群 IPCW -0.058 / AIPW -0.062]\n",
            ate_cf[1], ate_cf[2]))
if (abs(ate_cf[1] - hajek_rd) > 0.03)
  cat("警告：森林ATE与Hajek自检值偏差>0.03，请检查权重或数据。\n")
cat("\n")

# ----------------------------------------------------------------
# 2. 校准检验 + 变量重要性
# ----------------------------------------------------------------
cat("== 2. 校准检验与变量重要性 ==\n")
calib <- test_calibration(cf)
print(calib)
cat("（mean.prediction≈1为校准良好；differential.prediction显著=HTE存在）\n\n")

vi <- variable_importance(cf)
vi_dt <- data.table(variable = colnames(X_cf), importance = as.numeric(vi))
setorder(vi_dt, -importance)
cat("变量重要性 Top 10：\n")
print(head(vi_dt, 10))
fwrite(vi_dt, file.path(dir_out, "03_变量重要性.csv"))

png(file.path(dir_out, "03_变量重要性.png"), width = 1600, height = 1200, res = 200)
par(mar = c(5, 10, 2, 1))
top15 <- head(vi_dt, 15)
barplot(rev(top15$importance), names.arg = rev(top15$variable), horiz = TRUE,
        las = 1, col = "#2C5F8A", xlab = "Variable importance")
dev.off()

png(file.path(dir_out, "03_CATE分布.png"), width = 1600, height = 1000, res = 200)
hist(tau, breaks = 50, col = "#2C5F8A", border = "white",
     main = "", xlab = "CATE（早期预防对院内死亡的个体效应，负值=保护）")
abline(v = ate_cf[1], col = "#C0392B", lwd = 2, lty = 2)
dev.off()

# ----------------------------------------------------------------
# 3. 预设亚组CATE（临床先验分层）
# ----------------------------------------------------------------
cat("\n== 3. 预设亚组CATE（目标人群：存活到分叉点者） ==\n")
src <- cl$src_row[kidx]
subgroups <- list(
  "GCS <8（深昏迷）"        = which(dat$gcs_total[src] < 8),
  "GCS 8-12"                = which(dat$gcs_total[src] >= 8 & dat$gcs_total[src] <= 12),
  "GCS >=13（轻症）"        = which(dat$gcs_total[src] >= 13),
  "脑室/开颅手术"           = which(dat$neurosx[src] == TRUE),
  "未手术"                  = which(dat$neurosx[src] == FALSE),
  "机械通气"                = which(dat$mech_vent[src] == TRUE),
  "未机械通气"              = which(dat$mech_vent[src] == FALSE),
  "年龄 <65岁"              = which(dat$anchor_age[src] < 65),
  "年龄 >=65岁"             = which(dat$anchor_age[src] >= 65),
  "INR >=1.5（凝血异常）"   = which(dat$inr[src] >= 1.5),
  "INR <1.5"                = which(dat$inr[src] < 1.5),
  "长期抗凝/抗血小板"       = which(dat$longterm_ac[src] == TRUE),
  "无长期抗凝"              = which(dat$longterm_ac[src] == FALSE)
)
sub_res <- rbindlist(lapply(names(subgroups), function(nm) {
  idx <- subgroups[[nm]]
  if (length(idx) < 50) return(data.table(subgroup = nm, n = length(idx),
                                          CATE = NA, SE = NA))
  est <- average_treatment_effect(cf, subset = idx)
  data.table(subgroup = nm, n = length(idx),
             CATE = round(est[1], 4), SE = round(est[2], 4))
}))
sub_res[, `:=`(CI_lo = round(CATE - 1.96 * SE, 4), CI_hi = round(CATE + 1.96 * SE, 4))]
print(sub_res)
fwrite(sub_res, file.path(dir_out, "03_亚组CATE.csv"))

# ----------------------------------------------------------------
# 4. 策略树（深度2，可解释临床规则）
# ----------------------------------------------------------------
cat("\n== 4. 策略树 ==\n")
dr_scores <- get_scores(cf)  # 每条的DR伪结局（CATE=早期-延迟的死亡差，负值=早期保护）
# 奖励矩阵：结局为死亡（越低越好），选"早期"的奖励 = -tau
Gamma <- cbind(delay = dr_scores, early = -dr_scores)
# 策略树用少数可解释变量
X_pol <- as.data.frame(dat[src, .(anchor_age, gcs_total, sbp, inr, platelet,
                                  mech_vent = as.integer(mech_vent),
                                  neurosx = as.integer(neurosx))])
ptree <- policy_tree(X_pol, Gamma, depth = 2)
cat("策略树规则：\n")
print(ptree)

# 策略价值评估
# 注意：policytree的predict()在多数版本返回动作编号(1/2)而非列名标签，
# v1直接用 opt=="early" 比较 → 全FALSE → 误判"推荐0%早期"。此处显式映射。
opt_raw <- predict(ptree, X_pol)
opt <- if (is.character(opt_raw) || is.factor(opt_raw)) {
  as.character(opt_raw)
} else {
  colnames(Gamma)[as.integer(opt_raw)]
}
cat("predict返回类型：", class(opt_raw)[1], "；映射后唯一值：",
    paste(unique(opt), collapse = ", "), "\n")
val_policy <- mean(ifelse(opt == "early", -dr_scores, dr_scores))
val_all_early <- mean(-dr_scores)
val_all_delay <- mean(dr_scores)
cat(sprintf("\n全员延迟价值: %.4f | 全员早期价值: %.4f | 策略树价值: %.4f\n",
            val_all_delay, val_all_early, val_policy))
cat(sprintf("策略树 vs 全员早期: %+.4f（>0说明分层优于一刀切）\n",
            val_policy - val_all_early))
cat("策略树推荐早期预防比例：", sprintf("%.1f%%", 100 * mean(opt == "early")), "\n")

# RATE（排序加权效应，评估靶向效率；grf版本不支持则跳过）
rate <- tryCatch({
  r <- rank_average_treatment_effect(cf, tau)
  cat(sprintf("\nRATE (AUTOC): %.4f (SE %.4f)；显著>0说明按CATE排序靶向治疗优于平均分配\n",
              r$estimate, r$std.err))
  r
}, error = function(e) { cat("\nRATE跳过：", conditionMessage(e), "\n"); NULL })

cat("\n结果已保存：03_亚组CATE.csv / 03_变量重要性.csv / 两个PNG\n")
sink()
cat("运行完毕，请查看 [clinical output directory]/03_HTE结果.txt
")
