# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# NWICU 可行性探查（外部验证前置步骤）
# 目的：确认 NWICU 0.1.0 是否满足复现 MIMIC-IV 主分析的最低要求
#   ① ICH 例数是否足够（目标：>=300 例 ICU stay）
#   ② 肝素/依诺肝素给药时间是否可得（prescriptions/emar）
#   ③ GCS 是否在 chartevents 中（d_items 匹配）
#   ④ 关键化验覆盖度（INR/血小板/血红蛋白/肌酐/血糖）
#   ⑤ 死亡时间可用性（admissions.deathtime / patients.dod）
#   ⑥ 排除标准可执行性（治疗剂量肝素、既往VTE）
# 用法：修改下方 dir_nwicu 为你本地的解压路径后 source() 运行
# 输出：[clinical output directory]/NWICU_探查结果.txt
# ================================================================

rm(list = ls())
suppressMessages(library(data.table))

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "NWICU_探查结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
cat("探查路径：", dir_nwicu, "\n\n")

# ----------------------------------------------------------------
# 0. 检查表结构（列出所有文件）
# ----------------------------------------------------------------
cat("== 0. 文件清单 ==\n")
flist <- list.files(dir_nwicu, recursive = TRUE, pattern = "\\.csv(\\.gz)?$")
print(flist)
cat("\n")

find_table <- function(name) {
  hit <- flist[grepl(paste0(name, "\\.csv"), basename(flist), ignore.case = TRUE)]
  if (length(hit) == 0) return(NULL)
  file.path(dir_nwicu, hit[1])
}

# ----------------------------------------------------------------
# 1. ICU stay 规模
# ----------------------------------------------------------------
cat("== 1. ICU stay 规模 ==\n")
f_icu <- find_table("icustays")
icu <- fread(f_icu)
cat("icustays 列名：", paste(names(icu), collapse = ", "), "\n")
cat("ICU stay 总数：", nrow(icu), "\n")
cat("唯一患者数：", uniqueN(icu$subject_id), "\n")
if ("first_careunit" %in% names(icu)) {
  cat("单元分布：\n"); print(icu[, .N, by = first_careunit][order(-N)])
}
icu[, intime := as.POSIXct(intime)]
cat("\n")

# ----------------------------------------------------------------
# 2. ICH 例数（ICD-10: I61*；ICD-9: 431）
# ----------------------------------------------------------------
cat("== 2. ICH 诊断 ==\n")
f_dx  <- find_table("diagnoses_icd")
f_dxd <- find_table("d_icd_diagnoses")
dx <- fread(f_dx)
cat("diagnoses_icd 列名：", paste(names(dx), collapse = ", "), "\n")
code_col <- intersect(c("icd_code", "icd10_code"), names(dx))[1]
ver_col  <- intersect(c("icd_version"), names(dx))[1]
if (!is.null(ver_col) && !is.na(ver_col)) {
  ich_dx <- dx[grepl("^I61", get(code_col)) |
                 (grepl("^431", get(code_col)) & get(ver_col) == 9)]
} else {
  ich_dx <- dx[grepl("^I61", get(code_col)) | grepl("^431", get(code_col))]
}
cat("ICH 诊断记录：", nrow(ich_dx), "条；唯一住院：", uniqueN(ich_dx$hadm_id), "\n")
ich_stays <- merge(ich_dx[, .(hadm_id = unique(hadm_id))],
                   icu[, .(stay_id, subject_id, hadm_id, intime)], by = "hadm_id")
cat("ICH 患者 ICU stay 数：", nrow(ich_stays), "\n\n")

# ----------------------------------------------------------------
# 3. 预防性抗凝给药时间（prescriptions + emar）
# ----------------------------------------------------------------
cat("== 3. 抗凝药物时间戳 ==\n")
f_rx <- find_table("prescriptions")
rx <- fread(f_rx)
cat("prescriptions 列名：", paste(names(rx), collapse = ", "), "\n")
drug_col <- intersect(c("drug", "medication", "med_name"), names(rx))[1]
route_ok <- "route" %in% names(rx)
time_col <- intersect(c("starttime", "start_time", "order_time"), names(rx))[1]
stopifnot(!is.na(drug_col), !is.na(time_col))
hep <- rx[grepl("HEPARIN|ENOXAPARIN", get(drug_col), ignore.case = TRUE)]
cat("肝素/依诺肝素处方记录：", nrow(hep), "\n")
if (route_ok) {
  cat("给药途径分布：\n"); print(hep[, .N, by = route][order(-N)][1:10])
}
# SC 预防剂量（排除 IV 治疗剂量）
hep_sc <- if (route_ok) {
  hep[grepl("SC|SUBCUT", route, ignore.case = TRUE) |
        grepl("ENOXAPARIN", get(drug_col), ignore.case = TRUE)]
} else hep
hep_sc[, t0 := as.POSIXct(get(time_col))]
hep_ich <- merge(hep_sc, ich_stays[, .(stay_id, hadm_id, intime)], by = "hadm_id")
hep_ich[, hrs := as.numeric(difftime(t0, intime, units = "hours"))]
first_px <- hep_ich[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
cat("ICH stay 中有 SC 抗凝记录的：", nrow(first_px), "/", nrow(ich_stays), "\n")
cat("首次给药时间分布（小时）：\n")
print(round(quantile(first_px$first_px_hrs, c(0.1, 0.25, 0.5, 0.75, 0.9)), 1))
cat("48h 内给药 stay 数：", sum(first_px$first_px_hrs <= 48), "\n\n")

# ----------------------------------------------------------------
# 4. GCS 可用性（d_items + chartevents）
# ----------------------------------------------------------------
cat("== 4. GCS 可用性 ==\n")
f_items <- find_table("d_items")
f_chart <- find_table("chartevents")
if (!is.null(f_items) && !is.null(f_chart)) {
  items <- fread(f_items)
  cat("d_items 列名：", paste(names(items), collapse = ", "), "\n")
  gcs_items <- items[grepl("glasgow|gcs", label, ignore.case = TRUE)]
  cat("GCS 相关 itemid：\n"); print(gcs_items[, .(itemid, label)])
  if (nrow(gcs_items) > 0) {
    ch_head <- names(fread(f_chart, nrows = 5))
    cat("chartevents 列名：", paste(ch_head, collapse = ", "), "\n")
    ch_idcol <- intersect(c("stay_id", "hadm_id"), ch_head)[1]
    ch_gcs <- fread(f_chart, select = c(ch_idcol, "itemid"))
    ch_gcs <- ch_gcs[itemid %in% gcs_items$itemid]
    cat("有 GCS 记录的", ch_idcol, "：", uniqueN(ch_gcs[[ch_idcol]]), "\n")
  }
} else cat("缺少 d_items 或 chartevents！\n")
cat("\n")

# ----------------------------------------------------------------
# 5. 关键化验覆盖度
# ----------------------------------------------------------------
cat("== 5. 化验覆盖度 ==\n")
f_lab  <- find_table("labevents")
f_labd <- find_table("d_labitems")
if (!is.null(f_lab) && !is.null(f_labd)) {
  labd <- fread(f_labd)
  targets <- list(INR = "inr|prothrombin", 血小板 = "platelet",
                  血红蛋白 = "hemoglobin", 肌酐 = "creatinine", 血糖 = "glucose")
  for (nm in names(targets)) {
    hit <- labd[grepl(targets[[nm]], label, ignore.case = TRUE)]
    cat(nm, "候选 itemid：", paste(head(hit$itemid, 5), collapse = ", "),
        "（", paste(head(hit$label, 3), collapse = " | "), "）\n")
  }
  lab_head <- names(fread(f_lab, nrows = 5))
  cat("labevents 列名：", paste(lab_head, collapse = ", "), "\n")
  lab_idcol <- intersect(c("stay_id", "hadm_id"), lab_head)[1]
  lab <- fread(f_lab, select = c(lab_idcol, "itemid"))
  denom <- if (lab_idcol == "stay_id") nrow(icu) else uniqueN(icu$hadm_id)
  for (nm in names(targets)) {
    hit <- labd[grepl(targets[[nm]], label, ignore.case = TRUE)]
    n_cov <- uniqueN(lab[itemid %in% hit$itemid][[lab_idcol]])
    cat(sprintf("%s：覆盖 %d/%d %s (%.0f%%)\n", nm, n_cov, denom, lab_idcol,
                100 * n_cov / denom))
  }
} else cat("缺少 labevents 或 d_labitems！\n")
cat("\n")

# ----------------------------------------------------------------
# 6. 死亡时间
# ----------------------------------------------------------------
cat("== 6. 死亡时间 ==\n")
f_adm <- find_table("admissions")
f_pat <- find_table("patients")
adm <- fread(f_adm)
cat("admissions 列名：", paste(names(adm), collapse = ", "), "\n")
cat("有 deathtime 的住院：", sum(!is.na(adm$deathtime)), "/", nrow(adm), "\n")
pat <- fread(f_pat)
cat("patients 列名：", paste(names(pat), collapse = ", "), "\n")
if ("dod" %in% names(pat))
  cat("有 dod 的患者：", sum(!is.na(pat$dod)), "/", nrow(pat), "\n")
cat("\n")

# ----------------------------------------------------------------
# 7. 排除标准可执行性
# ----------------------------------------------------------------
cat("== 7. 排除标准 ==\n")
iv_hep <- rx[grepl("HEPARIN", get(drug_col), ignore.case = TRUE)]
if (route_ok)
  iv_hep <- iv_hep[grepl("^IV$|INTRAVENOUS", route, ignore.case = TRUE)]
cat("IV 肝素（治疗剂量）记录：", nrow(iv_hep), "条，涉及住院：",
    uniqueN(iv_hep$hadm_id), "\n")
vte_prior <- dx[grepl("^I82|^I80|^I26|^453|^4151", get(code_col))]
cat("VTE 相关诊断记录：", nrow(vte_prior), "条\n")
cat("\n")

# ----------------------------------------------------------------
# 8. 结论
# ----------------------------------------------------------------
cat("== 8. 可行性结论（自动判断） ==\n")
n_ich <- nrow(ich_stays)
n_px  <- if (exists("first_px")) sum(first_px$first_px_hrs <= 48) else 0
cat("① ICH stay 数：", n_ich, ifelse(n_ich >= 300, "【充足】", "【偏少，需谨慎】"), "\n")
cat("② 48h内SC抗凝 stay 数：", n_px, ifelse(n_px >= 100, "【充足】", "【偏少】"), "\n")
cat("③ 请人工核对上方 GCS itemid 是否真实存在\n")
cat("④ 请人工核对化验覆盖度是否 >70%\n")

sink()
cat("探查完毕，请查看 [clinical output directory]/NWICU_探查结果.txt 并上传给我/n")

