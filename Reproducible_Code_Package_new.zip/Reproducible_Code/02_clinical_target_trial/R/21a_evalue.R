# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 重算 E-value（修正行列取法）
suppressMessages(library(EValue))
res <- data.frame(outcome = c("hosp_mort", "hosp_mort", "mort90", "mort90"),
                  method = c("IPCW", "AIPW", "IPCW", "AIPW"),
                  RR = c(0.7115, 0.7538, 0.7130, 0.8201),
                  lo = c(0.6378, 0.6462, 0.6565, 0.7300),
                  hi = c(0.7851, 0.8794, 0.7668, 0.9213))
out <- character()
for (i in seq_len(nrow(res))) {
  r <- evalues.RR(res$RR[i], res$lo[i], res$hi[i], rare = FALSE)
  ev_p  <- r["E-values", "point"]
  ev_ci <- r["E-values", "upper"]
  out <- c(out, sprintf("%s [%s]: RR=%.3f (%.3f-%.3f) -> E-value 点估计=%.2f, CI保守端=%.2f",
                        res$outcome[i], res$method[i], res$RR[i], res$lo[i],
                        res$hi[i], ev_p, ev_ci))
}
writeLines(out, file.path(PATHS$clinical, "21a_evalue_results.txt"))
print(out)
