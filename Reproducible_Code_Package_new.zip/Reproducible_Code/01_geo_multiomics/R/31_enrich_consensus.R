# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 31_enrich_consensus.R
# ORA (GO BP/CC/MF + KEGG) on cross-dataset consensus gene lists.
# GO uses local org.Hs.eg.db; KEGG needs the local proxy.
suppressPackageStartupMessages({
  library(clusterProfiler); library(org.Hs.eg.db); library(dplyr)
})
Sys.setenv(http_proxy = "http://127.0.0.1:7897",
           https_proxy = "http://127.0.0.1:7897")
root <- PATHS$project
resdir <- file.path(root, "02_results")
lists <- readRDS(file.path(resdir, "consensus_gene_lists.rds"))

to_entrez <- function(sym) {
  m <- bitr(sym, "SYMBOL", "ENTREZID", org.Hs.eg.db)
  m[!duplicated(m$SYMBOL), "ENTREZID"]
}

ora_all <- list()
for (nm in names(lists)) {
  sym <- lists[[nm]]
  if (length(sym) < 5) { cat(nm, "too few genes, skip\n"); next }
  ez <- to_entrez(sym)
  cat("\n###", nm, "(", length(sym), "symbols /", length(ez), "entrez )\n")
  for (ont in c("BP","CC","MF")) {
    e <- enrichGO(ez, OrgDb = org.Hs.eg.db, ont = ont,
                  pAdjustMethod = "BH", pvalueCutoff = 0.05,
                  qvalueCutoff = 0.2, readable = TRUE)
    df <- as.data.frame(e)
    if (nrow(df) > 0) {
      key <- paste0(nm, "_GO_", ont)
      ora_all[[key]] <- df
      cat(key, nrow(df), "terms\n")
    }
  }
  k <- tryCatch(enrichKEGG(ez, organism = "hsa", pvalueCutoff = 0.05),
                error = function(e) e)
  if (!inherits(k, "error") && nrow(as.data.frame(k)) > 0) {
    ora_all[[paste0(nm, "_KEGG")]] <- as.data.frame(
      setReadable(k, org.Hs.eg.db, "ENTREZID"))
    cat(nm, "KEGG", nrow(as.data.frame(k)), "pathways\n")
  } else {
    cat(nm, "KEGG unavailable (network)\n")
  }
}
saveRDS(ora_all, file.path(resdir, "consensus_ORA.rds"))
# flat table for the manuscript
flat <- bind_rows(lapply(names(ora_all), function(k) {
  d <- ora_all[[k]]; d$set <- k; d
}))
write.csv(flat, file.path(resdir, "consensus_ORA.csv"), row.names=FALSE)

cat("\n=== top cross-section UP GO BP ===\n")
if ("cs_up_GO_BP" %in% names(ora_all))
  print(head(ora_all$cs_up_GO_BP[,c("Description","p.adjust","Count")],12),
        row.names=FALSE)
cat("\n=== top cross-section DOWN GO BP ===\n")
if ("cs_dn_GO_BP" %in% names(ora_all))
  print(head(ora_all$cs_dn_GO_BP[,c("Description","p.adjust","Count")],12),
        row.names=FALSE)
cat("\n=== top longitudinal UP GO BP ===\n")
if ("lg_up_GO_BP" %in% names(ora_all))
  print(head(ora_all$lg_up_GO_BP[,c("Description","p.adjust","Count")],12),
        row.names=FALSE)
cat("\nconsensus ORA done\n")
