# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 90_peek_mechanism_inputs.R
r <- file.path(PATHS$project, "02_results")
cat("==== cross_section consensus (counts) ====\n")
cs <- read.csv(file.path(r, "cross_section_consensus.csv"), check.names = FALSE)
print(colnames(cs)); print(table(cs$consensus, useNA = "ifany"))
cat("\n==== longitudinal consensus ====\n")
lg <- read.csv(file.path(r, "longitudinal_consensus.csv"), check.names = FALSE)
print(colnames(lg)); print(table(lg$consensus, useNA = "ifany"))
cat("\n==== WGCNA module-trait ====\n")
mt <- read.csv(file.path(r, "GSE335924_WGCNA_module_trait.csv"),
               check.names = FALSE)
print(mt)
cat("\n==== WGCNA hubs (module 1 top) ====\n")
hb <- read.csv(file.path(r, "GSE335924_WGCNA_hubs.csv"), check.names = FALSE)
print(head(hb[hb$module == 1, ], 12))
cat("\n==== ssGSEA diffs ====\n")
for (f in c("GSE335924_immune_diff.csv", "GSE296792_immune_diff.csv")) {
  cat("--", f, "\n"); print(read.csv(file.path(r, f), check.names = FALSE))
}
cat("\n==== consensus ORA top by set ====\n")
ora <- read.csv(file.path(r, "consensus_ORA.csv"), check.names = FALSE)
print(colnames(ora)); print(table(ora$set))
for (s in unique(ora$set)) {
  cat("--", s, "\n")
  print(head(ora[ora$set == s, c("Description", "GeneRatio",
                                 "p.adjust", "Count")], 5))
}
