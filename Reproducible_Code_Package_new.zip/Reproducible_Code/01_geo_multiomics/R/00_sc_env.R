# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 检查单细胞整合包与 features 格式
for (p in c("harmony", "Seurat", "future"))
  cat(sprintf("%-10s %s\n", p,
              if (requireNamespace(p, quietly = TRUE)) "OK" else "MISSING"))
exdir <- file.path(PATHS$project, "00_data/GSE266873/extracted")
ff <- file.path(exdir, "GSM8255340_sample1_1_ICH_2h_features.tsv.gz")
feat <- read.delim(gzfile(ff), header = FALSE)
cat("\nfeatures dim:", dim(feat), "\n"); print(head(feat, 4))
bb <- file.path(exdir, "GSM8255340_sample1_1_ICH_2h_barcodes.tsv.gz")
cat("barcodes:", length(readLines(gzfile(bb))), "\n")
