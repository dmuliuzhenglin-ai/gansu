# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 71_dmp_gse179759.R
# DNA methylation differential analysis (GSE179759, EPIC, peripheral blood,
# 64 samples ICH vs normal). limma on M-values adjusting for gender, with EPIC
# probe annotation and cross-omics linking to bulk DEGs.
suppressPackageStartupMessages({
  library(limma); library(dplyr)
  library(IlluminaHumanMethylationEPICanno.ilm10b4.hg19)
})
root <- PATHS$project
dr <- file.path(root, "00_data/GSE179759")
resdir <- file.path(root, "02_results")

# ---- phenotype ----
es <- GEOquery::getGEO(filename = file.path(dr, "GSE179759_series_matrix.txt.gz"),
                       getGPL = FALSE)
pd <- Biobase::pData(es)
pd$sample_num <- as.numeric(sub("^SAMPLE ([0-9]+).*", "\\1", pd$title))
pd$disease <- factor(sub("disease state: ", "", pd[["disease state:ch1"]]))
pd$gender <- factor(sub("gender: ", "", pd[["gender:ch1"]]))
cat("disease:\n"); print(table(pd$disease))
cat("gender:\n"); print(table(pd$gender))

# ---- beta matrix (skip 4 comment lines) ----
beta <- as.matrix(read.csv(gzfile(file.path(dr,
  "GSE179759_Matrix_processed.csv.gz")), skip = 4, check.names = FALSE,
  row.names = 1))
colnames(beta) <- trimws(colnames(beta))
col_num <- as.numeric(sub("SAMPLE ", "", colnames(beta)))
# align columns to phenotype order
ord <- match(pd$sample_num, col_num)
beta <- beta[, ord, drop = FALSE]
cat("beta matrix:", nrow(beta), "probes x", ncol(beta), "samples\n")

# remove probes with missing/constant beta and sex chromosomes
keep <- rowSums(is.na(beta)) == 0 &
        apply(beta, 1, function(x) sd(x) > 0)
beta <- beta[keep, ]
# M-values
M <- log2(beta / (1 - beta))

# ---- limma DMP: disease + gender ----
design <- model.matrix(~disease + gender, data = pd)
fit <- lmFit(M, design)
fit <- eBayes(fit)
coef_name <- grep("disease", colnames(design), value = TRUE)[1]
dmp <- topTable(fit, coef = coef_name, number = Inf)
dmp$probe <- rownames(dmp)
# mean beta difference (ICH vs normal) for effect size
ich_idx <- which(pd$disease == "ICH"); norm_idx <- which(pd$disease != "ICH")
dbeta <- rowMeans(beta[, ich_idx]) - rowMeans(beta[, norm_idx])
dmp$delta_beta <- dbeta[match(dmp$probe, rownames(beta))]
dmp$regulation <- "NS"
dmp$regulation[dmp$adj.P.Val < 0.05 & dmp$delta_beta >= 0.15]  <- "hyper"
dmp$regulation[dmp$adj.P.Val < 0.05 & dmp$delta_beta <= -0.15] <- "hypo"
cat("\nDMP regulation:\n"); print(table(dmp$regulation))

# ---- EPIC annotation ----
ann <- getAnnotation(IlluminaHumanMethylationEPICanno.ilm10b4.hg19)
ann_df <- data.frame(probe = ann$Name, chr = ann$chr, pos = ann$pos,
                     gene = ann$UCSC_RefGene_Name,
                     gene_group = ann$UCSC_RefGene_Group,
                     island_relation = ann$Relation_to_Island,
                     stringsAsFactors = FALSE)
dmp <- dmp %>% left_join(ann_df, by = "probe")
# first gene symbol (annotations are ;-separated across transcripts)
dmp$gene_symbol <- sapply(strsplit(dmp$gene, ";"), function(x)
  if (length(x) == 1 && is.na(x)) NA else unique(x)[1])
dmp <- dmp %>% select(probe, gene_symbol, chr, pos, island_relation,
                      gene_group, logFC, delta_beta, P.Value = P.Value,
                      FDR = adj.P.Val, regulation)
write.csv(dmp, file.path(resdir, "GSE179759_DMP_all.csv"), row.names = FALSE)

# ---- gene-level methylation summary for significant DMPs ----
sig <- dmp %>% filter(regulation %in% c("hyper","hypo") & !is.na(gene_symbol))
gene_meth <- sig %>% group_by(gene_symbol, regulation) %>%
  summarise(n_probes = n(),
            mean_delta_beta = mean(delta_beta),
            min_FDR = min(FDR), .groups = "drop") %>%
  arrange(min_FDR)
write.csv(gene_meth, file.path(resdir, "GSE179759_DMR_gene_level.csv"),
          row.names = FALSE)
cat("\nsignificant DMPs with gene mapping:", nrow(sig), "\n")
cat("genes with differential methylation:", nrow(gene_meth), "\n")
print(head(gene_meth, 20), row.names = FALSE)

# ---- cross-omics: methylation vs bulk expression (opposite direction) ----
cs <- read.csv(file.path(resdir, "cross_section_consensus.csv"))
cs <- cs %>% select(gene, consensus)
link <- gene_meth %>%
  left_join(cs, by = c("gene_symbol" = "gene"))
link$concordant <- case_when(
  link$regulation == "hyper" & link$consensus == "consensus_down" ~ "hyper_down",
  link$regulation == "hypo"  & link$consensus == "consensus_up"   ~ "hypo_up",
  TRUE ~ NA_character_)
write.csv(link, file.path(resdir, "methyl_expression_link.csv"),
          row.names = FALSE)
cat("\nanti-correlated methylation-expression pairs:\n")
print(link[!is.na(link$concordant), ], row.names = FALSE)
saveRDS(list(dmp = dmp, gene_meth = gene_meth, link = link),
        file.path(resdir, "GSE179759_methylation.rds"))
cat("\nGSE179759 methylation analysis done\n")
