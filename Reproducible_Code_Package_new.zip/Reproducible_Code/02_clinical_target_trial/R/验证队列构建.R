# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# NWICU 步骤1：验证队列构建（与MIMIC步骤1对齐，降配版）
# 暴露：emar实际给药的预防剂量SC抗凝（肝素5000U/依诺肝素30-40mg）
#   排除：IV肝素、治疗剂量依诺肝素(>40mg单次)、既往VTE
# 协变量：年龄/性别/种族/保险/合并症/机械通气/神外会诊/
#         SBP/HR/血小板/血红蛋白/肌酐/血糖（无GCS、无INR——数据缺失）
# 输入：NWICU 0.1.0
# 输出：[clinical output directory]/N1_分析队列.csv + N1_队列摘要.txt
# ================================================================

rm(list = ls())
suppressMessages(library(data.table))

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "N1_队列摘要.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

rd <- function(rel, ...) fread(file.path(dir_nwicu, rel), ...)

# ----------------------------------------------------------------
# 1. ICH 队列：ICD-10 I61*（主诊断或任意诊断）+ ICU stay
# ----------------------------------------------------------------
cat("== 1. ICH 队列 ==\n")
icu <- rd("data/nw_icu/icustays.csv.gz")
icu[, intime := as.POSIXct(intime)]
dx  <- rd("data/nw_hosp/diagnoses_icd.csv.gz")
ich_dx <- dx[grepl("^I61", icd_code) | (grepl("^431", icd_code) & icd_version == 9)]
cohort <- merge(ich_dx[, .(hadm_id = unique(hadm_id))],
                icu, by = "hadm_id")
cat("ICH ICU stay：", nrow(cohort), "；唯一患者：", uniqueN(cohort$subject_id), "\n")

# ----------------------------------------------------------------
# 2. 暴露：emar 实际给药的预防剂量 SC 抗凝
# ----------------------------------------------------------------
cat("\n== 2. 暴露（emar实际给药） ==\n")
emar <- rd("data/nw_hosp/emar.csv.gz")
emar[, charttime := as.POSIXct(charttime)]
# 预防剂量：肝素5000U注射（Injection/Subcutaneous）或依诺肝素30/40mg
proph <- emar[
  (grepl("HEPARIN.*5000", medication, ignore.case = TRUE) &
     !grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("30 MG|40 MG", medication, ignore.case = TRUE))
]
proph <- proph[event_txt == "Administered" | is.na(event_txt)]
cat("预防剂量给药记录：", nrow(proph), "\n")
px <- merge(proph[, .(hadm_id, charttime)],
            cohort[, .(stay_id, hadm_id, intime)], by = "hadm_id")
px[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
first_px <- px[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
cohort <- merge(cohort, first_px, by = "stay_id", all.x = TRUE, sort = FALSE)
cat("有预防抗凝的 stay：", sum(!is.na(cohort$first_px_hrs)), "/",
    nrow(cohort), "；48h内：", sum(cohort$first_px_hrs <= 48, na.rm = TRUE), "\n")

# ----------------------------------------------------------------
# 3. 排除：治疗剂量抗凝（IV肝素/大剂量依诺肝素）、既往VTE
# ----------------------------------------------------------------
cat("\n== 3. 排除 ==\n")
therap <- emar[
  (grepl("HEPARIN", medication, ignore.case = TRUE) &
     grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("80 MG|100 MG|120 MG|150 MG", medication, ignore.case = TRUE))
]
therap <- therap[event_txt == "Administered" | is.na(event_txt)]
iv_hadms <- unique(therap$hadm_id)
n0 <- nrow(cohort)
cohort <- cohort[!hadm_id %in% iv_hadms]
cat("排除治疗剂量抗凝：", n0 - nrow(cohort), "；剩余", nrow(cohort), "\n")

vte_prior <- dx[grepl("^I26|^I80|^I82|^453|^4151", icd_code)]
cohort <- cohort[!hadm_id %in% unique(vte_prior$hadm_id)]
cat("排除既往/并存VTE后：", nrow(cohort), "\n")

# ----------------------------------------------------------------
# 4. 人口学 + 合并症（ICD）
# ----------------------------------------------------------------
cat("\n== 4. 人口学与合并症 ==\n")
pat <- rd("data/nw_hosp/patients.csv.gz")
adm <- rd("data/nw_hosp/admissions.csv.gz")
cohort <- merge(cohort, pat[, .(subject_id, gender, anchor_age)], by = "subject_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, adm[, .(hadm_id, race, insurance, admission_type,
                                deathtime, hospital_expire_flag)],
                by = "hadm_id", all.x = TRUE, sort = FALSE)
dx_all <- dx[hadm_id %in% cohort$hadm_id]
flag_dx <- function(p10, p9) {
  hit <- dx_all[grepl(p10, icd_code) & icd_version == 10 |
                  grepl(p9, icd_code) & icd_version == 9]
  unique(hit$hadm_id)
}
cohort[, `:=`(
  hypertension = hadm_id %in% flag_dx("^I1[0-5]", "^401|^402|^403|^405"),
  diabetes     = hadm_id %in% flag_dx("^E1[01]", "^250"),
  atrial_fib   = hadm_id %in% flag_dx("^I48", "^42731"),
  ckd          = hadm_id %in% flag_dx("^N18", "^585"),
  liver_dz     = hadm_id %in% flag_dx("^K7[0-6]", "^571"),
  malignancy   = hadm_id %in% flag_dx("^C", "^1[4-9][0-9]|^2[0-3][0-9]"),
  longterm_ac  = hadm_id %in% flag_dx("^Z7901|^Z7902", "^V5812|^V5861")
)]
# 既往卒中：历史编码 + 入院前就诊（NWICU单库仅能用历史编码）
cohort[, prior_stroke := hadm_id %in% flag_dx("^I69|^Z8673", "^438|^V1254")]
cat("合并症患病率（%%）：\n")
print(round(100 * cohort[, lapply(.SD, mean),
                         .SDcols = c("hypertension","diabetes","atrial_fib","ckd","liver_dz",
                                     "malignancy","longterm_ac","prior_stroke")], 1))

# ----------------------------------------------------------------
# 5. 机械通气 + 神经外科会诊（chartevents/procedureevents）
# ----------------------------------------------------------------
cat("\n== 5. 机械通气与神经外科 ==\n")
items <- rd("data/nw_icu/d_items.csv.gz")
vent_items <- items[grepl("ventilat|vent mode|intubat|mechanical vent", label,
                          ignore.case = TRUE)]
cat("通气相关 itemid：\n"); print(vent_items[, .(itemid, label)][1:15])
ch_head <- names(rd("data/nw_icu/chartevents.csv.gz", nrows = 5))
cat("chartevents 列名：", paste(ch_head, collapse = ", "), "\n")
ch_id <- intersect(c("stay_id", "hadm_id"), ch_head)[1]
ch <- rd("data/nw_icu/chartevents.csv.gz",
         select = c(ch_id, "itemid", "charttime", "value", "valuenum"))
# 机械通气：出现通气itemid记录
vent_stays <- unique(ch[itemid %in% vent_items$itemid][[ch_id]])
if (ch_id == "hadm_id") {
  cohort[, mech_vent := hadm_id %in% vent_stays]
} else {
  cohort[, mech_vent := stay_id %in% vent_stays]
}
# 神经外科会诊（CONSULT TO NEUROSURGERY = 715711）
nsx_ids <- items[grepl("NEUROSURG", label, ignore.case = TRUE)]$itemid
nsx_stays <- unique(ch[itemid %in% nsx_ids][[ch_id]])
cohort[, neurosx := if (ch_id == "hadm_id") hadm_id %in% nsx_stays
       else stay_id %in% nsx_stays]
cat("机械通气：", sum(cohort$mech_vent), "；神外会诊/介入：", sum(cohort$neurosx), "\n")

# ----------------------------------------------------------------
# 6. 生命体征：SBP/HR 首24h（自动搜索itemid）
# ----------------------------------------------------------------
cat("\n== 6. 生命体征 ==\n")
sbp_items <- items[grepl("systolic|sbp|blood pressure.*sys|arterial.*sys", label,
                         ignore.case = TRUE)]
hr_items  <- items[grepl("^heart rate|heart rate$|pulse", label, ignore.case = TRUE)]
cat("SBP候选：\n"); print(sbp_items[, .(itemid, label)][1:10])
cat("HR候选：\n"); print(hr_items[, .(itemid, label)][1:10])
ch[, charttime := as.POSIXct(charttime)]
ch_c <- merge(ch, cohort[, .(stay_id, hadm_id, intime)],
              by = ch_id, sort = FALSE)
ch_c[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
ch24 <- ch_c[hrs >= 0 & hrs <= 24 & !is.na(valuenum)]
# 非侵入SBP优先（避免"Arterial"有创与无创混合；取候选中含non-invasive/NBP的）
sbp_id <- sbp_items$itemid[1]
hr_id  <- hr_items$itemid[1]
v_sbp <- ch24[itemid == sbp_id & valuenum >= 40 & valuenum <= 280,
              .(sbp = median(valuenum)), by = ch_id]
v_hr  <- ch24[itemid == hr_id & valuenum >= 30 & valuenum <= 220,
              .(hr = median(valuenum)), by = ch_id]
if (ch_id == "hadm_id") {
  cohort <- merge(cohort, v_sbp, by = "hadm_id", all.x = TRUE, sort = FALSE)
  cohort <- merge(cohort, v_hr,  by = "hadm_id", all.x = TRUE, sort = FALSE)
} else {
  cohort <- merge(cohort, v_sbp, by = "stay_id", all.x = TRUE, sort = FALSE)
  cohort <- merge(cohort, v_hr,  by = "stay_id", all.x = TRUE, sort = FALSE)
}
cat(sprintf("SBP覆盖：%.0f%%；HR覆盖：%.0f%%\n",
            100 * mean(!is.na(cohort$sbp)), 100 * mean(!is.na(cohort$hr))))

# ----------------------------------------------------------------
# 7. 化验：首24h中位数
# ----------------------------------------------------------------
cat("\n== 7. 化验 ==\n")
labd <- rd("data/nw_hosp/d_labitems.csv.gz")
lab <- rd("data/nw_hosp/labevents.csv.gz",
          select = c("hadm_id", "itemid", "charttime", "valuenum"))
lab[, charttime := as.POSIXct(charttime)]
lab_c <- merge(lab, unique(cohort[, .(hadm_id, intime)]), by = "hadm_id")
lab_c[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
lab24 <- lab_c[hrs >= 0 & hrs <= 24 & !is.na(valuenum)]
get_lab <- function(pattern, nm) {
  ids <- labd[grepl(pattern, label, ignore.case = TRUE)]$itemid
  v <- lab24[itemid %in% ids, .(v = median(valuenum)), by = hadm_id]
  setnames(v, "v", nm)
  v
}
cohort <- merge(cohort, get_lab("platelet", "platelet"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, get_lab("^hemoglobin", "hemoglobin"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, get_lab("^creatinine$", "creatinine"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, get_lab("^glucose", "glucose"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cat("化验覆盖度：\n")
print(round(100 * cohort[, lapply(.SD, function(x) mean(!is.na(x))),
                         .SDcols = c("platelet","hemoglobin","creatinine","glucose")], 1))

# ----------------------------------------------------------------
# 8. 结局
# ----------------------------------------------------------------
cat("\n== 8. 结局 ==\n")
cohort[, death_hrs := as.numeric(difftime(as.POSIXct(deathtime), intime,
                                          units = "hours"))]
cohort[, hosp_mort := as.integer(hospital_expire_flag == 1)]
pat_dod <- pat[, .(subject_id, dod)]
cohort <- merge(cohort, pat_dod, by = "subject_id", all.x = TRUE, sort = FALSE)
cohort[, death90_hrs := as.numeric(as.Date(dod) - as.Date(intime)) * 24]
cohort[, mort90 := as.integer(!is.na(death90_hrs) & death90_hrs <= 90 * 24)]
cat("院内死亡：", sum(cohort$hosp_mort == 1), sprintf("(%.1f%%)",
                                                 100 * mean(cohort$hosp_mort)), "\n")
cat("90天死亡：", sum(cohort$mort90 == 1), sprintf("(%.1f%%)",
                                               100 * mean(cohort$mort90)), "\n")
cat("（VTE结局：NWICU的VTE仅出院ICD编码，与MIMIC同口径，TTE时构建）\n")
cohort[, vte := hadm_id %in% flag_dx("^I26|^I82", "^4151|^453")]

# ----------------------------------------------------------------
# 9. 保存
# ----------------------------------------------------------------
keep_cols <- c("subject_id","hadm_id","stay_id","intime","anchor_age","gender",
               "race","insurance","admission_type","hypertension","diabetes",
               "prior_stroke","atrial_fib","ckd","liver_dz","malignancy",
               "longterm_ac","mech_vent","neurosx","sbp","hr","platelet",
               "hemoglobin","creatinine","glucose","first_px_hrs","vte",
               "hosp_mort","mort90","death_hrs","death90_hrs")
out <- cohort[, ..keep_cols]
fwrite(out, file.path(dir_out, "N1_分析队列.csv"))
cat("\n最终队列：", nrow(out), " stay\n")
cat("已保存：", file.path(dir_out, "N1_分析队列.csv"), "\n")
sink()
cat("完成，请上传 N1_队列摘要.txt\n")
