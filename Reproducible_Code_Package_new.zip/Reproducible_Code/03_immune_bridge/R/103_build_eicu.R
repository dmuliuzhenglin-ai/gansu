# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
## 103_build_eicu.R
## eICU：构建淋巴细胞绝对值/NLR/单核%的 0-96h 分窗数据集 + 基线 ALBI

suppressPackageStartupMessages(library(data.table))

in_cohort <- file.path(PATHS$clinical_src, "E1_分析队列.csv")
in_labs   <- file.path(PATHS$project, "05_bridge_immune/00_data/eicu_labs_subset.csv.gz")
out_dir   <- file.path(PATHS$project, "05_bridge_immune/01_data")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

co <- fread(in_cohort, encoding = "UTF-8")
co[, first_px_hrs := as.numeric(first_px_hrs)]
co[, early := as.integer(!is.na(first_px_hrs) & first_px_hrs <= 48)]
cat("cohort:", nrow(co), " early:", sum(co$early), "\n")

lab <- fread(in_labs, encoding = "UTF-8")
lab[, item := fcase(
  labname == "WBC x 1000", "wbc",
  labname == "-lymphs", "lym_pct",
  labname == "-polys", "neut_pct",
  labname == "-monos", "mono_pct",
  labname == "albumin", "alb",
  labname == "total bilirubin", "bili",
  default = NA_character_
)]
lab <- lab[!is.na(item)]

## 值域清洗
lab <- lab[
  (item == "wbc"      & labresult > 0.1 & labresult < 100) |
  (item == "lym_pct"  & labresult >= 0  & labresult <= 100) |
  (item == "neut_pct" & labresult >= 0  & labresult <= 100) |
  (item == "mono_pct" & labresult >= 0  & labresult <= 60)  |
  (item == "alb"      & labresult > 0.5 & labresult < 6)    |
  (item == "bili"     & labresult > 0.1 & labresult < 50)
]

lab <- merge(lab[, .(stay_id = patientunitstayid, off = labresultoffset, item, labresult)],
             co[, .(stay_id, early, first_px_hrs, los_icu_hrs, hosp_mort, gcs, age,
                    mech_vent, neurosx, platelet, creatinine, hemoglobin, ckd, liver)],
             by = "stay_id")

lab <- lab[off >= -360 & off <= 5760]
lab[, win := fcase(
  off >= -360 & off < 1440, "W0",
  off >= 1440 & off < 2880, "W24",
  off >= 2880 & off < 4320, "W48",
  off >= 4320 & off < 5760, "W72",
  default = NA_character_
)]
lab <- lab[!is.na(win)]

lab[, dist0 := abs(off)]
base <- lab[win == "W0", .SD[which.min(dist0)], by = .(stay_id, item), .SDcols = c("labresult")]
base[, win := "W0"]
post <- lab[win != "W0", .(labresult = mean(labresult, na.rm = TRUE), n_meas = .N), by = .(stay_id, win, item)]
wide_l <- rbind(base[, .(stay_id, win, item, labresult, n_meas = 1L)], post)

w <- dcast(wide_l, stay_id + win ~ item, value.var = "labresult")

## 绝对值：优先直接测值（本库无直接 ALC，均由 WBC × % 推导）
w[, alc := fifelse(!is.na(wbc) & !is.na(lym_pct), wbc * lym_pct / 100, NA_real_)]
w[, anc := fifelse(!is.na(wbc) & !is.na(neut_pct), wbc * neut_pct / 100, NA_real_)]
w[, amc := fifelse(!is.na(wbc) & !is.na(mono_pct), wbc * mono_pct / 100, NA_real_)]
w[, nlr := fifelse(!is.na(anc) & !is.na(alc) & alc > 0, pmin(anc / alc, 100), NA_real_)]

w <- merge(w, co[, .(stay_id, early, first_px_hrs, los_icu_hrs, hosp_mort, gcs, age,
                     mech_vent, neurosx, platelet, creatinine, hemoglobin, ckd, liver,
                     gender, ethnicity, hospitalid)],
           by = "stay_id", all.x = TRUE)

long <- melt(w[, .(stay_id, win, alc, nlr, mono_pct, lym_pct, wbc, anc, early,
                   first_px_hrs, los_icu_hrs, hosp_mort, gcs, age, mech_vent, neurosx,
                   platelet, creatinine, hemoglobin, ckd, liver, hospitalid)],
             id.vars = c("stay_id", "win", "early", "first_px_hrs", "los_icu_hrs", "hosp_mort",
                         "gcs", "age", "mech_vent", "neurosx", "platelet", "creatinine",
                         "hemoglobin", "ckd", "liver", "hospitalid"),
             variable.name = "metric", value.name = "value")
long <- long[!is.na(value)]
long[, win_f := factor(win, levels = c("W0", "W24", "W48", "W72"))]
fwrite(long, file.path(out_dir, "eicu_bridge_long.csv"))

b <- w[win == "W0"]
b[, albi := 0.66 * log10(bili) - 0.085 * (alb * 10)]
b[, albi_grade := fcase(is.na(albi), NA_integer_, albi <= -2.60, 1L,
                        albi <= -1.39, 2L, default = 3L)]
fwrite(b, file.path(out_dir, "eicu_bridge_baseline.csv"))

av <- w[, .(n_stay = .N, n_wbc = sum(!is.na(wbc)), n_alc = sum(!is.na(alc)),
            n_nlr = sum(!is.na(nlr)), n_mono = sum(!is.na(mono_pct)),
            n_alb = sum(!is.na(alb)), n_bili = sum(!is.na(bili))), by = win]
print(av)
cat("ALBI available:", sum(!is.na(b$albi)), "\n")
cat("long rows:", nrow(long), "\n")
fwrite(av, file.path(out_dir, "eicu_availability.csv"))
