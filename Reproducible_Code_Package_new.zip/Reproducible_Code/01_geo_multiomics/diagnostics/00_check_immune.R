# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 检查免疫浸润可用资源
for (p in c("msigdbr", "GSVA", "preprocessCore")) {
  cat(sprintf("%-15s %s\n", p,
              if (requireNamespace(p, quietly = TRUE)) "OK" else "MISSING"))
}
# 测试通过代理访问公开免疫 GMT（CIBERSORT LM22 常用镜像）
url <- "https://raw.githubusercontent.com/ibiods/CIBERSORT/master/LM22.txt"
res <- tryCatch({
  tmp <- tempfile()
  st <- system2("curl.exe",
    c("--ssl-no-revoke", "-x", "http://127.0.0.1:7897", "-sIL", url,
      "-o", tmp, "-w", "%{http_code}"), stdout = TRUE)
  st
}, error = function(e) conditionMessage(e))
cat("\nLM22 mirror HTTP status:", res, "\n")
