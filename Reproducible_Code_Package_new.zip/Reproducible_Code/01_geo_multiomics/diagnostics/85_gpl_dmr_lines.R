# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 提取 GPL soft 中含 dmr 的行及其上下文
f <- file.path(PATHS$project, "00_data/GSE43618/GPL16517_family.soft.gz")
con <- gzfile(f); lines <- readLines(con); close(con)
dmr_idx <- grep("dmr", lines)
cat("dmr line indices range:", range(dmr_idx), "\n")
print(head(lines[dmr_idx], 10))
# 看 dmr 区域附近的表结构
cat("\ncontext around first dmr:\n")
print(lines[(dmr_idx[1] - 3):(dmr_idx[1] + 3)])
