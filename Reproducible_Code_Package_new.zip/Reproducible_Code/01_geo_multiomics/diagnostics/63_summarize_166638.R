# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 汇总 GSE166638 结果
resdir <- file.path(PATHS$project, "02_results")
cat("=== BLD vs HEF composition (long) ===\n")
comp <- read.csv(file.path(resdir, "GSE166638_composition_source.csv"))
print(comp)
cat("\n=== wide proportion ===\n")
print(tidyr::pivot_wider(comp, names_from = Var2, values_from = Freq))

cat("\n=== hub pct expressing (first 25 rows) ===\n")
hp <- read.csv(file.path(resdir, "GSE166638_hub_pct_expressing.csv"),
               check.names = FALSE, row.names = 1)
print(round(hp[1:25, ], 2))

cat("\n=== files present ===\n")
grep("GSE166638", list.files(resdir), value = TRUE)
