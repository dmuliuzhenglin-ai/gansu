# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
r <- file.path(PATHS$project, "02_results")
cat("==== DMR_gene_level ====\n")
dmr <- read.csv(file.path(r, "GSE179759_DMR_gene_level.csv"), check.names = FALSE)
print(dim(dmr)); print(colnames(dmr)); print(head(dmr, 10))
cat("\n==== methyl_expression_link ====\n")
mel <- read.csv(file.path(r, "methyl_expression_link.csv"), check.names = FALSE)
print(dim(mel)); print(colnames(mel)); print(mel)
cat("\n==== miRNA_mRNA_network ====\n")
net <- read.csv(file.path(r, "miRNA_mRNA_network.csv"), check.names = FALSE)
print(dim(net)); print(colnames(net)); print(head(net, 8))
cat("\nmiRNA counts (top):\n")
print(sort(table(net$miRNA), decreasing = TRUE)[1:15])
cat("\nunique target genes:", length(unique(net$target)), "\n")
