# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 检查 GPL soft 原始文本是否含 dmr
f <- file.path(PATHS$project, "00_data/GSE43618/GPL16517_family.soft.gz")
con <- gzfile(f); lines <- readLines(con); close(con)
cat("total lines:", length(lines), "\n")
cat("lines containing dmr:", sum(grepl("dmr", lines)), "\n")
# 看一个完整平台块的结构
idx <- grep("^\\^PLATFORM", lines)
cat("platform block start:", idx, "\n")
print(head(lines[idx:(idx + 25)], 25))
