# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R",
                "../../../config_paths.R", "../../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# Final Figure S1: causal forest on the shipped clone set (kept = adherent |
# event-before-divergence, n = 2,303 clones), pre-specified GCS bins 3-8/9-12/13-15.
# Also reports variable importance so the text can be updated from the same fit.
suppressMessages({
  library(data.table); library(glmnet); library(grf); library(ggplot2)
})
set.seed(2026)
dir_mimic <- PATHS$mimic
dir_clin  <- PATHS$clinical
dir_out   <- file.path(PATHS$project, "03_figures")

dat <- fread(file.path(dir_clin, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"), select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"), select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, race4 := fcase(grepl("WHITE", race, ignore.case = TRUE), "White",
                     grepl("BLACK", race, ignore.case = TRUE), "Black",
                     grepl("ASIAN", race, ignore.case = TRUE), "Asian", default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4 := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, paste0(num_vars, "_miss")),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]

G <- 48
cl <- rbind(dat[, .(stay_id, subject_id, src_row = .I, arm = "early", first_px_hrs)],
            dat[, .(stay_id, subject_id, src_row = .I, arm = "delayed", first_px_hrs)])
cl[, t_div := fifelse(!is.na(first_px_hrs) & first_px_hrs <= G, first_px_hrs, G)]
cl[, adherent := fcase(arm == "early" & !is.na(first_px_hrs) & first_px_hrs <= G, 1L,
                       arm == "delayed" & (is.na(first_px_hrs) | first_px_hrs > G), 1L,
                       default = 0L)]
cl[, Y := as.integer(dat[["hosp_mort"]][src_row])]
cl[, t_ev := dat[["death_hrs"]][src_row]]
cl[, ev_before_div := as.integer(!is.na(t_ev) & t_ev <= t_div)]
cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
Xall <- X_mm[cl$src_row, , drop = FALSE]
arm_all <- as.integer(cl$arm == "early")
p_all <- rep(NA_real_, nrow(cl))
for (a in 0:1) {
  idx <- which(arm_all == a)
  fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx], family = "binomial", nfolds = 5)
  p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE], s = "lambda.min", type = "response"))
}
p_all <- pmax(p_all, 0.01)
stab <- ave(cl$adherent, cl$arm, FUN = mean)
w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
w_all[cl$ev_before_div == 1] <- 1
pos <- cl$adherent == 1 & cl$ev_before_div == 0
qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])

kidx <- which(cl$kept == 1)
X_cf <- Xall[kidx, , drop = FALSE]; Y_cf <- cl$Y[kidx]; W_cf <- arm_all[kidx]
w_cf <- w_all[kidx]; clu_cf <- cl$subject_id[kidx]

cf <- causal_forest(X_cf, Y_cf, W_cf, sample.weights = w_cf, clusters = clu_cf,
                    num.trees = 2000, seed = 2026)
ate <- average_treatment_effect(cf)
cat(sprintf("n_kept=%d  ate=%.4f (se %.4f)\n", length(Y_cf), ate[1], ate[2]))

vi <- variable_importance(cf)
vi_dt <- data.table(variable = colnames(X_cf), importance = as.numeric(vi))
setorder(vi_dt, -importance)
cat("VI top10:\n"); print(head(vi_dt, 10))
fwrite(vi_dt, file.path(dir_out, "FigureS1_variable_importance.csv"))

src <- cl$src_row[kidx]
g <- dat$gcs_total[src]
sub <- list(
  "GCS 3-8 (deep coma)" = which(g >= 3 & g <= 8),
  "GCS 9-12" = which(g >= 9 & g <= 12),
  "GCS 13-15 (mild)" = which(g >= 13 & g <= 15),
  "Neurosurgical procedure" = which(dat$neurosx[src] == TRUE),
  "No neurosurgical procedure" = which(dat$neurosx[src] == FALSE),
  "Mechanical ventilation" = which(dat$mech_vent[src] == TRUE),
  "No mechanical ventilation" = which(dat$mech_vent[src] == FALSE),
  "Age <65 y" = which(dat$anchor_age[src] < 65),
  "Age ≥65 y" = which(dat$anchor_age[src] >= 65),
  "INR ≥1.5" = which(dat$inr[src] >= 1.5),
  "INR <1.5" = which(dat$inr[src] < 1.5),
  "Long-term anticoag/antiplatelet" = which(dat$longterm_ac[src] == TRUE),
  "No long-term anticoagulation" = which(dat$longterm_ac[src] == FALSE))

res <- rbindlist(lapply(names(sub), function(nm) {
  i <- sub[[nm]]
  if (length(i) < 50) return(data.table(subgroup = nm, n = length(i), cate = NA_real_, se = NA_real_))
  e <- average_treatment_effect(cf, subset = i)
  data.table(subgroup = nm, n = length(i), cate = e[1], se = e[2])
}))
res[, `:=`(lo = cate - 1.96 * se, hi = cate + 1.96 * se)]
res[, sig := !(lo < 0 & hi > 0)]
res[, lab := sprintf("%s (n = %d)", subgroup, n)]
print(res)
fwrite(res, file.path(dir_out, "FigureS1_subgroup_cate.csv"))

res[, lab := factor(lab, levels = rev(lab))]
p <- ggplot(res, aes(x = cate, y = lab, colour = sig)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "grey40") +
  geom_errorbar(aes(xmin = lo, xmax = hi), width = 0.22, linewidth = 0.45, orientation = "y") +
  geom_point(size = 2.1) +
  scale_colour_manual(values = c(`TRUE` = "#C0392B", `FALSE` = "#2E6DA4"), guide = "none") +
  labs(title = "Exploratory subgroup treatment effects (causal forest, MIMIC-IV)",
       x = "CATE (early vs delayed) on in-hospital mortality\nnegative = early prophylaxis protective",
       y = NULL) +
  theme_bw(base_size = 9) +
  theme(panel.grid.minor = element_blank(),
        plot.title = element_text(size = 10, face = "bold", hjust = 0.5),
        axis.text.y = element_text(size = 8),
        axis.title.x = element_text(size = 8))
ggsave(file.path(dir_out, "FigureS1_subgroup_cate.pdf"), p, width = 7.2, height = 5.2, device = cairo_pdf)
ggsave(file.path(dir_out, "FigureS1_subgroup_cate.png"), p, width = 7.2, height = 5.2, dpi = 300)
cat("done\n")
