# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 90_mirna_network.R
# Differential miRNA analysis and miRNA-mRNA regulatory network.
# GSE43618 plasma (ICH vs control, exploratory) and GSE296792 whole blood
# (paired longitudinal). Targets from MSigDB C3 MIRDB; links require opposite
# direction to bulk DEGs.
suppressPackageStartupMessages({
  library(limma); library(msigdbr); library(dplyr); library(GEOquery)
})
root <- PATHS$project
resdir <- file.path(root, "02_results")

# ---------- GSE43618: ICH vs control (n=2 per group, exploratory) ----------
e436 <- getGEO(filename = file.path(root,
  "00_data/GSE43618/GSE43618_series_matrix.txt.gz"), getGPL = FALSE)
ex436 <- exprs(e436); pd436 <- pData(e436)
keep_row <- grepl("^hsa", rownames(ex436))
ex436 <- ex436[keep_row, ]
grp <- ifelse(grepl("ICH", pd436$title), "ICH",
       ifelse(grepl("control", pd436$title), "control", "ischemic"))
keep_col <- grp %in% c("ICH","control")
m436 <- ex436[, keep_col]; g436 <- factor(grp[keep_col])
d436 <- model.matrix(~g436)
f436 <- eBayes(lmFit(m436, d436))
t436 <- topTable(f436, coef = "g436ICH", number = Inf)
t436$mir <- rownames(t436)
t436 <- t436 %>% transmute(mir, logFC, PValue = P.Value, FDR = adj.P.Val)
write.csv(t436, file.path(resdir, "GSE43618_miRNA_diff.csv"), row.names = FALSE)
cat("GSE43618 ICH vs control (small n, exploratory):\n")
print(head(t436, 10), row.names = FALSE)

# ---------- GSE296792: paired longitudinal ----------
mi <- as.matrix(read.csv(gzfile(file.path(root,
  "00_data/GSE296792/GSE296792_Normalized_miRNA_counts_v1.csv.gz")),
  check.names = FALSE, row.names = 1))
logmi <- log2(mi + 1)
sids <- colnames(logmi)
pat <- sub("_(base|bas|72h|7day|7da)$", "", sids)
tp <- gsub("bas$","base", gsub("7da$","7day", sub("^.*_","", sids)))
design <- model.matrix(~0 + factor(tp))
colnames(design) <- c("base","t72h","t7day")
corfit <- duplicateCorrelation(logmi, design, block = pat)
fit <- lmFit(logmi, design, block = pat, correlation = corfit$consensus.correlation)
fit <- contrasts.fit(fit, makeContrasts(d7_base = t7day - base, levels = design))
fit <- eBayes(fit, trend = TRUE, robust = TRUE)
t296 <- topTable(fit, coef = "d7_base", number = Inf)
t296$mir <- rownames(t296)
t296 <- t296 %>% transmute(mir, logFC, PValue = P.Value, FDR = adj.P.Val)
write.csv(t296, file.path(resdir, "GSE296792_miRNA_diff.csv"), row.names = FALSE)
cat("\nGSE296792 7day vs base miRNA:\n"); print(table(t296$FDR < 0.05))
print(head(t296, 10), row.names = FALSE)

# ---------- family-level parsing ----------
parse_fam <- function(nm) {
  up <- toupper(nm)
  arm <- ifelse(grepl("5P", up), "5P",
         ifelse(grepl("3P", up), "3P", NA))
  if (grepl("LET-7", up)) return(data.frame(fam = "LET7", arm))
  mm <- regmatches(up, regexec("HSA-MIR-([0-9]+)", up))[[1]]
  data.frame(fam = if (length(mm) >= 2) paste0("MIR", mm[2]) else NA, arm)
}
pf <- bind_rows(lapply(t296$mir, parse_fam))
t296 <- cbind(t296, pf)

# ---------- MIRDB target sets ----------
c3 <- msigdbr(species = "Homo sapiens", category = "C3", subcategory = "MIR:MIRDB")
mirdb <- split(c3$gene_symbol, c3$gs_name)
all_gs <- names(mirdb)
match_targets <- function(fam, arm) {
  if (is.na(fam) || is.na(arm)) return(character(0))
  pat <- if (fam == "LET7") paste0("^LET_7.*_", arm, "$")
         else paste0("^", fam, "[A-Z0-9_]*_", arm, "$")
  sets <- grep(pat, all_gs, value = TRUE)
  unique(unlist(mirdb[sets], use.names = FALSE))
}

# ---------- miRNA-mRNA network (opposite direction to bulk DEGs) ----------
cs <- read.csv(file.path(resdir, "cross_section_consensus.csv"))
deg_dir <- setNames(cs$consensus, cs$gene)
# use a relaxed DEG universe: any gene with a direction call (incl. single evidence)
cs2 <- cs; cs2$dir <- ifelse(cs2$n_up >= 1 & cs2$n_down == 0, "up",
                      ifelse(cs2$n_down >= 1 & cs2$n_up == 0, "down", NA))
deg_univ <- setNames(cs2$dir, cs2$gene)

# significant/top miRNAs (relaxed p<0.05 given small effects)
sig_mir <- t296 %>% filter(PValue < 0.05 & !is.na(fam))
net <- bind_rows(lapply(seq_len(nrow(sig_mir)), function(i) {
  r <- sig_mir[i, ]; targets <- match_targets(r$fam, r$arm)
  tdir <- deg_univ[intersect(targets, names(deg_univ))]
  # miRNA up at 7day -> targets should be down; miRNA down -> targets up
  mir_dir <- ifelse(r$logFC > 0, "up", "down")
  wanted <- if (mir_dir == "up") "down" else "up"
  genes <- names(tdir)[!is.na(tdir) & tdir == wanted]
  if (length(genes) == 0) return(NULL)
  data.frame(miRNA = r$mir, family = r$fam, arm = r$arm,
             miRNA_logFC = r$logFC, miRNA_FDR = r$FDR,
             target = genes, target_dir = wanted)
}))
write.csv(net, file.path(resdir, "miRNA_mRNA_network.csv"), row.names = FALSE)
cat("\nmiRNA-mRNA regulatory edges:", nrow(net), "\n")
cat("distinct miRNAs:", length(unique(net$miRNA)),
    "| distinct targets:", length(unique(net$target)), "\n")
if (nrow(net) > 0) print(head(net, 15), row.names = FALSE)
saveRDS(list(t436 = t436, t296 = t296, net = net, mirdb = mirdb),
        file.path(resdir, "miRNA_analysis.rds"))
cat("\nmiRNA analysis done\n")
