# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 诊断 GSE163256 列名匹配
root <- PATHS$project
dr <- file.path(root, "00_data/GSE163256")
m <- as.matrix(read.csv(gzfile(file.path(dr, "GSE163256_monos_counts.csv.gz")),
                        row.names = 1, check.names = FALSE))
cat("counts dim:", dim(m), "\n")
cat("counts cols head:/n"); print(head(colnames(m), 5))
es <- GEOquery::getGEO(filename = file.path(dr, "GSE163256_series_matrix.txt.gz"),
                       getGPL = FALSE)
pd <- Biobase::pData(es)
cat("pData rownames head:/n"); print(head(rownames(pd), 5))
cat("intersect:", length(intersect(colnames(m), rownames(pd))), "\n")
cat("source table:\n"); print(table(pd$source_name_ch1))
