# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 找 pData 中承载内部样本名的字段
root <- PATHS$project
dr <- file.path(root, "00_data/GSE163256")
m <- as.matrix(read.csv(gzfile(file.path(dr, "GSE163256_monos_counts.csv.gz")),
                        row.names = 1, check.names = FALSE))
target <- head(colnames(m), 3)
es <- GEOquery::getGEO(filename = file.path(dr, "GSE163256_series_matrix.txt.gz"),
                       getGPL = FALSE)
pd <- Biobase::pData(es)
cat("all pData columns:\n"); print(colnames(pd))
for (fld in colnames(pd)) {
  vals <- as.character(pd[[fld]])
  hit <- any(sapply(target, function(t) grepl(t, vals, fixed = TRUE)))
  if (hit) {
    cat("\n>>> FIELD", fld, "contains internal names. examples:\n")
    print(head(vals, 4))
  }
}
