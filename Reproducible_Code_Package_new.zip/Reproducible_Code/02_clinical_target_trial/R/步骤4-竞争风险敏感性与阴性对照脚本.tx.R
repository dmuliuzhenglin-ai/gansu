# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 步骤4：VTE竞争风险敏感性 + E-value + 阴性对照暴露【v2】
# 【v2修正】IPCW-HT改在kept子集（依从+分叉前事件克隆）上估计——
#   v1在全部克隆上求和计入删失克隆结局，IPCW列被稀释（AIPW列不受影响）。
#   v1的AIPW结果（复合终点-8.6pp、阴性对照+0.2pp）依然有效，重跑主要为修正IPCW列。
# A. VTE三重分析：①二分类VTE（同2b）②复合终点(死亡或VTE) ③存活者中VTE
#    说明：MIMIC的VTE来自出院ICD编码、无事件时间，无法做真正的Fine-Gray；
#    复合终点是对"死亡作为竞争事件"最干净的敏感性处理。
# B. E-value：主结局RR的未测量混杂稳健性
# C. 阴性对照暴露：早期对乙酰氨基酚(≤48h)→院内死亡，预期效应≈0
# 依赖：data.table, glmnet, ranger
# 输入：[clinical output directory]/01_分析队列.csv + MIMIC-IV原始表
# 输出：[clinical output directory]/04_敏感性结果.txt + 04_敏感性汇总.csv
# ================================================================

rm(list = ls())
suppressMessages({
  library(data.table)
  library(glmnet)
  library(ranger)
})
set.seed(2026)

dir_mimic <- PATHS$mimic
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "04_敏感性结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

dat <- fread(file.path(dir_out, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]

# ----------------------------------------------------------------
# 0. 预处理（同2b-v5：死亡时间 + 协变量矩阵）
# ----------------------------------------------------------------
cat("== 0. 预处理 ==\n")
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"),
               select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"),
               select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs   := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, death90_hrs := as.numeric(as.Date(dod) - as.Date(intime)) * 24]

dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
miss_vars <- paste0(num_vars, "_miss")
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]
cat("队列：", nrow(dat), "条stay；协变量：", ncol(X_mm), "维\n\n")

# ----------------------------------------------------------------
# 通用克隆构建（暴露时间列名可换）+ SL + 分析函数（同2b-v5架构）
# ----------------------------------------------------------------
build_clones <- function(dt, G, evar) {
  ev <- dt[[evar]]
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early")],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed")])
  cl[, px := rep(ev, 2)]
  cl[, t_div := fifelse(!is.na(px) & px <= G, px, G)]
  cl[, adherent := fcase(
    arm == "early"   & !is.na(px) & px <= G, 1L,
    arm == "delayed" & (is.na(px) | px > G), 1L,
    default = 0L)]
  cl
}

fit_sl <- function(x, y) {
  y <- as.integer(y)
  K <- 5
  folds <- sample(rep(1:K, length.out = length(y)))
  cv_err <- c(glmnet = Inf, ranger = Inf)
  pred_oof <- list(glmnet = rep(NA_real_, length(y)),
                   ranger = rep(NA_real_, length(y)))
  for (k in 1:K) {
    tr <- folds != k; te <- folds == k
    fit_g <- tryCatch(cv.glmnet(x[tr, , drop = FALSE], y[tr], family = "binomial",
                                nfolds = 3), error = function(e) NULL)
    if (!is.null(fit_g)) {
      pred_oof$glmnet[te] <- as.numeric(predict(fit_g, x[te, , drop = FALSE],
                                                s = "lambda.min", type = "response"))
    }
    fit_r <- tryCatch(ranger(x = as.data.frame(x[tr, , drop = FALSE]),
                             y = factor(y[tr], levels = c(0, 1)),
                             probability = TRUE, num.trees = 300),
                      error = function(e) NULL)
    if (!is.null(fit_r)) {
      pr <- predict(fit_r, data = as.data.frame(x[te, , drop = FALSE]))$predictions
      pc <- if ("1" %in% colnames(pr)) "1" else colnames(pr)[ncol(pr)]
      pred_oof$ranger[te] <- pr[, pc]
    }
  }
  for (nm in names(cv_err)) {
    p <- pred_oof[[nm]]
    ok <- !is.na(p)
    if (sum(ok) > 0 && length(unique(y[ok])) > 1)
      cv_err[nm] <- mean((y[ok] - p[ok])^2)
  }
  best <- names(which.min(cv_err))
  list(best = best,
       glmnet = cv.glmnet(x, y, family = "binomial", nfolds = 5),
       ranger = ranger(x = as.data.frame(x), y = factor(y, levels = c(0, 1)),
                       probability = TRUE, num.trees = 500))
}
predict_sl <- function(fit, x) {
  if (fit$best == "glmnet") {
    as.numeric(predict(fit$glmnet, x, s = "lambda.min", type = "response"))
  } else {
    pr <- predict(fit$ranger, data = as.data.frame(x))$predictions
    pc <- if ("1" %in% colnames(pr)) "1" else colnames(pr)[ncol(pr)]
    pr[, pc]
  }
}

# 主分析函数：IPCW-HT（自助法CI）+ AIPW；返回单行结果
analyze_one <- function(dt, X, G, yvar, tvar, evar, n_boot = 500, label = "") {
  cat("[stage]", label, "构建克隆 G =", G, "\n")
  cl <- build_clones(dt, G, evar)
  cl[, Y := as.integer(dt[[yvar]][src_row])]
  tv <- dt[[tvar]][cl$src_row]
  cl[, ev_before_div := as.integer(!is.na(tv) & tv <= t_div)]
  Xall <- X[cl$src_row, , drop = FALSE]
  arm_all <- as.integer(cl$arm == "early")
  n_arm <- nrow(dt)
  
  cat("[stage]", label, "依从模型\n")
  p_all <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_all == a)
    fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                       family = "binomial", nfolds = 5)
    p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                     s = "lambda.min", type = "response"))
  }
  p_all <- pmax(p_all, 0.01)
  stab <- ave(cl$adherent, cl$arm, FUN = mean)
  w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
  w_all[cl$ev_before_div == 1] <- 1
  pos <- cl$adherent == 1 & cl$ev_before_div == 0
  qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
  w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])
  
  # ---- IPCW-HT（v2修正：仅在kept子集=依从+分叉前事件克隆上估计；
  #      v1误在全部克隆上求和，删失克隆结局被计入，效应被稀释） ----
  kept <- cl$adherent == 1 | cl$ev_before_div == 1
  ht_est <- function(wv, arm_v, Y_v) {
    r_e <- sum(wv[arm_v == 1] * Y_v[arm_v == 1]) / n_arm
    r_d <- sum(wv[arm_v == 0] * Y_v[arm_v == 0]) / n_arm
    c(r_e, r_d, r_e - r_d, r_e / r_d)
  }
  pt <- ht_est(w_all[kept], arm_all[kept], cl$Y[kept])
  subj <- cl$subject_id
  usubj <- unique(subj)
  idx_list <- split(seq_len(nrow(cl)), subj)
  boot_mat <- matrix(NA_real_, n_boot, 4)
  colnames(boot_mat) <- c("risk_early", "risk_delayed", "RD", "RR")
  for (b in 1:n_boot) {
    bs <- sample(usubj, replace = TRUE)
    bi <- unlist(idx_list[as.character(bs)])
    if (length(unique(cl$adherent[bi])) < 2) next
    p_b <- rep(NA_real_, length(bi))
    ok <- TRUE
    for (a in 0:1) {
      ia <- which(arm_all[bi] == a)
      fit_b <- tryCatch(cv.glmnet(Xall[bi[ia], , drop = FALSE], cl$adherent[bi][ia],
                                  family = "binomial", nfolds = 3),
                        error = function(e) NULL)
      if (is.null(fit_b)) { ok <- FALSE; break }
      p_b[ia] <- as.numeric(predict(fit_b, Xall[bi[ia], , drop = FALSE],
                                    s = "lambda.min", type = "response"))
    }
    if (!ok) next
    p_b <- pmax(p_b, 0.01)
    stab_b <- ave(cl$adherent[bi], arm_all[bi], FUN = mean)
    w_b <- ifelse(cl$adherent[bi] == 1, stab_b / p_b, 1)
    w_b[cl$ev_before_div[bi] == 1] <- 1
    posb <- cl$adherent[bi] == 1 & cl$ev_before_div[bi] == 0
    qsb <- quantile(w_b[posb], c(0.01, 0.99), na.rm = TRUE)
    w_b[posb] <- pmin(pmax(w_b[posb], qsb[1]), qsb[2])
    kept_b <- cl$adherent[bi] == 1 | cl$ev_before_div[bi] == 1
    arm_b <- arm_all[bi][kept_b]
    w_kb <- w_b[kept_b]
    Y_kb <- cl$Y[bi][kept_b]
    boot_mat[b, ] <- c(sum(w_kb[arm_b == 1] * Y_kb[arm_b == 1]) / n_arm,
                       sum(w_kb[arm_b == 0] * Y_kb[arm_b == 0]) / n_arm, NA, NA)
    boot_mat[b, 3] <- boot_mat[b, 1] - boot_mat[b, 2]
    boot_mat[b, 4] <- boot_mat[b, 1] / boot_mat[b, 2]
  }
  ci_rd <- quantile(boot_mat[, 3], c(0.025, 0.975), na.rm = TRUE)
  ci_rr <- quantile(boot_mat[, 4], c(0.025, 0.975), na.rm = TRUE)
  
  # ---- AIPW ----
  cat("[stage]", label, "结局模型(SL交叉拟合)\n")
  M <- 5
  ofolds <- sample(rep(1:M, length.out = nrow(cl)))
  mu1 <- mu0 <- phat <- rep(NA_real_, nrow(cl))
  for (m in 1:M) {
    tr <- ofolds != m; te <- ofolds == m
    for (a in 0:1) {
      tr_a <- tr & arm_all == a & cl$adherent == 1
      if (sum(tr_a) < 50 || length(unique(cl$Y[tr_a])) < 2) next
      fit_o <- fit_sl(Xall[tr_a, , drop = FALSE], cl$Y[tr_a])
      pr <- predict_sl(fit_o, Xall[te, , drop = FALSE])
      if (a == 1) mu1[te] <- pr else mu0[te] <- pr
    }
    for (a in 0:1) {
      tr_a <- tr & arm_all == a
      fit_a <- cv.glmnet(Xall[tr_a, , drop = FALSE], cl$adherent[tr_a],
                         family = "binomial", nfolds = 3)
      pp <- as.numeric(predict(fit_a, Xall[te & arm_all == a, , drop = FALSE],
                               s = "lambda.min", type = "response"))
      phat[te & arm_all == a] <- pp
    }
  }
  phat <- pmax(phat, 0.01)
  in_arm <- arm_all == 1
  aug_w <- ifelse(cl$ev_before_div == 1, 1,
                  ifelse(cl$adherent == 1, 1 / phat, 0))
  aipw1 <- mu1 + in_arm * aug_w * (cl$Y - mu1)
  aipw0 <- mu0 + (!in_arm) * aug_w * (cl$Y - mu0)
  psi <- aipw1 - aipw0
  rd_aipw <- mean(psi)
  # 聚类稳健IF方差
  Dc <- tapply(psi - rd_aipw, subj, sum)
  se_rd <- sqrt(sum(Dc^2)) / length(psi)
  rr_aipw <- mean(aipw1) / mean(aipw0)
  se_logrr <- se_rd / max(abs(rd_aipw), 1e-6) * abs(log(rr_aipw))  # 近似
  ci_rd_a <- c(rd_aipw - 1.96 * se_rd, rd_aipw + 1.96 * se_rd)
  
  data.table(
    label = label, G = G, outcome = yvar, exposure = evar,
    n_stay = n_arm, n_kept = sum(cl$adherent == 1 | cl$ev_before_div == 1),
    ipcw_risk_early = round(pt[1], 4), ipcw_risk_delayed = round(pt[2], 4),
    ipcw_RD = round(pt[3], 4), ipcw_RD_lo = round(ci_rd[1], 4),
    ipcw_RD_hi = round(ci_rd[2], 4),
    ipcw_RR = round(pt[4], 3), ipcw_RR_lo = round(ci_rr[1], 3),
    ipcw_RR_hi = round(ci_rr[2], 3),
    aipw_RD = round(rd_aipw, 4), aipw_RD_lo = round(ci_rd_a[1], 4),
    aipw_RD_hi = round(ci_rd_a[2], 4), aipw_RR = round(rr_aipw, 3)
  )
}

results <- list()

# ----------------------------------------------------------------
# A. VTE 竞争风险敏感性（G=48）
# ----------------------------------------------------------------
cat("\n== A. VTE 竞争风险敏感性 ==\n")

# A1. 二分类VTE（同2b口径，重述）
results[["A1_VTE二分类"]] <- analyze_one(dat, X_mm, 48, "vte", "death_hrs",
                                      "first_px_hrs", 500, "A1-VTE")
print(results[["A1_VTE二分类"]])

# A2. 复合终点：死亡或VTE（死亡竞争风险的最干净处理）
dat[, comp_dv := as.integer(hosp_mort == 1 | vte == 1)]
results[["A2_复合死亡或VTE"]] <- analyze_one(dat, X_mm, 48, "comp_dv", "death_hrs",
                                        "first_px_hrs", 500, "A2-复合")
print(results[["A2_复合死亡或VTE"]])

# A3. 住院存活者中的VTE（注明：选择偏倚，仅作参考）
cat("\n[stage] A3-存活者VTE（IPCW-HT，简单加权对比）\n")
surv_idx <- which(dat$hosp_mort == 0)
dat_s <- dat[surv_idx, ]
X_s <- X_mm[surv_idx, , drop = FALSE]
res_a3 <- analyze_one(dat_s, X_s, 48, "vte", "death_hrs",
                      "first_px_hrs", 500, "A3-存活者VTE")
res_a3[, label := "A3_存活者VTE（有选择偏倚）"]
results[["A3_存活者VTE"]] <- res_a3
print(res_a3)

# ----------------------------------------------------------------
# B. E-value（基于步骤2b的AIPW估计）
# ----------------------------------------------------------------
cat("\n== B. E-value（未测量混杂稳健性） ==\n")
evalue_rr <- function(rr) {
  rr_p <- 1 / rr  # 保护性RR翻转为>1
  rr_p + sqrt(rr_p * (rr_p - 1))
}
# 2b-v5主结果：院内死亡 AIPW RR 0.75 (CI上限0.91)；90天死亡 AIPW RR 0.79 (上限0.93)
# 若你本地2b汇总值略有出入，请用实际值替换下面四行
rr_hosp <- 0.75; rr_hosp_hi <- 0.91
rr_m90  <- 0.79; rr_m90_hi  <- 0.93
cat(sprintf("院内死亡 RR=%.2f：E-value = %.2f（点估计）/ %.2f（CI上限）\n",
            rr_hosp, evalue_rr(rr_hosp), evalue_rr(rr_hosp_hi)))
cat(sprintf("90天死亡 RR=%.2f：E-value = %.2f（点估计）/ %.2f（CI上限）\n",
            rr_m90, evalue_rr(rr_m90), evalue_rr(rr_m90_hi)))
cat("解读：未测量混杂需与暴露和结局均存在≥该值的RR关联，才能完全解释效应。\n")

# ----------------------------------------------------------------
# C. 阴性对照暴露：早期对乙酰氨基酚（预期对死亡无因果效应）
# ----------------------------------------------------------------
cat("\n== C. 阴性对照暴露：早期对乙酰氨基酚 ==\n")
rx <- fread(file.path(dir_mimic, "hosp/prescriptions.csv.gz"),
            select = c("hadm_id", "drug", "starttime"))
rx <- rx[grepl("ACETAMINOPHEN|PARACETAMOL", drug, ignore.case = TRUE)]
rx[, starttime := as.POSIXct(starttime)]
rx <- merge(rx, unique(dat[, .(hadm_id, intime)]), by = "hadm_id")
rx[, acet_hrs := as.numeric(difftime(starttime, intime, units = "hours"))]
first_acet <- rx[acet_hrs >= 0, .(first_acet_hrs = min(acet_hrs)), by = hadm_id]
dat <- merge(dat, first_acet, by = "hadm_id", all.x = TRUE, sort = FALSE)
cat("48h内使用对乙酰氨基酚：", sum(!is.na(dat$first_acet_hrs) & dat$first_acet_hrs <= 48),
    "/", nrow(dat), "\n")
results[["C_阴性对照"]] <- analyze_one(dat, X_mm, 48, "hosp_mort", "death_hrs",
                                   "first_acet_hrs", 500, "C-阴性对照")
print(results[["C_阴性对照"]])
cat("（预期：RD接近0且CI跨0；若显著非零→提示分析流程存在系统性偏倚）\n")

# ----------------------------------------------------------------
# 汇总输出
# ----------------------------------------------------------------
res_all <- rbindlist(results, fill = TRUE)
cat("\n== 汇总 ==\n")
print(res_all)
fwrite(res_all, file.path(dir_out, "04_敏感性汇总.csv"))

cat("\n结果已保存：04_敏感性结果.txt / 04_敏感性汇总.csv\n")
sink()
cat("运行完毕，请查看 [clinical output directory]/04_敏感性结果.txt/n")
