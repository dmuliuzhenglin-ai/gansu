# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R",
                "../../../config_paths.R", "../../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# Align the causal forest with the Hajek-normalised primary estimator:
# normalise sample weights within each treatment arm so that each strategy
# contributes equal total weight, then compare ATE and GCS-stratum CATEs.
suppressMessages({
  library(data.table); library(glmnet); library(grf)
})
set.seed(2026)
dir_mimic <- PATHS$mimic
dir_clin  <- PATHS$clinical

dat <- fread(file.path(dir_clin, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"), select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"), select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, race4 := fcase(grepl("WHITE", race, ignore.case = TRUE), "White",
                     grepl("BLACK", race, ignore.case = TRUE), "Black",
                     grepl("ASIAN", race, ignore.case = TRUE), "Asian", default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4 := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]
num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars,
                                           paste0(num_vars, "_miss")), collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]

G <- 48
cl <- rbind(dat[, .(stay_id, subject_id, src_row = .I, arm = "early", first_px_hrs)],
            dat[, .(stay_id, subject_id, src_row = .I, arm = "delayed", first_px_hrs)])
cl[, t_div := fifelse(!is.na(first_px_hrs) & first_px_hrs <= G, first_px_hrs, G)]
cl[, adherent := fcase(arm == "early" & !is.na(first_px_hrs) & first_px_hrs <= G, 1L,
                       arm == "delayed" & (is.na(first_px_hrs) | first_px_hrs > G), 1L, default = 0L)]
cl[, Y := as.integer(dat[["hosp_mort"]][src_row])]
cl[, t_ev := dat[["death_hrs"]][src_row]]
cl[, ev_before_div := as.integer(!is.na(t_ev) & t_ev <= t_div)]
cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
Xall <- X_mm[cl$src_row, , drop = FALSE]
arm_all <- as.integer(cl$arm == "early")
p_all <- rep(NA_real_, nrow(cl))
for (a in 0:1) {
  idx <- which(arm_all == a)
  fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx], family = "binomial", nfolds = 5)
  p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE], s = "lambda.min", type = "response"))
}
p_all <- pmax(p_all, 0.01)
stab <- ave(cl$adherent, cl$arm, FUN = mean)
w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
w_all[cl$ev_before_div == 1] <- 1
pos <- cl$adherent == 1 & cl$ev_before_div == 0
qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])

kidx <- which(cl$kept == 1)
X <- Xall[kidx, , drop = FALSE]; Y <- cl$Y[kidx]; W <- arm_all[kidx]
w <- w_all[kidx]; clu <- cl$subject_id[kidx]
src <- cl$src_row[kidx]; g <- dat$gcs_total[src]

wn <- w
wn[W == 1] <- wn[W == 1] / mean(wn[W == 1])
wn[W == 0] <- wn[W == 0] / mean(wn[W == 0])

report <- function(label, cf) {
  a <- average_treatment_effect(cf)
  cat(sprintf("\n[%s] ATE=%.4f (se %.4f)\n", label, a[1], a[2]))
  for (nm in c("3-8", "9-12", "13-15")) {
    i <- switch(nm, "3-8" = which(g >= 3 & g <= 8), "9-12" = which(g >= 9 & g <= 12),
                "13-15" = which(g >= 13))
    e <- average_treatment_effect(cf, subset = i)
    cat(sprintf("   GCS %-6s n=%4d cate=%+.4f (%.4f to %.4f)\n", nm, length(i),
                e[1], e[1] - 1.96 * e[2], e[1] + 1.96 * e[2]))
  }
  cat(sprintf("   w mean early=%.2f delayed=%.2f\n", mean(w[W == 1]), mean(w[W == 0])))
}

cf1 <- causal_forest(X, Y, W, sample.weights = w, clusters = clu, num.trees = 2000, seed = 2026)
report("raw_weights", cf1)
cf2 <- causal_forest(X, Y, W, sample.weights = wn, clusters = clu, num.trees = 2000, seed = 2026)
report("arm_normalised", cf2)
cat("\ndone\n")
