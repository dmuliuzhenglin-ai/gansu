# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E0b - eICU 探查补丁脚本
# 修正：① ICH 排除外伤/出血转化  ② 预防定义覆盖 "5,000" 千分位写法 + dosage 列
#       ③ 实验室覆盖重新核实  ④ GCS 走 apachepredvar  ⑤ hospitalid 工具变量可行性
# 用法：source(file.path(PATHS$clinical, "eICU探查补丁.R"), encoding="UTF-8")
# ============================================================

library(data.table)
set.seed(2026)
dir_eicu <- PATHS$eicu
dir_out  <- PATHS$clinical
sink_f   <- file.path(dir_out, "E0b_探查补丁结果.txt")

rd <- function(name, ...) {
  f1 <- file.path(dir_eicu, paste0(name, ".csv.gz"))
  f2 <- file.path(dir_eicu, paste0(name, ".csv"))
  f  <- if (file.exists(f1)) f1 else f2
  if (!file.exists(f)) stop("找不到: ", f)
  fread(f, ...)
}
sc_route <- function(x) grepl("SC|SUB", toupper(x))   # 皮下注射的各路写法

sink(sink_f, split = TRUE)
cat("E0b 补丁探查  ", as.character(Sys.time()), "\n\n")

# ---- 1. 干净的 ICH（自发性） ----
cat("========== 1. 自发性 ICH（排除外伤/出血转化） ==========\n")
dg <- rd("diagnosis")
ich <- dg[
  grepl("(^| |, )431\\b|I61", icd9code, ignore.case = TRUE) |
    (grepl("hemorrhagic stroke", diagnosisstring, ignore.case = TRUE) &
       !grepl("transformation", diagnosisstring, ignore.case = TRUE))
]
ich <- ich[!grepl("trauma|traumatic|subdural|subarachnoid|epidural|injury", diagnosisstring, ignore.case = TRUE)]
ich_stays <- unique(ich$patientunitstayid)
cat("自发性 ICH stays:", length(ich_stays), "\n")
cat("诊断字符串 TOP10:\n")
print(head(sort(table(ich$diagnosisstring), decreasing = TRUE), 10))

pt <- rd("patient", select = c("patientunitstayid","uniquepid","hospitalid","gender","age",
                               "unittype","hospitaldischargestatus","unitdischargestatus",
                               "hospitaldischargeoffset"))
pt_ich <- pt[patientunitstayid %in% ich_stays]
cat("涉及医院数:", uniqueN(pt_ich$hospitalid), "\n")
hm <- pt_ich[tolower(hospitaldischargestatus) == "expired", .N]
cat(sprintf("院内死亡: %d (%.1f%%)\n", hm, 100*hm/nrow(pt_ich)))

# ---- 2. 修正的预防定义 ----
cat("\n========== 2. 修正后的预防性抗凝 ==========\n")
med <- rd("medication")
med_ich <- med[patientunitstayid %in% ich_stays]
med_ich[, t_off := fifelse(!is.na(drugstartoffset), drugstartoffset, drugorderoffset)]

# 肝素预防：药名含 5000 或 5,000（排除冲洗/输注/大剂量），或泛名 heparin 且 dosage 列提示 5000
hep_name <- med_ich[grepl("heparin", drugname, ignore.case = TRUE)]
flush <- grepl("flush|lock|10 unit|1000 unit|25,?000|infusion|drip|d5w|nacl|intralumin", hep_name$drugname, ignore.case = TRUE)
hep_5000 <- hep_name[!flush & (grepl("5,?000", drugname, ignore.case = TRUE) |
                                 grepl("5000", dosage, ignore.case = TRUE))]
cat("肝素5000类医嘱:", nrow(hep_5000), " 涉及 stays:", uniqueN(hep_5000$patientunitstayid), "\n")
cat("  其中皮下途径 stays:", uniqueN(hep_5000[sc_route(routeadmin)]$patientunitstayid), "\n")
cat("  非皮下途径分布(核对用):\n")
print(sort(table(hep_5000[!sc_route(routeadmin)]$routeadmin), decreasing = TRUE))
# 泛名 heparin 的 dosage 取值 TOP（人工核对是否还有遗漏的预防写法）
cat("  泛名 heparin 的 dosage TOP15:\n")
generic <- hep_name[!flush & !grepl("5,?000", drugname, ignore.case = TRUE)]
print(head(sort(table(paste(generic$drugname, "|", generic$dosage)), decreasing = TRUE), 15))

eno <- med_ich[grepl("enoxaparin|lovenox", drugname, ignore.case = TRUE)]
eno_proph <- eno[grepl("30|40", drugname) | grepl("30|40", dosage)]
cat("依诺肝素30/40类医嘱:", nrow(eno_proph), " 涉及 stays:", uniqueN(eno_proph$patientunitstayid), "\n")

proph <- rbind(
  hep_5000[sc_route(routeadmin) | is.na(routeadmin) | routeadmin == "",
           .(patientunitstayid, t_off)],
  eno_proph[, .(patientunitstayid, t_off)]
)
first_px <- proph[!is.na(t_off), .(first_px_hrs = min(t_off)/60), by = patientunitstayid]
cat("任一预防(修正定义)涉及 ICH stays:", uniqueN(proph$patientunitstayid),
    sprintf("(%.1f%%)\n", 100*uniqueN(proph$patientunitstayid)/length(ich_stays)))
for (G in c(24, 48, 72)) {
  n_early <- sum(first_px$first_px_hrs <= G)
  cat(sprintf("  ≤%dh 启动: %d stays (%.1f%%)\n", G, n_early, 100*n_early/length(ich_stays)))
}
cat("首次给药时间(小时)分位数:\n")
print(round(quantile(first_px$first_px_hrs, c(.1,.25,.5,.75,.9), na.rm = TRUE), 1))

# ---- 3. 实验室覆盖重新核实（完整读取，不看 select） ----
cat("\n========== 3. 实验室覆盖重新核实 ==========\n")
lb <- rd("lab")
lb_ich <- lb[patientunitstayid %in% ich_stays]
cat("ICH stays 的检验记录数:", nrow(lb_ich), " 有任一检验的 stays:", uniqueN(lb_ich$patientunitstayid),
    sprintf("(%.1f%%)\n", 100*uniqueN(lb_ich$patientunitstayid)/length(ich_stays)))
cat("labname TOP20:\n")
print(head(sort(table(lb_ich$labname), decreasing = TRUE), 20))
lab_pat <- list(INR = "^INR$|INR\\(PT\\)", PT = "^PT$|prothrombin",
                platelet = "platelet", hemoglobin = "^Hgb|hemoglobin",
                creatinine = "creatinine", glucose = "glucose")
for (nm in names(lab_pat)) {
  n_cov <- uniqueN(lb_ich[grepl(lab_pat[[nm]], labname, ignore.case = TRUE)]$patientunitstayid)
  cat(sprintf("%-11s 覆盖: %5d (%.1f%%)\n", nm, n_cov, 100*n_cov/length(ich_stays)))
}

# ---- 4. GCS / APACHE ----
cat("\n========== 4. GCS(apachepredvar) 与 APACHE ==========\n")
apv <- rd("apachepredvar")
apv_ich <- apv[patientunitstayid %in% ich_stays]
cat("apachepredvar 列名中含 gcs/eye/verbal/motor 的列:\n")
print(grep("gcs|eye|verbal|motor|intubat", names(apv), value = TRUE, ignore.case = TRUE))
gcs_cols <- grep("^eyes$|^verbal$|^motor$", names(apv_ich), value = TRUE, ignore.case = TRUE)
if (length(gcs_cols) == 3) {
  has_gcs <- apv_ich[!is.na(get(gcs_cols[1])) & !is.na(get(gcs_cols[2])) & !is.na(get(gcs_cols[3]))]
  cat("GCS 三分量齐全 stays:", uniqueN(has_gcs$patientunitstayid),
      sprintf("(%.1f%%)\n", 100*uniqueN(has_gcs$patientunitstayid)/length(ich_stays)))
  gcs_sum <- has_gcs[, .(gcs = get(gcs_cols[1]) + get(gcs_cols[2]) + get(gcs_cols[3])),
                     by = patientunitstayid]
  cat("GCS 分布: ≤8:", sum(gcs_sum$gcs <= 8), " 9-12:", sum(gcs_sum$gcs %in% 9:12),
      " 13-15:", sum(gcs_sum$gcs >= 13), "\n")
  if ("intubated" %in% names(apv_ich))
    cat("intubated=1 比例:", sprintf("%.1f%%", 100*mean(apv_ich$intubated == 1, na.rm = TRUE)), "\n")
}

# ---- 5. 医院偏好工具变量可行性 ----
cat("\n========== 5. 医院层面预防率变异(IV 可行性) ==========\n")
if (exists("first_px")) {
  hosp <- pt_ich[, .(hospitalid, patientunitstayid)]
  hosp <- merge(hosp, first_px[, .(patientunitstayid, early48 = as.integer(first_px_hrs <= 48))],
                by = "patientunitstayid", all.x = TRUE)
  hosp[is.na(early48), early48 := 0L]
  hh <- hosp[, .(n = .N, early_n = sum(early48), rate = round(mean(early48), 3)), by = hospitalid][n >= 20]
  setorder(hh, -n)
  cat("收治 ≥20 例 ICH 的医院数:", nrow(hh), "\n")
  print(hh)
  cat("医院间预防率范围:", min(hh$rate), "-", max(hh$rate),
      "  IQR:", paste(round(quantile(hh$rate, c(.25,.75)), 3), collapse = "-"), "\n")
}

# ---- 6. 小结 ----
cat("\n========== 6. 补丁后小结 ==========\n")
n_early48 <- if (exists("first_px")) sum(first_px$first_px_hrs <= 48) else NA
cat("自发性 ICH stays:", length(ich_stays), "  ≤48h 预防:", n_early48, "\n")
cat("判定:", ifelse(!is.na(n_early48) && n_early48 >= 200,
                  "暴露量达标，可进入正式队列构建（E1）", "暴露量仍偏少，需人工核对上面 dosage TOP 表"), "\n")
sink()
cat("\n完成 ->", sink_f, "\n")
