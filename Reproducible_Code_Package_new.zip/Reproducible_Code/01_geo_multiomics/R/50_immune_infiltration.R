# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 50_immune_infiltration.R
# ssGSEA immune cell abundance (MSigDB C8 markers, merged per cell type)
# GSE335924 PBMC: ICH vs HC; GSE296792 whole blood: longitudinal 7day vs base.
suppressPackageStartupMessages({
  library(msigdbr); library(GSVA); library(limma); library(edgeR); library(dplyr)
})
Sys.setenv(http_proxy = "http://127.0.0.1:7897",
           https_proxy = "http://127.0.0.1:7897")
root <- PATHS$project
resdir <- file.path(root, "02_results")

# ---- build merged marker sets per cell type ----
c8 <- msigdbr(species = "Homo sapiens", category = "C8")
kw <- list(
  B_cells        = "B_CELL",
  CD4_T_cells    = "CD4",
  CD8_T_cells    = "CD8",
  NK_cells       = "NK_CELL|NKT|NATURAL_KILLER",
  monocytes      = "MONOCYTE",
  macrophages    = "MACROPHAGE",
  neutrophils    = "NEUTROPHIL",
  dendritic      = "DENDRITIC",
  mast_cells     = "MAST_CELL")
markers <- lapply(kw, function(pt)
  sort(unique(c8$gene_symbol[grepl(pt, c8$gs_name)])))
cat("marker counts per cell type:\n"); print(lengths(markers))

run_ssgsea <- function(expr) {
  p <- ssgseaParam(exprData = expr, geneSets = markers, normalize = TRUE,
                   alpha = 0.25)
  gsva(p, verbose = FALSE)
}

# ---- GSE335924: cross-sectional ICH vs HC ----
r335 <- readRDS(file.path(resdir, "GSE335924_edgeR.rds"))
expr335 <- cpm(r335$dge, log = TRUE)
ss335 <- run_ssgsea(expr335)
grp335 <- factor(r335$dge$samples$group)
design335 <- model.matrix(~grp335)
fit335 <- eBayes(lmFit(ss335, design335))
tt335 <- topTable(fit335, coef = "grp335ICH", number = Inf)
tt335$cell <- rownames(tt335)
tt335 <- tt335 %>% transmute(cell, logFC, t, PValue = P.Value,
                              FDR = adj.P.Val) %>% arrange(PValue)
write.csv(ss335, file.path(resdir, "GSE335924_ssGSEA_scores.csv"))
write.csv(tt335, file.path(resdir, "GSE335924_immune_diff.csv"),
          row.names = FALSE)
cat("\nGSE335924 ICH vs HC immune differences:\n")
print(tt335, row.names = FALSE, digits = 3)

# ---- GSE296792: longitudinal, paired 7day vs base ----
raw <- read.csv(gzfile(file.path(root,
  "00_data/GSE296792/GSE296792_Normalized_mRNA_counts_v1.csv.gz")),
  check.names = FALSE, row.names = 1)
logx <- log2(as.matrix(raw) + 1)
ss296 <- run_ssgsea(logx)
sids <- colnames(ss296)
pat <- sub("_(base|bas|72h|7day|7da)$", "", sids)
tp <- gsub("bas$", "base", gsub("7da$", "7day", sub("^.*_", "", sids)))
# restrict to base and 7day for paired contrast
keep <- tp %in% c("base", "7day")
ssub <- ss296[, keep]; sp <- pat[keep]
st <- factor(tp[keep], levels = c("base", "7day"), labels = c("base", "day7"))
design <- model.matrix(~st + factor(sp))
coef_name <- "stday7"
cat("design columns:", paste(colnames(design), collapse = ", "), "\n")
fit <- eBayes(lmFit(ssub, design))
tt296 <- topTable(fit, coef = coef_name, number = Inf)
tt296$cell <- rownames(tt296)
tt296 <- tt296 %>% transmute(cell, logFC, t, PValue = P.Value,
                              FDR = adj.P.Val) %>% arrange(PValue)
write.csv(ss296, file.path(resdir, "GSE296792_ssGSEA_scores.csv"))
write.csv(tt296, file.path(resdir, "GSE296792_immune_diff.csv"),
          row.names = FALSE)
cat("\nGSE296792 7day vs base immune differences:\n")
print(tt296, row.names = FALSE, digits = 3)
cat("\nimmune infiltration done\n")
