# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}

  # NWICU 步骤2：TTE外部验证分析（对应MIMIC步骤2b-v5架构）
  # 前置修正：①暴露重建时排除emar"Not Given"记录
  #          ②mort90 = hosp_mort ∪ 90d内dod；death90_hrs缺失继承death_hrs
  # 主分析：G=48h，结局=院内死亡；敏感性：G=24/72h + 90天死亡 + VTE
  # 估计：IPCW-HT（自助CI）+ AIPW（交叉拟合SL，聚类稳健SE）
  # 输入：[clinical output directory]/N1_分析队列.csv + NWICU原始表
  # 输出：N2_TTE验证结果.txt + N2_结果汇总.csv + N2_加权后SMD.csv
  # ================================================================

rm(list = ls())
suppressMessages({
  library(data.table)
  library(glmnet)
  library(ranger)
})
set.seed(2026)

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "N2_TTE验证结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

rd <- function(rel, ...) fread(file.path(dir_nwicu, rel), ...)
dat <- fread(file.path(dir_out, "N1_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]

# ----------------------------------------------------------------
# 前置修正1：暴露重建（排除"Not Given"）
# ----------------------------------------------------------------
cat("== 前置修正1：暴露重建 ==\n")
emar <- rd("data/nw_hosp/emar.csv.gz")
emar[, charttime := as.POSIXct(charttime)]
hep_all <- emar[grepl("HEPARIN|ENOXAPARIN", medication, ignore.case = TRUE)]
proph <- hep_all[
  (grepl("HEPARIN.*5000", medication, ignore.case = TRUE) &
     !grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("30 MG|40 MG", medication, ignore.case = TRUE))
]
proph <- proph[event_txt != "Not Given" | is.na(event_txt)]
px <- merge(proph[, .(hadm_id, charttime)],
            dat[, .(stay_id, hadm_id, intime)], by = "hadm_id")
px[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
first_px <- px[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
dat[, first_px_hrs := NULL]
dat <- merge(dat, first_px, by = "stay_id", all.x = TRUE, sort = FALSE)
cat("排除Not Given后：有预防抗凝", sum(!is.na(dat$first_px_hrs)), "；48h内",
    sum(dat$first_px_hrs <= 48, na.rm = TRUE), "\n")

# 前置修正2：90天死亡口径
dat[mort90 == 0 & hosp_mort == 1, mort90 := 1L]
dat[!is.na(death_hrs) & (is.na(death90_hrs) | death90_hrs > 90 * 24) &
      death_hrs <= 90 * 24, death90_hrs := death_hrs]
dat[, mort90 := as.integer(!is.na(death90_hrs) & death90_hrs <= 90 * 24)]
cat("修正后90天死亡：", sum(dat$mort90), sprintf("(%.1f%%)\n\n", 100*mean(dat$mort90)))

# ----------------------------------------------------------------
# 协变量矩阵（无GCS/INR；缺失指示变量+中位数插补）
# ----------------------------------------------------------------
dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]
num_vars <- c("anchor_age", "sbp", "hr", "platelet", "creatinine",
              "glucose", "hemoglobin")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")
for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
miss_vars <- paste0(num_vars, "_miss")
for (v in bin_vars) {
  dat[is.na(get(v)), (v) := FALSE]
  dat[, (v) := as.integer(get(v))]
}
x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]
cat("协变量矩阵：", nrow(X_mm), "×", ncol(X_mm), "\n\n")

# ----------------------------------------------------------------
# 克隆构建 + SL + 分析函数（与步骤4同架构）
# ----------------------------------------------------------------
build_clones <- function(dt, G, evar) {
  ev <- dt[[evar]]
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early")],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed")])
  cl[, px := rep(ev, 2)]
  cl[, t_div := fifelse(!is.na(px) & px <= G, px, G)]
  cl[, adherent := fcase(
    arm == "early"   & !is.na(px) & px <= G, 1L,
    arm == "delayed" & (is.na(px) | px > G), 1L,
    default = 0L)]
  cl
}
fit_sl <- function(x, y) {
  y <- as.integer(y)
  K <- 5
  folds <- sample(rep(1:K, length.out = length(y)))
  cv_err <- c(glmnet = Inf, ranger = Inf)
  pred_oof <- list(glmnet = rep(NA_real_, length(y)),
                   ranger = rep(NA_real_, length(y)))
  for (k in 1:K) {
    tr <- folds != k; te <- folds == k
    fit_g <- tryCatch(cv.glmnet(x[tr, , drop = FALSE], y[tr], family = "binomial",
                                nfolds = 3), error = function(e) NULL)
    if (!is.null(fit_g))
      pred_oof$glmnet[te] <- as.numeric(predict(fit_g, x[te, , drop = FALSE],
                                                s = "lambda.min", type = "response"))
    fit_r <- tryCatch(ranger(x = as.data.frame(x[tr, , drop = FALSE]),
                             y = factor(y[tr], levels = c(0, 1)),
                             probability = TRUE, num.trees = 300),
                      error = function(e) NULL)
    if (!is.null(fit_r)) {
      pr <- predict(fit_r, data = as.data.frame(x[te, , drop = FALSE]))$predictions
      pc <- if ("1" %in% colnames(pr)) "1" else colnames(pr)[ncol(pr)]
      pred_oof$ranger[te] <- pr[, pc]
    }
  }
  for (nm in names(cv_err)) {
    p <- pred_oof[[nm]]
    ok <- !is.na(p)
    if (sum(ok) > 0 && length(unique(y[ok])) > 1)
      cv_err[nm] <- mean((y[ok] - p[ok])^2)
  }
  best <- names(which.min(cv_err))
  list(best = best,
       glmnet = cv.glmnet(x, y, family = "binomial", nfolds = 5),
       ranger = ranger(x = as.data.frame(x), y = factor(y, levels = c(0, 1)),
                       probability = TRUE, num.trees = 500))
}
predict_sl <- function(fit, x) {
  if (fit$best == "glmnet") {
    as.numeric(predict(fit$glmnet, x, s = "lambda.min", type = "response"))
  } else {
    pr <- predict(fit$ranger, data = as.data.frame(x))$predictions
    pc <- if ("1" %in% colnames(pr)) "1" else colnames(pr)[ncol(pr)]
    pr[, pc]
  }
}
analyze_one <- function(dt, X, G, yvar, tvar, evar, n_boot = 500, label = "") {
  cat("[stage]", label, "构建克隆 G =", G, "\n")
  cl <- build_clones(dt, G, evar)
  cl[, Y := as.integer(dt[[yvar]][src_row])]
  tv <- dt[[tvar]][cl$src_row]
  cl[, ev_before_div := as.integer(!is.na(tv) & tv <= t_div)]
  Xall <- X[cl$src_row, , drop = FALSE]
  arm_all <- as.integer(cl$arm == "early")
  n_arm <- nrow(dt)
  cat("[stage]", label, "依从模型\n")
  p_all <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_all == a)
    fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                       family = "binomial", nfolds = 5)
    p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                     s = "lambda.min", type = "response"))
  }
  p_all <- pmax(p_all, 0.01)
  stab <- ave(cl$adherent, cl$arm, FUN = mean)
  w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
  w_all[cl$ev_before_div == 1] <- 1
  pos <- cl$adherent == 1 & cl$ev_before_div == 0
  qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
  w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])
  ht_est <- function(wv, arm_v, Y_v) {
    r_e <- sum(wv[arm_v == 1] * Y_v[arm_v == 1]) / n_arm
    r_d <- sum(wv[arm_v == 0] * Y_v[arm_v == 0]) / n_arm
    c(r_e, r_d, r_e - r_d, r_e / r_d)
  }
  pt <- ht_est(w_all, arm_all, cl$Y)
  subj <- cl$subject_id
  usubj <- unique(subj)
  idx_list <- split(seq_len(nrow(cl)), subj)
  boot_mat <- matrix(NA_real_, n_boot, 4)
  colnames(boot_mat) <- c("risk_early", "risk_delayed", "RD", "RR")
  for (b in 1:n_boot) {
    bs <- sample(usubj, replace = TRUE)
    bi <- unlist(idx_list[as.character(bs)])
    if (length(unique(cl$adherent[bi])) < 2) next
    p_b <- rep(NA_real_, length(bi))
    ok <- TRUE
    for (a in 0:1) {
      ia <- which(arm_all[bi] == a)
      if (length(unique(cl$adherent[bi][ia])) < 2) { ok <- FALSE; break }
      fit_b <- tryCatch(cv.glmnet(Xall[bi[ia], , drop = FALSE], cl$adherent[bi][ia],
                                  family = "binomial", nfolds = 3),
                        error = function(e) NULL)
      if (is.null(fit_b)) { ok <- FALSE; break }
      p_b[ia] <- as.numeric(predict(fit_b, Xall[bi[ia], , drop = FALSE],
                                    s = "lambda.min", type = "response"))
    }
    if (!ok) next
    p_b <- pmax(p_b, 0.01)
    stab_b <- ave(cl$adherent[bi], arm_all[bi], FUN = mean)
    w_b <- ifelse(cl$adherent[bi] == 1, stab_b / p_b, 1)
    w_b[cl$ev_before_div[bi] == 1] <- 1
    posb <- cl$adherent[bi] == 1 & cl$ev_before_div[bi] == 0
    qsb <- quantile(w_b[posb], c(0.01, 0.99), na.rm = TRUE)
    w_b[posb] <- pmin(pmax(w_b[posb], qsb[1]), qsb[2])
    boot_mat[b, ] <- ht_est(w_b, arm_all[bi], cl$Y[bi])
  }
  ci_rd <- quantile(boot_mat[, 3], c(0.025, 0.975), na.rm = TRUE)
  ci_rr <- quantile(boot_mat[, 4], c(0.025, 0.975), na.rm = TRUE)
  cat("[stage]", label, "结局模型(SL交叉拟合)\n")
  M <- 5
  ofolds <- sample(rep(1:M, length.out = nrow(cl)))
  mu1 <- mu0 <- phat <- rep(NA_real_, nrow(cl))
  for (m in 1:M) {
    tr <- ofolds != m; te <- ofolds == m
    for (a in 0:1) {
      tr_a <- tr & arm_all == a & cl$adherent == 1
      if (sum(tr_a) < 50 || length(unique(cl$Y[tr_a])) < 2) next
      fit_o <- fit_sl(Xall[tr_a, , drop = FALSE], cl$Y[tr_a])
      pr <- predict_sl(fit_o, Xall[te, , drop = FALSE])
      if (a == 1) mu1[te] <- pr else mu0[te] <- pr
    }
    for (a in 0:1) {
      tr_a <- tr & arm_all == a
      fit_a <- cv.glmnet(Xall[tr_a, , drop = FALSE], cl$adherent[tr_a],
                         family = "binomial", nfolds = 3)
      pp <- as.numeric(predict(fit_a, Xall[te & arm_all == a, , drop = FALSE],
                               s = "lambda.min", type = "response"))
      phat[te & arm_all == a] <- pp
    }
  }
  phat <- pmax(phat, 0.01)
  in_arm <- arm_all == 1
  aug_w <- ifelse(cl$ev_before_div == 1, 1,
                  ifelse(cl$adherent == 1, 1 / phat, 0))
  aipw1 <- mu1 + in_arm * aug_w * (cl$Y - mu1)
  aipw0 <- mu0 + (!in_arm) * aug_w * (cl$Y - mu0)
  psi <- aipw1 - aipw0
  rd_aipw <- mean(psi)
  Dc <- tapply(psi - rd_aipw, subj, sum)
  se_rd <- sqrt(sum(Dc^2)) / length(psi)
  rr_aipw <- mean(aipw1) / mean(aipw0)
  ci_rd_a <- c(rd_aipw - 1.96 * se_rd, rd_aipw + 1.96 * se_rd)
  # 主规格加权SMD（仅G=48主分析时输出）
  smd_tab <- NULL
  if (label == "主分析-院内死亡") {
    kept <- cl$adherent == 1 | cl$ev_before_div == 1
    wk <- w_all[kept]; ak <- arm_all[kept]
    Xk <- Xall[kept, , drop = FALSE]
    smd <- sapply(seq_len(ncol(Xk)), function(j) {
      x <- Xk[, j]
      m1 <- sum(wk[ak == 1] * x[ak == 1]) / sum(wk[ak == 1])
      m0 <- sum(wk[ak == 0] * x[ak == 0]) / sum(wk[ak == 0])
      v1 <- sum(wk[ak == 1] * (x[ak == 1] - m1)^2) / sum(wk[ak == 1])
      v0 <- sum(wk[ak == 0] * (x[ak == 0] - m0)^2) / sum(wk[ak == 0])
      (m1 - m0) / sqrt((v1 + v0) / 2)
    })
    smd_tab <- data.table(variable = colnames(Xk), SMD = round(smd, 3))
    smd_tab <- smd_tab[order(-abs(SMD))]
  }
  list(res = data.table(
    label = label, G = G, outcome = yvar,
    n_stay = n_arm, n_kept = sum(cl$adherent == 1 | cl$ev_before_div == 1),
    ipcw_risk_early = round(pt[1], 4), ipcw_risk_delayed = round(pt[2], 4),
    ipcw_RD = round(pt[3], 4), ipcw_RD_lo = round(ci_rd[1], 4),
    ipcw_RD_hi = round(ci_rd[2], 4),
    ipcw_RR = round(pt[4], 3), ipcw_RR_lo = round(ci_rr[1], 3),
    ipcw_RR_hi = round(ci_rr[2], 3),
    aipw_RD = round(rd_aipw, 4), aipw_RD_lo = round(ci_rd_a[1], 4),
    aipw_RD_hi = round(ci_rd_a[2], 4), aipw_RR = round(rr_aipw, 3)),
    smd = smd_tab)
}

# ----------------------------------------------------------------
# 分析：主分析 + 敏感性
# ----------------------------------------------------------------
specs <- list(
  list(G = 48, y = "hosp_mort", t = "death_hrs",   lab = "主分析-院内死亡"),
  list(G = 48, y = "mort90",    t = "death90_hrs", lab = "主分析-90天死亡"),
  list(G = 24, y = "hosp_mort", t = "death_hrs",   lab = "敏感性-G24"),
  list(G = 72, y = "hosp_mort", t = "death_hrs",   lab = "敏感性-G72"),
  list(G = 48, y = "vte",       t = "death_hrs",   lab = "敏感性-VTE")
)
res_list <- list()
smd_main <- NULL
for (sp in specs) {
  cat("\n======== ", sp$lab, " ========\n")
  out <- analyze_one(dat, X_mm, sp$G, sp$y, sp$t, "first_px_hrs", 500, sp$lab)
  print(out$res)
  res_list[[sp$lab]] <- out$res
  if (!is.null(out$smd)) smd_main <- out$smd
}
res_all <- rbindlist(res_list)
cat("\n== 汇总 ==\n")
print(res_all)
fwrite(res_all, file.path(dir_out, "N2_结果汇总.csv"))
if (!is.null(smd_main)) {
  cat("\n主分析加权后SMD Top10：\n"); print(head(smd_main, 10))
  fwrite(smd_main, file.path(dir_out, "N2_加权后SMD.csv"))
}
cat("\n结果已保存：N2_TTE验证结果.txt / N2_结果汇总.csv\n")
# 打印累积警告供排查
w <- warnings()
if (!is.null(w)) { cat("\n== 警告汇总（前10条） ==\n"); print(head(w, 10)) }
sink()
cat("运行完毕，请上传 N2_TTE验证结果.txt 和 N2_结果汇总.csv\n")
