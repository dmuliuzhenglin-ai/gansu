# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
## 101_build_bridge.R
## 目的：把 MIMIC-IV 常规血检/肝功对齐到 ICH 队列的 ICU 入科时间，生成
##       淋巴细胞绝对值、NLR、单核百分比的分窗（0-24/24-48/48-72/72-96h）数据集，
##       并计算基线 ALBI。输出长表供混合效应模型使用。

suppressPackageStartupMessages({
  library(data.table)
})

in_cohort <- file.path(PATHS$clinical_src, "01_分析队列.csv")
in_labs   <- file.path(PATHS$project, "05_bridge_immune/00_data/labs_subset.csv.gz")
out_dir   <- file.path(PATHS$project, "05_bridge_immune/01_data")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

co <- fread(in_cohort, encoding = "UTF-8")
co[, intime := as.POSIXct(intime, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")]
co[, early := as.integer(exposure_48h == "早期(<=48h)")]
co[, first_px_hrs := as.numeric(first_px_hrs)]
cat("cohort rows:", nrow(co), " early:", sum(co$early), "\n")

lab <- fread(in_labs, encoding = "UTF-8")
lab[, charttime := as.POSIXct(charttime, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")]
lab[, hadm_id := as.numeric(hadm_id)]

## 只保留入科前 6h 到入科后 168h 的记录
key <- co[, .(stay_id, hadm_id, intime, icu_hours, early, first_px_hrs)]
lab <- merge(lab, key, by = "hadm_id", allow.cartesian = TRUE)
lab[, rel_h := as.numeric(difftime(charttime, intime, units = "hours"))]
lab <- lab[rel_h >= -6 & rel_h <= 168]

## 合理值域过滤（避免录入错误污染均值）
lab <- lab[
  (itemid == 51133 & valuenum > 0.05 & valuenum < 20) |
  (itemid == 52075 & valuenum > 0.5  & valuenum < 60) |
  (itemid == 52074 & valuenum >= 0    & valuenum < 10) |
  (itemid == 51301 & valuenum > 0.5  & valuenum < 80) |
  (itemid == 51244 & valuenum >= 0   & valuenum <= 100) |
  (itemid == 51254 & valuenum >= 0   & valuenum <= 60) |
  (itemid == 51256 & valuenum >= 0   & valuenum <= 100) |
  (itemid == 50862 & valuenum > 1    & valuenum < 6) |
  (itemid == 50885 & valuenum > 0.1  & valuenum < 50)
]

## 分窗：baseline 为 [-6,24) 且取最接近 0h 的一次；其余窗口取均值
lab[, win := fcase(
  rel_h >= -6  & rel_h < 24, "W0",
  rel_h >= 24  & rel_h < 48, "W24",
  rel_h >= 48  & rel_h < 72, "W48",
  rel_h >= 72  & rel_h < 96, "W72",
  default = NA_character_
)]
lab <- lab[!is.na(win)]

lab[, item := fcase(
  itemid == 51133, "alc",
  itemid == 52075, "anc",
  itemid == 52074, "amc",
  itemid == 51301, "wbc",
  itemid == 51244, "lym_pct",
  itemid == 51256, "neut_pct",
  itemid == 51254, "mono_pct",
  itemid == 50862, "alb",
  itemid == 50885, "bili",
  default = NA_character_
)]
lab <- lab[!is.na(item)]

## 每个 stay × 窗口 × 指标：W0 取最接近 0h，其余取均值
lab[, dist0 := abs(rel_h - 0)]
base <- lab[win == "W0", .SD[which.min(dist0)], by = .(stay_id, item), .SDcols = c("valuenum")]
base[, win := "W0"]
base[, valuenum := valuenum]
post <- lab[win != "W0", .(valuenum = mean(valuenum, na.rm = TRUE), n_meas = .N), by = .(stay_id, win, item)]
wide_l <- rbind(base[, .(stay_id, win, item, valuenum, n_meas = 1L)], post)

## 转宽表：每个窗口一行
w <- dcast(wide_l, stay_id + win ~ item, value.var = "valuenum")

## 直接测值缺失时，用同一窗口的白细胞总数 × 百分比推导
w[, alc_d  := fifelse(!is.na(wbc) & !is.na(lym_pct), wbc * lym_pct / 100, NA_real_)]
w[, anc_d  := fifelse(!is.na(wbc) & !is.na(neut_pct), wbc * neut_pct / 100, NA_real_)]
w[, amc_d  := fifelse(!is.na(wbc) & !is.na(mono_pct), wbc * mono_pct / 100, NA_real_)]
w[, alc  := fcoalesce(alc, alc_d)]
w[, anc  := fcoalesce(anc, anc_d)]
w[, amc  := fcoalesce(amc, amc_d)]
w[, nlr := fifelse(!is.na(anc) & !is.na(alc) & alc > 0, anc / alc, NA_real_)]
w[, nlr := pmin(nlr, 100)]

## 输出长表（三个主指标）
long <- melt(
  w[, .(stay_id, win, alc, nlr, mono_pct, lym_pct, wbc, anc)],
  id.vars = c("stay_id", "win"),
  variable.name = "metric", value.name = "value"
)
long <- long[!is.na(value)]
long <- merge(long, co[, .(stay_id, early, first_px_hrs, icu_hours, hosp_mort, mort90,
                           anchor_age, gender, gcs_total, ckd, liver_dz, malignancy,
                           mech_vent, neurosx, platelet, creatinine, hemoglobin)],
              by = "stay_id")
long[, win_f := factor(win, levels = c("W0", "W24", "W48", "W72"))]
fwrite(long, file.path(out_dir, "bridge_long.csv"))

## 基线 ALBI（白蛋白 g/dL -> g/L）
b <- w[win == "W0"]
b <- merge(b, co[, .(stay_id, early, first_px_hrs, icu_hours, hosp_mort, mort90,
                     anchor_age, gender, gcs_total, ckd, liver_dz, malignancy,
                     mech_vent, neurosx, platelet, creatinine)],
           by = "stay_id", all.x = TRUE)
b[, albi := 0.66 * log10(bili) - 0.085 * (alb * 10)]
b[, albi_grade := fcase(
  is.na(albi), NA_integer_,
  albi <= -2.60, 1L,
  albi <= -1.39, 2L,
  default = 3L
)]
fwrite(b, file.path(out_dir, "bridge_baseline.csv"))

## 可用率
av <- w[, .(n_stay = .N, n_alc = sum(!is.na(alc)), n_nlr = sum(!is.na(nlr)),
            n_mono = sum(!is.na(mono_pct)), n_wbc = sum(!is.na(wbc)),
            n_alc_direct = sum(!is.na(alc_d))), by = win]
print(av)
cat("baseline ALBI available:", sum(!is.na(b$albi)), "of", nrow(co), "\n")
cat("long rows:", nrow(long), "\n")
fwrite(av, file.path(out_dir, "availability.csv"))
