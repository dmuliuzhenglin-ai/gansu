# --- shared path configuration; edit config_paths.py for your local machine ---
import os as _os, sys as _sys
for _cf in ("config_paths.py", "../../config_paths.py", "../config_paths.py", "../../../config_paths.py"):
    if _os.path.exists(_cf):
        _d = _os.path.dirname(_os.path.abspath(_cf))
        if _d not in _sys.path:
            _sys.path.insert(0, _d)
        import config_paths as _cp
        PATHS = _cp.PATHS
        break
# -*- coding: utf-8 -*-
"""Extract CBC-differential / albumin / bilirubin from eICU lab table."""
import os
import pandas as pd

LAB = ros.path.join(PATHS["eicu"], "lab.csv.gz")
OUTDIR = ros.path.join(PATHS["project"], "05_bridge_immune/00_data")
os.makedirs(OUTDIR, exist_ok=True)
OUT = os.path.join(OUTDIR, "eicu_labs_subset.csv.gz")

COLS = ["patientunitstayid", "labresultoffset", "labname", "labresult", "labmeasurenamesystem"]
PAT = "lymph|monos|polys|neutroph|wbc|albumin|bilirubin"

chunks, names = [], []
reader = pd.read_csv(LAB, usecols=COLS, chunksize=3_000_000, compression="gzip",
                     on_bad_lines="skip", low_memory=False)
for ch in reader:
    names.append(ch["labname"].value_counts())
    sub = ch[ch["labname"].str.lower().str.contains(PAT, na=False)]
    if len(sub):
        chunks.append(sub)

lab = pd.concat(chunks, ignore_index=True)
lab.to_csv(OUT, index=False, compression="gzip")

allnames = pd.concat(names).groupby(level=0).sum().sort_values(ascending=False)
print(allnames.head(40).to_string())
print("KEPT:", len(lab))
print(lab.groupby("labname").size().to_string())
print("SAVED:", OUT)
