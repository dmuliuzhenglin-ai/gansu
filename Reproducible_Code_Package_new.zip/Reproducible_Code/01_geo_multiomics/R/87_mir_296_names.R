# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 查看 GSE296792 miRNA 命名规律 + multiMiR 可用性
mi <- read.csv(gzfile(file.path(PATHS$project, "00_data/GSE296792/GSE296792_Normalized_miRNA_counts_v1.csv.gz")),
               check.names = FALSE, row.names = 1)
nm <- rownames(mi)
cat("total miRNAs:", length(nm), "\n")
cat("sample of names across the list:\n")
print(nm[round(seq(1, length(nm), length.out = 25))])
cat("\nmultiMiR:", requireNamespace("multiMiR", quietly = TRUE), "\n")
