# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R",
                "../../../config_paths.R", "../../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 158_fig1_rerun.R
# Regenerate Figure 1 from the deterministic pipeline outputs:
#   MIMIC 02b -> _02b_det/run1; NWICU -> _nwicu_det/run1; eICU unchanged.
source("../../01_geo_multiomics/R/80_fig_theme.R")
clin <- PATHS$clinical
root <- PATHS$project

m <- read.csv(file.path(root, "02_results/_02b_det/run1/02b_结果汇总.csv"),
              check.names = FALSE)
m <- m[m$grace_h == 48 & m$outcome == "hosp_mort" & m$method == "IPCW", ]
e <- read.csv(file.path(clin, "E2_结果汇总.csv"), check.names = FALSE)
e <- e[e$spec == "G48 院内死亡" & e$est == "IPCW-HT", ]
n <- read.csv(file.path(root, "02_results/_nwicu_det/run1/N2_结果汇总.csv"),
              check.names = FALSE)
n <- n[n$label == "主分析-院内死亡", ]

three <- data.frame(
  cohort = factor(c("MIMIC-IV", "eICU", "NWICU"),
                  levels = c("NWICU", "MIMIC-IV", "eICU")),
  RD = c(m$RD, e$rd_pp / 100, n$ipcw_RD),
  RD_lo = c(m$RD_lo, e$rd_lo / 100, n$ipcw_RD_lo),
  RD_hi = c(m$RD_hi, e$rd_hi / 100, n$ipcw_RD_hi),
  RR = c(m$RR, e$rr, n$ipcw_RR),
  RR_lo = c(m$RR_lo, e$rr_lo, n$ipcw_RR_lo),
  RR_hi = c(m$RR_hi, e$rr_hi, n$ipcw_RR_hi))

pA <- ggplot(three, aes(RD * 100, cohort, colour = cohort)) +
  geom_vline(xintercept = 0, linetype = 2, linewidth = .3, colour = "grey40") +
  geom_linerange(aes(xmin = RD_lo * 100, xmax = RD_hi * 100), linewidth = .5) +
  geom_point(size = 2.2) +
  scale_colour_manual(values = c("MIMIC-IV" = "#2C3E50", "eICU" = "#E67E22",
                                 "NWICU" = "#16A085")) +
  labs(x = "Risk difference (percentage points)", y = NULL,
       title = "48-h in-hospital mortality, IPCW") +
  fig_theme + theme(legend.position = "none")

pB <- ggplot(three, aes(RR, cohort, colour = cohort)) +
  geom_vline(xintercept = 1, linetype = 2, linewidth = .3, colour = "grey40") +
  geom_linerange(aes(xmin = RR_lo, xmax = RR_hi), linewidth = .5) +
  geom_point(size = 2.2) +
  scale_colour_manual(values = c("MIMIC-IV" = "#2C3E50", "eICU" = "#E67E22",
                                 "NWICU" = "#16A085")) +
  scale_x_log10() +
  labs(x = "Risk ratio (log scale)", y = NULL, title = "Risk ratio") +
  fig_theme + theme(legend.position = "none", axis.text.y = element_blank())

gcs <- read.csv(file.path(clin, "Table4_MIMIC_GCS分层.csv"), check.names = FALSE)
gcs <- gcs[gcs$method == "IPCW-HT", ]
gcs$stratum <- factor(gcs$stratum, levels = c("GCS 13-15", "GCS 9-12", "GCS 3-8"))
pC <- ggplot(gcs, aes(RD_pp, stratum)) +
  geom_vline(xintercept = 0, linetype = 2, linewidth = .3, colour = "grey40") +
  geom_linerange(aes(xmin = RD_lo_pp, xmax = RD_hi_pp),
                 linewidth = .5, colour = "#2C3E50") +
  geom_point(size = 2.2, colour = "#2C3E50") +
  labs(x = "Risk difference (percentage points)", y = NULL,
       title = "GCS-stratified effect (MIMIC-IV)") +
  fig_theme

ml <- read.csv(file.path(clin, "22_ML分析汇总.csv"), check.names = FALSE)
pick <- rbind(
  data.frame(method = "IPCW", ATE = m$RD, lo = m$RD_lo, hi = m$RD_hi),
  data.frame(method = "Causal forest",
             ATE = ml$ATE_RD[ml$analysis == "CF_global_early_vs_other"],
             lo = ml$ATE_lo[ml$analysis == "CF_global_early_vs_other"],
             hi = ml$ATE_hi[ml$analysis == "CF_global_early_vs_other"]),
  data.frame(method = "TMLE",
             ATE = ml$ATE_RD[ml$analysis == "TMLE_early_vs_other"],
             lo = ml$ATE_lo[ml$analysis == "TMLE_early_vs_other"],
             hi = ml$ATE_hi[ml$analysis == "TMLE_early_vs_other"]),
  data.frame(method = "Super-learner IPW",
             ATE = ml$ATE_RD[ml$analysis == "SL_IPW_early_vs_other"],
             lo = ml$ATE_lo[ml$analysis == "SL_IPW_early_vs_other"],
             hi = ml$ATE_hi[ml$analysis == "SL_IPW_early_vs_other"]))
pick$method <- factor(pick$method,
                      levels = c("IPCW", "Causal forest", "TMLE",
                                 "Super-learner IPW"))
pD <- ggplot(pick, aes(ATE * 100, method)) +
  geom_vline(xintercept = 0, linetype = 2, linewidth = .3, colour = "grey40") +
  geom_linerange(aes(xmin = lo * 100, xmax = hi * 100),
                 linewidth = .5, colour = "#C0392B") +
  geom_point(size = 2.2, colour = "#C0392B") +
  labs(x = "Risk difference (percentage points)", y = NULL,
       title = "Cross-method robustness (MIMIC-IV)") +
  fig_theme

fig1 <- patchwork::wrap_plots(pA, pB, pC, pD, ncol = 2) +
  patchwork::plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(face = "bold", size = 10))
save_pdf(fig1, "Figure1_clinical_effects", 180, 130)
