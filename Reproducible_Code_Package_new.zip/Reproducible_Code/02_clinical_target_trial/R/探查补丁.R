# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# NWICU 探查补丁：解决初探的三个遗留问题
#   ① SC预防抗凝真实例数：Injection途径 + 剂量(5000U) + emar实际给药
#   ② GCS/神经评估 itemid：按 eye|verbal|motor|rass|neuro|coma 别名搜索
#   ③ INR/PT itemid：按 prothrombin|pt|inr 重搜；修正覆盖度分母
# 用法：直接 source 运行（路径已配置）
# 输出：[clinical output directory]/NWICU_探查补丁结果.txt
# ================================================================

rm(list = ls())
suppressMessages(library(data.table))

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "NWICU_探查补丁结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

f_icu <- file.path(dir_nwicu, "data/nw_icu/icustays.csv.gz")
f_rx  <- file.path(dir_nwicu, "data/nw_hosp/prescriptions.csv.gz")
f_emar<- file.path(dir_nwicu, "data/nw_hosp/emar.csv.gz")
f_dx  <- file.path(dir_nwicu, "data/nw_hosp/diagnoses_icd.csv.gz")
f_items <- file.path(dir_nwicu, "data/nw_icu/d_items.csv.gz")
f_chart <- file.path(dir_nwicu, "data/nw_icu/chartevents.csv.gz")
f_labd  <- file.path(dir_nwicu, "data/nw_hosp/d_labitems.csv.gz")
f_lab   <- file.path(dir_nwicu, "data/nw_hosp/labevents.csv.gz")

icu <- fread(f_icu); icu[, intime := as.POSIXct(intime)]
dx  <- fread(f_dx)
ich_dx <- dx[grepl("^I61", icd_code) | (grepl("^431", icd_code) & icd_version == 9)]
ich_stays <- merge(ich_dx[, .(hadm_id = unique(hadm_id))],
                   icu[, .(stay_id, subject_id, hadm_id, intime)], by = "hadm_id")
cat("ICH stay：", nrow(ich_stays), "\n\n")

# ----------------------------------------------------------------
# ① 预防性抗凝：途径细分 + 剂量 + emar
# ----------------------------------------------------------------
cat("== 1. 抗凝给药深挖 ==\n")
rx <- fread(f_rx)
hep <- rx[grepl("HEPARIN|ENOXAPARIN", drug, ignore.case = TRUE)]
cat("--- 药物名 × 途径 交叉表 ---\n")
print(hep[, .N, by = .(drug, route)][order(-N)][1:20])
cat("\n--- 预防剂量特征：heparin 5000 单位 ---\n")
hep[, dose_num := as.numeric(dose_val_rx)]
print(hep[!is.na(dose_num) & dose_num <= 10000, .N,
          by = .(drug, dose_num, dose_unit_rx, route)][order(-N)][1:15])

# 宽口径：SC/Subcutaneous/Injection 或依诺肝素，排除 IV
hep_wide <- hep[grepl("ENOXAPARIN", drug, ignore.case = TRUE) |
                  grepl("SC|SUBCUT|INJECTION", route, ignore.case = TRUE)]
hep_wide <- hep_wide[!grepl("^IV$|INTRAVENOUS", route, ignore.case = TRUE)]
hep_wide[, starttime := as.POSIXct(starttime)]
hw_ich <- merge(hep_wide, ich_stays[, .(stay_id, hadm_id, intime)], by = "hadm_id")
hw_ich[, hrs := as.numeric(difftime(starttime, intime, units = "hours"))]
fp_wide <- hw_ich[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
cat("\n宽口径（含Injection途径）ICH stay 有预防抗凝：", nrow(fp_wide), "/",
    nrow(ich_stays), "\n")
cat("首次给药时间分位（h）：")
cat(paste(round(quantile(fp_wide$first_px_hrs, c(.1,.25,.5,.75,.9)), 1), collapse = " / "), "\n")
cat("48h内：", sum(fp_wide$first_px_hrs <= 48), "；72h内：",
    sum(fp_wide$first_px_hrs <= 72), "\n")

# emar 实际给药（可能比处方更准确）
cat("\n--- emar 实际给药 ---\n")
emar <- fread(f_emar)
cat("emar 列名：", paste(names(emar), collapse = ", "), "\n")
med_col <- intersect(c("medication", "drug", "emar_name"), names(emar))[1]
time_e  <- intersect(c("charttime", "scheduletime", "given_time"), names(emar))[1]
if (!is.na(med_col)) {
  em_hep <- emar[grepl("HEPARIN|ENOXAPARIN", get(med_col), ignore.case = TRUE)]
  cat("emar 肝素/依诺肝素给药记录：", nrow(em_hep), "\n")
  cat("emar 药物名分布：\n")
  print(em_hep[, .N, by = get(med_col)][order(-N)][1:15])
  if (!is.na(time_e)) {
    em_hep[, t0 := as.POSIXct(get(time_e))]
    eh_ich <- merge(em_hep, ich_stays[, .(stay_id, hadm_id, intime)], by = "hadm_id")
    eh_ich[, hrs := as.numeric(difftime(t0, intime, units = "hours"))]
    fe <- eh_ich[hrs >= -1, .(first_hrs = min(hrs)), by = stay_id]
    cat("emar 口径 ICH stay 有给药：", nrow(fe), "/", nrow(ich_stays),
        "；48h内：", sum(fe$first_hrs <= 48), "\n")
  }
}

# ----------------------------------------------------------------
# ② GCS/神经评估 itemid 别名搜索
# ----------------------------------------------------------------
cat("\n== 2. GCS/神经评估 itemid ==\n")
items <- fread(f_items)
for (pat in c("glasgow|gcs", "eye", "verbal", "motor", "rass",
              "neuro", "coma", "conscious", "pupil", "cam", "sedat",
              "orient", "alert", "responsive")) {
  hit <- items[grepl(pat, label, ignore.case = TRUE) |
                 grepl(pat, abbreviation, ignore.case = TRUE)]
  if (nrow(hit) > 0) {
    cat("模式 '", pat, "' 命中 ", nrow(hit), " 项：\n", sep = "")
    print(hit[, .(itemid, label, category)][1:min(10, .N)])
  }
}

# ----------------------------------------------------------------
# ③ INR/PT 重搜 + 覆盖度修正
# ----------------------------------------------------------------
cat("\n== 3. 凝血化验 itemid ==\n")
labd <- fread(f_labd)
coag <- labd[grepl("prothrombin|\\bpt\\b|inr|aptt|partial thrombo|fibrinogen|d-dimer|dimer",
                   label, ignore.case = TRUE)]
print(coag[, .(itemid, label)])
lab <- fread(f_lab, select = c("hadm_id", "itemid"))
icu_hadms <- unique(icu$hadm_id)
lab_icu <- lab[hadm_id %in% icu_hadms]
for (nm_pat in list(c("INR", "inr|prothrombin"), c("PT/APTT", "prothrombin|partial thrombo"),
                    c("血小板", "platelet"), c("血红蛋白", "^hemoglobin"),
                    c("肌酐", "^creatinine$"), c("血糖", "^glucose"))) {
  hit <- labd[grepl(nm_pat[2], label, ignore.case = TRUE)]
  n_cov <- uniqueN(lab_icu[itemid %in% hit$itemid]$hadm_id)
  cat(sprintf("%s (itemid: %s)：覆盖 %d/%d ICU住院 (%.0f%%)\n",
              nm_pat[1], paste(head(hit$itemid, 5), collapse = ","),
              n_cov, length(icu_hadms), 100 * n_cov / length(icu_hadms)))
}
# ICH 亚组覆盖
ich_hadms <- unique(ich_stays$hadm_id)
lab_ich <- lab[hadm_id %in% ich_hadms]
for (nm_pat in list(c("INR", "inr|prothrombin"), c("血小板", "platelet"),
                    c("血红蛋白", "^hemoglobin"), c("肌酐", "^creatinine$"))) {
  hit <- labd[grepl(nm_pat[2], label, ignore.case = TRUE)]
  n_cov <- uniqueN(lab_ich[itemid %in% hit$itemid]$hadm_id)
  cat(sprintf("ICH亚组 %s：覆盖 %d/%d (%.0f%%)\n", nm_pat[1],
              n_cov, length(ich_hadms), 100 * n_cov / length(ich_hadms)))
}

cat("\n探查补丁完毕\n")
sink()
cat("完成，请上传 [clinical output directory]/NWICU_探查补丁结果.txt/n")

