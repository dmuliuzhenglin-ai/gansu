# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
suppressPackageStartupMessages(library(msigdbr))
c3 <- msigdbr(species = "Homo sapiens", category = "C3", subcategory = "MIR:MIRDB")
gs <- unique(c3$gs_name)
for (k in c("MIR_146","MIR_181","MIR_29","MIR_223","MIR_155","MIR_10","MIR_21")) {
  cat("###", k, "\n"); print(grep(k, gs, value = TRUE)[1:6])
}
