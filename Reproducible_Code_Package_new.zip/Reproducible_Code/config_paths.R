# ============================================================
# Central path configuration.
# This is the ONLY file you need to edit to reproduce the analyses.
# Forward slashes work on Windows, macOS and Linux.
# ============================================================
# Access-controlled databases (MIMIC-IV, eICU-CRD, NWICU, MIMIC notes) are NOT
# redistributed with this package. See README.md for how to obtain access.
# The public GEO data can be downloaded automatically by
# 01_geo_multiomics/R/02_download_all.R.
#
# Edit every "PLEASE_SET/..." value to the matching folder on your machine.
PATHS <- list(
  # folder containing this package (the extracted project root)
  project      = normalizePath(".", winslash = "/", mustWork = FALSE),
  # source folder that holds the derived clinical cohort CSV files
  clinical_src = "PLEASE_SET/clinical_cohort_source",
  # root folders of the source databases
  mimic        = "PLEASE_SET/mimic-iv-3.1/mimic-iv-3.1",
  eicu         = "PLEASE_SET/eicu-collaborative-research-database-2.0/eicu-collaborative-research-database-2.0",
  nwicu        = "PLEASE_SET/northwestern-icu-nwicu-database-0.1.0/northwestern-icu-nwicu-database-0.1.0",
  note         = "PLEASE_SET/mimic-iv-note-deidentified-free-text-clinical-notes-2.2/note",
  # working/output directory used by the clinical target-trial scripts
  clinical     = "PLEASE_SET/clinical_output",
  work         = "PLEASE_SET/working_directory"
)
