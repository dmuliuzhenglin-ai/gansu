# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 85_fig3_network.R
# Figure 3. Co-expression network and immune landscape: module-trait
# correlations with ICH, module-1 hub connectivity, and ssGSEA immune
# infiltration differences (cross-sectional and longitudinal).
source(file.path(PATHS$project, "01_code/80_fig_theme.R"))
r <- file.path(PATHS$project, "02_results")

# ---- A: module-trait correlations ----------------------------------------
mt <- read.csv(file.path(r, "GSE335924_WGCNA_module_trait.csv"),
               check.names = FALSE)
mt$lab <- paste0("M", mt$module, " (n=", mt$n_genes, ")")
mt$lab <- factor(mt$lab, levels = rev(mt$lab))
mt$sig <- ifelse(mt$FDR < .05, "FDR<0.05", "NS")
pA <- ggplot(mt, aes(cor_ICH, lab, fill = cor_ICH)) +
  geom_vline(xintercept = 0, linewidth = .3, colour = "grey40") +
  geom_col(width = .68) +
  scale_fill_gradient2(low = "#2471A3", mid = "white", high = "#C0392B",
                       midpoint = 0, limits = c(-.8, .8), name = "Correlation") +
  labs(x = "Module-ICH correlation", y = NULL,
       title = "WGCNA module-trait relationships") +
  fig_theme

# ---- B: module-1 hubs -----------------------------------------------------
hb <- read.csv(file.path(r, "GSE335924_WGCNA_hubs.csv"), check.names = FALSE)
h1 <- head(hb[hb$module == 1, ][order(-hb[hb$module == 1, ]$kme), ], 12)
h1$gene <- factor(h1$gene, levels = rev(h1$gene))
pB <- ggplot(h1, aes(kme, gene)) +
  geom_segment(aes(x = .9, xend = kme, y = gene, yend = gene),
               linewidth = .35, colour = "#C0392B") +
  geom_point(aes(colour = gene_significance), size = 2.2) +
  scale_colour_gradient(low = "#F1948A", high = "#7B241C",
                        name = "Gene\nsignificance") +
  xlim(.9, 1) +
  labs(x = "Module membership (kME)", y = NULL,
       title = "Module-1 hub genes") +
  fig_theme + theme(axis.text.y = element_text(size = 7.5))

# ---- C: cross-sectional immune infiltration -------------------------------
im <- read.csv(file.path(r, "GSE335924_immune_diff.csv"), check.names = FALSE)
im$cell <- factor(im$cell, levels = rev(im$cell))
im$sig <- ifelse(im$FDR < .05, "FDR<0.05", "NS")
pC <- ggplot(im, aes(logFC, cell, fill = sig)) +
  geom_vline(xintercept = 0, linewidth = .3, colour = "grey40") +
  geom_col(width = .7) +
  scale_fill_manual(values = c("#C0392B", "#B2BABB"), name = NULL) +
  labs(x = "ssGSEA logFC (ICH vs control)", y = NULL,
       title = "Immune infiltration, PBMC") +
  fig_theme

# ---- D: longitudinal immune (7d vs baseline) -----------------------------
im2 <- read.csv(file.path(r, "GSE296792_immune_diff.csv"), check.names = FALSE)
im2$cell <- factor(im2$cell, levels = rev(im2$cell))
im2$sig <- ifelse(im2$FDR < .05, "FDR<0.05", "NS")
pD <- ggplot(im2, aes(logFC, cell, fill = sig)) +
  geom_vline(xintercept = 0, linewidth = .3, colour = "grey40") +
  geom_col(width = .7) +
  scale_fill_manual(values = c("#C0392B", "#B2BABB"), name = NULL) +
  labs(x = "ssGSEA logFC (day 7 vs baseline)", y = NULL,
       title = "Immune infiltration, longitudinal") +
  fig_theme

fig3 <- patchwork::wrap_plots(pA, pB, pC, pD, ncol = 2) +
  patchwork::plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(face = "bold", size = 10))
save_pdf(fig3, "Figure3_network_immune", 180, 160)
