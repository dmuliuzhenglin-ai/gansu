# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# Table1 - 基线特征表(early vs delayed, 48h)
# 输入: [clinical output directory]/01_分析队列.csv (+ 02_加权后SMD.csv 提供加权后SMD列)
# 输出: [clinical output directory]/Table1_基线特征.csv (直接贴进 Word)
# 用法: source(file.path(PATHS$clinical, "Table1-基线特征表.R"), encoding="UTF-8")
# ============================================================

library(data.table)
options(error = NULL)
dir_out <- PATHS$clinical

dt <- fread(file.path(dir_out, "01_分析队列.csv"))
dt[, group := fifelse(!is.na(first_px_hrs) & first_px_hrs <= 48, "Early (<=48h)", "Delayed (>48h/none)")]
dt[, group := factor(group, levels = c("Early (<=48h)", "Delayed (>48h/none)"))]
cat("分组: ", dt[, .N, by = group][, paste(group, N, sep = "=", collapse = ", ")], "\n")

# ---- 变量清单 ----
cont_vars <- c("anchor_age", "gcs_total", "sbp", "hr", "platelet", "hemoglobin",
               "creatinine", "glucose", "inr", "icu_hours")
cont_lab  <- c("Age, years", "GCS total", "Systolic BP, mmHg", "Heart rate, bpm",
               "Platelets, 10^9/L", "Hemoglobin, g/dL", "Creatinine, mg/dL",
               "Glucose, mg/dL", "INR", "ICU LOS, hours")
cat_vars <- c("gender", "mech_vent", "neurosx", "hypertension", "diabetes",
              "prior_stroke", "atrial_fib", "ckd", "liver_dz", "malignancy",
              "longterm_ac", "race", "insurance", "admission_type")
cat_lab  <- c("Female", "Mechanical ventilation", "Neurosurgical procedure",
              "Hypertension", "Diabetes", "Prior stroke", "Atrial fibrillation",
              "Chronic kidney disease", "Liver disease", "Malignancy",
              "Long-term anticoagulation", "Race", "Insurance", "Admission type")

# ---- 加权后 SMD (来自 02_加权后SMD.csv, 按变量名匹配) ----
f_smd <- file.path(dir_out, "02_加权后SMD.csv")
smd_w <- data.table(variable = character(), SMD_weighted = numeric())
if (file.exists(f_smd)) {
  smd_w <- fread(f_smd)
  smd_w[, variable := gsub("TRUE$", "", variable)]  # mech_ventTRUE -> mech_vent
  cat("加权SMD条目:", nrow(smd_w), "\n")
}

# ---- SMD 计算 ----
smd_cont <- function(x, g) {
  x1 <- x[g == levels(g)[1]]; x0 <- x[g == levels(g)[2]]
  (mean(x1, na.rm = TRUE) - mean(x0, na.rm = TRUE)) /
    sqrt((sd(x1, na.rm = TRUE)^2 + sd(x0, na.rm = TRUE)^2) / 2)
}
smd_bin <- function(x, g) {
  p1 <- mean(x[g == levels(g)[1]] == 1, na.rm = TRUE)
  p0 <- mean(x[g == levels(g)[2]] == 1, na.rm = TRUE)
  (p1 - p0) / sqrt((p1*(1-p1) + p0*(1-p0)) / 2)
}
smd_multi <- function(x, g) {  # 多分类: 各类别SMD的均方根
  lv <- unique(na.omit(x))
  ss <- sapply(lv, function(L) smd_bin(as.integer(x == L), g)^2)
  sqrt(mean(ss, na.rm = TRUE))
}

rows <- list()
add_row <- function(var, lab, e, d, smd, w = NA_real_) {
  wm <- smd_w[variable == var]
  if (nrow(wm) == 0) wm <- smd_w[grepl(var, variable, fixed = TRUE)]
  wv <- if (nrow(wm) > 0) round(wm$SMD_weighted[1], 3) else w
  rows[[length(rows)+1]] <<- data.table(
    Characteristic = lab, `Early (<=48h)` = e, `Delayed (>48h/none)` = d,
    SMD_unweighted = round(smd, 3), SMD_weighted = wv, check.names = FALSE)
}

# 连续变量: 偏度>1 用中位数[IQR]
for (i in seq_along(cont_vars)) {
  v <- cont_vars[i]
  if (!v %in% names(dt)) next
  x <- dt[[v]]
  if (all(is.na(x))) next
  sk <- abs((mean(x, na.rm=TRUE) - median(x, na.rm=TRUE)) / sd(x, na.rm=TRUE))
  g <- dt$group
  if (sk > 0.5) {
    f <- function(s) sprintf("%.1f [%.1f, %.1f]", median(s, na.rm=TRUE),
                             quantile(s, .25, na.rm=TRUE), quantile(s, .75, na.rm=TRUE))
    lab <- paste0(cont_lab[i], ", median [IQR]")
  } else {
    f <- function(s) sprintf("%.1f (%.1f)", mean(s, na.rm=TRUE), sd(s, na.rm=TRUE))
    lab <- paste0(cont_lab[i], ", mean (SD)")
  }
  nmiss <- sum(is.na(x))
  if (nmiss > 0) lab <- paste0(lab, " (missing ", nmiss, ")")
  add_row(v, lab, f(x[g == levels(g)[1]]), f(x[g == levels(g)[2]]), smd_cont(x, g))
}

# 分类变量
for (i in seq_along(cat_vars)) {
  v <- cat_vars[i]
  if (!v %in% names(dt)) next
  x <- dt[[v]]; g <- dt$group
  ux <- unique(na.omit(x))
  if (length(ux) <= 2) {  # 二分类
    xb <- as.integer(x %in% c(1, TRUE, "1", "TRUE", "F", "Female", "Yes", "yes"))
    f <- function(s) sprintf("%d (%.1f%%)", sum(s == 1, na.rm=TRUE), 100*mean(s == 1, na.rm=TRUE))
    add_row(v, paste0(cat_lab[i], ", n (%)"),
            f(xb[g == levels(g)[1]]), f(xb[g == levels(g)[2]]), smd_bin(xb, g))
  } else {  # 多分类: 逐水平一行
    add_row(v, paste0(cat_lab[i], ", n (%)"), "", "", smd_multi(as.character(x), g))
    for (L in sort(as.character(ux))) {
      xl <- as.integer(as.character(x) == L)
      f <- function(s) sprintf("%d (%.1f%%)", sum(s == 1, na.rm=TRUE), 100*mean(s == 1, na.rm=TRUE))
      rows[[length(rows)+1]] <- data.table(
        Characteristic = paste0("   ", L),
        `Early (<=48h)` = f(xl[g == levels(g)[1]]),
        `Delayed (>48h/none)` = f(xl[g == levels(g)[2]]),
        SMD_unweighted = NA_real_, SMD_weighted = NA_real_, check.names = FALSE)
    }
  }
}

tab <- rbindlist(rows)
# 首行加 n
tab <- rbind(data.table(Characteristic = "n", `Early (<=48h)` = as.character(sum(dt$group == levels(dt$group)[1])),
                        `Delayed (>48h/none)` = as.character(sum(dt$group == levels(dt$group)[2])),
                        SMD_unweighted = NA_real_, SMD_weighted = NA_real_, check.names = FALSE), tab)
print(tab, nrow = 60)
fwrite(tab, file.path(dir_out, "Table1_基线特征.csv"))
cat("/n完成 -> [clinical output directory]/Table1_基线特征.csv/n")
cat("提示: |SMD| > 0.1 的未加权条目提示组间不平衡(加权后应 < 0.1)\n")

