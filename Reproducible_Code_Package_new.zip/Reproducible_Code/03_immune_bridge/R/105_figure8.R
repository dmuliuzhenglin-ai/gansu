# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
## 105_figure8.R
## Figure 8: 血肿后免疫轨迹（淋巴细胞 / NLR / 单核比例）与 ALBI 预后分层

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

dir_in  <- file.path(PATHS$project, "05_bridge_immune/01_data")
dir_res <- file.path(PATHS$project, "05_bridge_immune/02_results")
dir_fig <- file.path(PATHS$project, "03_figures")
dir.create(dir_fig, recursive = TRUE, showWarnings = FALSE)

traj <- fread(file.path(dir_res, "eicu_trajectory.csv"), encoding = "UTF-8")
traj[, mid := fcase(win_f == "W0", 12, win_f == "W24", 36, win_f == "W48", 60, win_f == "W72", 84)]
traj[, grp := fcase(early == 1, "Early prophylaxis (\u226448 h)", default = "Delayed / none")]
traj[, grp := factor(grp, levels = c("Early prophylaxis (\u226448 h)", "Delayed / none"))]

pal <- c("Early prophylaxis (\u226448 h)" = "#1F5673", "Delayed / none" = "#C1666B")

base_theme <- theme_classic(base_size = 10) +
  theme(
    axis.line = element_line(colour = "black", linewidth = 0.35),
    axis.ticks = element_line(colour = "black", linewidth = 0.3),
    panel.grid.major.y = element_line(colour = "grey92", linewidth = 0.25),
    legend.position = "top",
    legend.title = element_blank(),
    legend.key.size = unit(0.4, "cm"),
    plot.title = element_text(size = 10, face = "bold", hjust = 0, margin = margin(b = 4)),
    plot.margin = margin(6, 8, 4, 4)
  )

mk_panel <- function(m, ylab, title, ylim = NULL) {
  d <- traj[metric == m]
  p <- ggplot(d, aes(mid, est, colour = grp)) +
    geom_linerange(aes(ymin = lo, ymax = hi), linewidth = 0.35, alpha = 0.55) +
    geom_line(linewidth = 0.7) +
    geom_point(size = 1.7, stroke = 0.2) +
    scale_colour_manual(values = pal) +
    scale_x_continuous(breaks = c(12, 36, 60, 84),
                       labels = c("0\u201324", "24\u201348", "48\u201372", "72\u201396")) +
    labs(x = "Hours after ICU admission", y = ylab, title = title) +
    base_theme
  if (!is.null(ylim)) p <- p + coord_cartesian(ylim = ylim)
  p
}

pA <- mk_panel("alc", "Lymphocytes (K/\u00b5L)", "A  Absolute lymphocyte count")
pB <- mk_panel("nlr", "Neutrophil-to-lymphocyte ratio", "B  NLR")
pC <- mk_panel("mono_pct", "Monocytes (%)", "C  Monocyte fraction")

## D: ALBI 三分位与住院死亡
b <- fread(file.path(dir_in, "eicu_bridge_baseline.csv"), encoding = "UTF-8")
b <- b[!is.na(albi) & !is.na(hosp_mort)]
b[, hosp_mort := as.integer(hosp_mort)]
qs <- quantile(b$albi, c(1/3, 2/3))
lab_lo <- gsub("-", "\u2212", sprintf("Lowest\n(\u2264%.2f)", qs[1]))
lab_hi <- gsub("-", "\u2212", sprintf("Highest\n(>%.2f)", qs[2]))
b[, tert := cut(albi, breaks = c(min(b$albi), qs[1], qs[2], max(b$albi) + 1e-9),
                include.lowest = TRUE,
                labels = c(lab_lo, "Middle", lab_hi))]
cat("ALBI cut points:", sprintf("%.4f", c(min(b$albi), qs, max(b$albi))), "\n")
dD <- b[, .(n = .N, deaths = sum(hosp_mort)), by = tert]
dD[, rate := deaths / n * 100]
dD[, `:=`(lo = binom.test(deaths, n)$conf.int[1] * 100,
          hi = binom.test(deaths, n)$conf.int[2] * 100), by = tert]

pD <- ggplot(dD, aes(tert, rate)) +
  geom_col(width = 0.62, fill = "#6C8EAD", colour = "black", linewidth = 0.25) +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.14, linewidth = 0.35) +
  geom_text(aes(y = 2.2, label = paste0("n=", n)), size = 2.6, colour = "white") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12)), limits = c(0, 42)) +
  labs(x = "Baseline ALBI tertile", y = "In-hospital mortality (%)",
       title = "D  ALBI tertiles and mortality") +
  base_theme +
  theme(axis.text.x = element_text(size = 8))

design <- "
AB
CD
"
fig <- pA + pB + pC + pD +
  plot_layout(design = design, guides = "collect") &
  theme(legend.position = "top")

ggsave(file.path(dir_fig, "Figure8_immune_trajectory.pdf"), fig,
       width = 7.0, height = 6.2, device = cairo_pdf)
ggsave(file.path(dir_fig, "Figure8_immune_trajectory.png"), fig,
       width = 7.0, height = 6.2, dpi = 300, bg = "white")

cat("DONE: Figure8 written\n")
print(dD)
