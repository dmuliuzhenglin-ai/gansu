# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# ================================================================
# 步骤0：可行性核验（Feasibility Check）
#
# 项目：自发性脑出血（ICH）后 早期 vs 延迟 VTE药物预防
#       目标试验模拟（Target Trial Emulation）
# 数据：MIMIC-IV v3.1 + eICU-CRD v2.0
# 输出：[clinical output directory]/
#
# 运行环境：R >= 4.2，仅需 data.table（>=1.14，可直接读取 .csv.gz）
# 首次运行前请先执行：install.packages("data.table")
# ================================================================

rm(list = ls())
options(datatable.print.topn = 10)
library(data.table)

# ---------- 0. 路径配置（已按您的电脑填写） ----------
dir_mimic <- PATHS$mimic
dir_eicu  <- PATHS$eicu
dir_out   <- PATHS$clinical
dir.create(dir_out, showWarnings = FALSE, recursive = TRUE)

# 所有打印结果同时写入文件
sink(file.path(dir_out, "00_可行性结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

# ---------- 1. 编码与暴露定义 ----------
# 自发性脑出血（ICH）
ich_icd9  <- "^431"                 # ICD-9: 脑内出血
ich_icd10 <- "^I61"                 # ICD-10: 非创伤性脑内出血
# 排除：蛛网膜下腔出血(430/I60)、硬膜下血肿(432.1/I62.0)、创伤性脑损伤(850-854/S06)
excl_icd9  <- "^430|^4321|^85[0-4]"
excl_icd10 <- "^I60|^I620|^S06"

# VTE结局（肺栓塞 + 深静脉血栓）
vte_icd9  <- "^4151|^453|^4511|^4512|^4519"
vte_icd10 <- "^I26|^I80|^I82"

# 预防性抗凝药物（皮下注射视为预防；静脉泵入视为治疗，单独标记）
drug_regex <- "heparin|enoxaparin|dalteparin|lovenox"

# ================================================================
# 2. MIMIC-IV
# ================================================================
cat("========== MIMIC-IV v3.1 ==========\n\n")

adm   <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"))
pts   <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"))
diag  <- fread(file.path(dir_mimic, "hosp/diagnoses_icd.csv.gz"))
stays <- fread(file.path(dir_mimic, "icu/icustays.csv.gz"))

# --- 2.1 圈定ICH住院记录 ---
diag[, code_clean := gsub("\\.", "", icd_code)]
is_ich  <- diag[(icd_version == 9  & grepl(ich_icd9,  code_clean)) |
                  (icd_version == 10 & grepl(ich_icd10, code_clean))]
is_excl <- diag[(icd_version == 9  & grepl(excl_icd9,  code_clean)) |
                  (icd_version == 10 & grepl(excl_icd10, code_clean))]
ich_hadm <- setdiff(unique(is_ich$hadm_id), unique(is_excl$hadm_id))
cat("ICH相关住院记录数（hadm_id）：", length(ich_hadm), "\n")

# --- 2.2 限定：成人 + 有ICU记录 + 每次住院首次ICU入住 ---
stays_ich <- stays[hadm_id %in% ich_hadm]
stays_ich <- merge(stays_ich, pts[, .(subject_id, anchor_age, dod)], by = "subject_id")
stays_ich <- merge(stays_ich,
                   adm[, .(hadm_id, admittime, deathtime, hospital_expire_flag)],
                   by = "hadm_id")
stays_ich[, intime := as.POSIXct(intime)]
stays_ich <- stays_ich[anchor_age >= 18]
setorder(stays_ich, subject_id, hadm_id, intime)
stays_ich[, first_stay := seq_len(.N) == 1, by = .(subject_id, hadm_id)]
cohort_m <- stays_ich[first_stay == TRUE]
cat("成人ICH且首次ICU入住的 stay 数：", nrow(cohort_m),
    "（独立患者：", uniqueN(cohort_m$subject_id), "）\n\n")

# --- 2.3 暴露：入ICU 48小时内皮下肝素/低分子肝素 ---
rx <- fread(file.path(dir_mimic, "hosp/prescriptions.csv.gz"))
rx_pro <- rx[hadm_id %in% cohort_m$hadm_id & grepl(drug_regex, drug, ignore.case = TRUE)]
rx_pro[, is_sc := grepl("SUB|SC", route, ignore.case = TRUE)]
rx_pro[, starttime := as.POSIXct(starttime)]
rx_pro <- merge(rx_pro, cohort_m[, .(hadm_id, intime)], by = "hadm_id")
rx_pro[, hrs_from_icu := as.numeric(difftime(starttime, intime, units = "hours"))]
early_m <- rx_pro[is_sc == TRUE & hrs_from_icu >= 0 & hrs_from_icu <= 48, unique(hadm_id)]

# 静脉治疗性肝素泵（敏感性分析排除用）
d_items   <- fread(file.path(dir_mimic, "icu/d_items.csv.gz"))
hep_items <- d_items[grepl("heparin", label, ignore.case = TRUE) &
                       linksto == "inputevents", itemid]
in_ev  <- fread(file.path(dir_mimic, "icu/inputevents.csv.gz"),
                select = c("hadm_id", "itemid", "starttime"))
iv_hep_hadm <- unique(in_ev[itemid %in% hep_items & hadm_id %in% cohort_m$hadm_id, hadm_id])

cohort_m[, exposure := fifelse(hadm_id %in% early_m, "早期(<=48h)", "延迟/未用")]
cohort_m[, iv_heparin := hadm_id %in% iv_hep_hadm]

cat("暴露分布（皮下预防性抗凝，按入ICU 48h切分）：\n")
print(cohort_m[, .(N = .N,
                   比例 = sprintf("%.1f%%", 100 * .N / nrow(cohort_m))), by = exposure])
cat("其中接受静脉肝素泵入（治疗性）的记录数：", sum(cohort_m$iv_heparin), "\n\n")

# --- 2.4 结局事件率 ---
vte_m <- diag[hadm_id %in% cohort_m$hadm_id &
                ((icd_version == 9  & grepl(vte_icd9,  code_clean)) |
                   (icd_version == 10 & grepl(vte_icd10, code_clean))), unique(hadm_id)]
cohort_m[, vte := hadm_id %in% vte_m]
cohort_m[, hosp_mort := hospital_expire_flag == 1]
cohort_m[, dod_date := as.Date(dod)]
cohort_m[, adm_date := as.Date(admittime)]
cohort_m[, mort90 := !is.na(dod_date) & as.numeric(dod_date - adm_date) <= 90]

cat("结局事件率（按暴露分组）：\n")
tab_m <- cohort_m[, .(N = .N,
                      VTE        = sprintf("%.1f%%", 100 * mean(vte)),
                      院内死亡   = sprintf("%.1f%%", 100 * mean(hosp_mort)),
                      `90天死亡` = sprintf("%.1f%%", 100 * mean(mort90, na.rm = TRUE))),
                  by = exposure]
print(tab_m)

# --- 2.5 最小可检出效应（以院内死亡为例，双侧alpha=0.05，power=80%） ---
n_early <- sum(cohort_m$exposure == "早期(<=48h)")
n_late  <- sum(cohort_m$exposure == "延迟/未用")
p_base  <- mean(cohort_m$hosp_mort)
mde_val <- round((1.96 + 0.84) *
                   sqrt(p_base * (1 - p_base) / max(n_early, 1) +
                          p_base * (1 - p_base) / max(n_late, 1)), 3)
cat(sprintf("\n功效估算：早期组 n=%d，对照组 n=%d，基线院内死亡率 %.1f%%\n",
            n_early, n_late, 100 * p_base))
cat(sprintf("以80%%功效可检出的最小绝对风险差约为 %.1f 个百分点\n", 100 * mde_val))

fwrite(cohort_m[, .(subject_id, hadm_id, stay_id, exposure, iv_heparin,
                    vte, hosp_mort, mort90)],
       file.path(dir_out, "MIMIC_可行性队列.csv"))

# ================================================================
# 3. eICU-CRD v2.0
# ================================================================
cat("\n\n========== eICU-CRD v2.0 ==========\n\n")

epat  <- fread(file.path(dir_eicu, "patient.csv.gz"))
ediag <- fread(file.path(dir_eicu, "diagnosis.csv.gz"))
emed  <- fread(file.path(dir_eicu, "medication.csv.gz"))

# --- 3.1 圈定ICH（诊断文本 + ICD编码双保险） ---
ediag[, is_ich := grepl("intracerebral hemorrhage|cerebral hemorrhage|intraparenchymal",
                        diagnosisstring, ignore.case = TRUE) &
        !grepl("subarachnoid|traumatic|subdural|epidural",
               diagnosisstring, ignore.case = TRUE)]
ediag[, icd_clean := gsub("\\.", "", icd9code)]
ediag[is_ich == FALSE, is_ich := grepl("^431$|^I61", icd_clean)]
ich_stays_e <- unique(ediag[is_ich == TRUE, patientunitstayid])
cat("ICH ICU入住记录数：", length(ich_stays_e), "\n")

# --- 3.2 成人 + 每次住院首次ICU入住 ---
ecohort <- epat[patientunitstayid %in% ich_stays_e]
ecohort[, age_num := suppressWarnings(as.numeric(age))]
ecohort[age == "> 89", age_num := 90]
ecohort <- ecohort[age_num >= 18]
setorder(ecohort, uniquepid, patienthealthsystemstayid, hospitaladmitoffset)
ecohort[, first_stay := seq_len(.N) == 1, by = .(uniquepid, patienthealthsystemstayid)]
ecohort <- ecohort[first_stay == TRUE]
cat("成人ICH首次ICU入住：", nrow(ecohort),
    "（独立患者：", uniqueN(ecohort$uniquepid), "）\n\n")

# --- 3.3 暴露：drugstartoffset <= 2880分钟（48h）的皮下肝素类 ---
emed_pro <- emed[patientunitstayid %in% ecohort$patientunitstayid &
                   grepl(drug_regex, drugname, ignore.case = TRUE)]
emed_pro[, is_sc := grepl("subcut", routeadmin, ignore.case = TRUE)]
early_e <- emed_pro[is_sc == TRUE & drugstartoffset <= 2880, unique(patientunitstayid)]
ecohort[, exposure := fifelse(patientunitstayid %in% early_e, "早期(<=48h)", "延迟/未用")]

cat("暴露分布：\n")
print(ecohort[, .(N = .N,
                  比例 = sprintf("%.1f%%", 100 * .N / nrow(ecohort))), by = exposure])

# --- 3.4 结局事件率 ---
ecohort[, hosp_mort := hospitaldischargestatus == "Expired"]
evte <- unique(ediag[grepl("pulmonary embolism|deep vein thrombosis|deep venous thrombosis|venous thromboembolism",
                           diagnosisstring, ignore.case = TRUE), patientunitstayid])
ecohort[, vte := patientunitstayid %in% evte]

cat("结局事件率（注：eICU无出院后随访，无法计算90天死亡）：\n")
tab_e <- ecohort[, .(N = .N,
                     VTE      = sprintf("%.1f%%", 100 * mean(vte)),
                     院内死亡 = sprintf("%.1f%%", 100 * mean(hosp_mort))),
                 by = exposure]
print(tab_e)

fwrite(ecohort[, .(uniquepid, patientunitstayid, exposure, vte, hosp_mort)],
       file.path(dir_out, "eICU_可行性队列.csv"))

cat("\n完成。结果文件保存在：", dir_out, "\n")
sink()
cat("运行完毕，请查看 [clinical output directory]/00_可行性结果.txt/n")
# ================================================================
# 步骤0b：eICU 提取逻辑探查与修正
# 目的：解决第一版 eICU ICH队列偏小、早期暴露组仅33例的问题
# 修正点：1) ICH圈定加入 admissionDx.csv（入院诊断路径表）
#         2) 探查肝素类药物在 medication.csv 中的实际记录方式
# 输出：[clinical output directory]/00b_eICU探查结果.txt
# ================================================================

rm(list = ls())
library(data.table)

dir_eicu <- PATHS$eicu
dir_out  <- PATHS$clinical

sink(file.path(dir_out, "00b_eICU探查结果.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

epat  <- fread(file.path(dir_eicu, "patient.csv.gz"))
ediag <- fread(file.path(dir_eicu, "diagnosis.csv.gz"))
eadx  <- fread(file.path(dir_eicu, "admissionDx.csv.gz"))
emed  <- fread(file.path(dir_eicu, "medication.csv.gz"))

# ---------- 1. 入院诊断表中的出血类路径 ----------
cat("== 1. admissionDx 中含 hemorrhage/bleed 的入院诊断路径（前30） ==\n")
hem_paths <- eadx[grepl("hemorrhage|bleed|haemorrhage", admitdxpath, ignore.case = TRUE),
                  .N, by = admitdxpath][order(-N)]
print(head(hem_paths, 30))

# ICH入院诊断：脑内/脑实质出血，排除蛛网膜下腔、硬膜下、创伤
ich_adx <- eadx[grepl("intracerebral hemorrhage|intraparenchymal|cerebral hemorrhage",
                      admitdxpath, ignore.case = TRUE) &
                  !grepl("subarachnoid|subdural|epidural|traumatic",
                         admitdxpath, ignore.case = TRUE),
                unique(patientunitstayid)]
cat("\nadmissionDx 圈定的ICH入住记录数：", length(ich_adx), "\n\n")

# ---------- 2. diagnosis.csv 中的出血类诊断 ----------
cat("== 2. diagnosis.csv 中含 hemorrhage 的诊断文本（前30） ==\n")
hem_diag <- ediag[grepl("hemorrhage", diagnosisstring, ignore.case = TRUE),
                  .N, by = diagnosisstring][order(-N)]
print(head(hem_diag, 30))

ediag[, icd_clean := gsub("\\.", "", icd9code)]
ich_diag <- ediag[(grepl("intracerebral hemorrhage|cerebral hemorrhage|intraparenchymal",
                         diagnosisstring, ignore.case = TRUE) &
                     !grepl("subarachnoid|subdural|epidural|traumatic",
                            diagnosisstring, ignore.case = TRUE)) |
                    grepl("^431$|^I61", icd_clean),
                  unique(patientunitstayid)]
cat("\ndiagnosis.csv 圈定的ICH入住记录数：", length(ich_diag), "\n")

# ---------- 3. 两表合并后的ICH队列 ----------
ich_all <- union(ich_adx, ich_diag)
cat("合并后ICH入住记录数：", length(ich_all), "\n")

ecohort <- epat[patientunitstayid %in% ich_all]
ecohort[, age_num := suppressWarnings(as.numeric(age))]
ecohort[age == "> 89", age_num := 90]
ecohort <- ecohort[age_num >= 18]
setorder(ecohort, uniquepid, patienthealthsystemstayid, hospitaladmitoffset)
ecohort[, first_stay := seq_len(.N) == 1, by = .(uniquepid, patienthealthsystemstayid)]
ecohort <- ecohort[first_stay == TRUE]
cat("成人ICH首次ICU入住：", nrow(ecohort),
    "（独立患者：", uniqueN(ecohort$uniquepid), "）\n\n")

# ---------- 4. 肝素类药物在 medication.csv 中的实际记录方式 ----------
cat("== 3. ICH队列中肝素类药物的 drugname × routeadmin 分布（前40） ==\n")
emed_ich <- emed[patientunitstayid %in% ecohort$patientunitstayid &
                   grepl("heparin|enoxaparin|dalteparin|lovenox", drugname, ignore.case = TRUE)]
print(head(emed_ich[, .N, by = .(drugname, routeadmin)][order(-N)], 40))
cat("\nICH队列中共有", uniqueN(emed_ich$patientunitstayid), "例有任何肝素类药物记录\n\n")

# ---------- 5. 修正后的暴露分布 ----------
emed_pro <- emed_ich[grepl("subcut", routeadmin, ignore.case = TRUE)]
early_e  <- emed_pro[drugstartoffset <= 2880, unique(patientunitstayid)]
any_pro  <- unique(emed_pro$patientunitstayid)

ecohort[, exposure := fifelse(patientunitstayid %in% early_e, "早期(<=48h)",
                              fifelse(patientunitstayid %in% any_pro, "延迟(>48h)", "未用"))]
cat("== 4. 修正后暴露分布 ==\n")
print(ecohort[, .(N = .N,
                  比例 = sprintf("%.1f%%", 100 * .N / nrow(ecohort))), by = exposure])

# 结局
ecohort[, hosp_mort := hospitaldischargestatus == "Expired"]
cat("\n按暴露分组的院内死亡率：\n")
print(ecohort[, .(N = .N, 院内死亡 = sprintf("%.1f%%", 100 * mean(hosp_mort))), by = exposure])

fwrite(ecohort[, .(uniquepid, patientunitstayid, exposure, hosp_mort)],
       file.path(dir_out, "eICU_修正队列.csv"))

cat("\n完成。\n")
sink()
cat("运行完毕，请查看 [clinical output directory]/00b_eICU探查结果.txt/n")