# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 13_peek_163256_meta.R - 确认 GSE163256 分组（A/B/C/D/E 前缀含义）
p <- file.path(PATHS$project, "00_data/GSE163256/GSE163256_series_matrix.txt.gz")
es <- GEOquery::getGEO(filename = p, getGPL = FALSE)
cat("samples:", ncol(es), "\n")
pd <- Biobase::pData(es)
for (fld in grep(":ch1$|characteristics|source_name", colnames(pd), value = TRUE)) {
  vals <- unique(pd[[fld]])
  cat("\n", fld, "(", length(vals), "levels):\n", sep = "")
  print(vals)
}
