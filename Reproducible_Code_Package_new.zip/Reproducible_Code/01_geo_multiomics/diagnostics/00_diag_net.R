# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 网络诊断：R 内部访问 GEO 目录与文件
options(timeout = 60)
u_dir <- "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE125nnn/GSE125512/"
u_file <- "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE125nnn/GSE125512/GSE125512_family.soft.gz"

cat("R version:", R.version.string, "\n")
cat("default download method:", getOption("download.file.method"), "\n")
cat("libcurl built:", capabilities("libcurl"), "\n")

for (m in c("auto", "libcurl", "wininet")) {
  cat("\n=== method:", m, "===\n")
  options(download.file.method = m)
  tf <- tempfile()
  res <- try(download.file(u_dir, tf, quiet = TRUE), silent = TRUE)
  if (!inherits(res, "try-error")) {
    cat("dir download OK, bytes=", file.info(tf)$size, "\n")
    h <- try(xml2::read_html(tf), silent = TRUE)
    if (!inherits(h, "try-error")) {
      links <- xml2::xml_text(xml2::xml_find_all(h, "//a/@href"))
      cat("parsed links:", length(links), "\n")
      print(head(links, 10))
    } else cat("html parse fail:", as.character(h), "\n")
  } else cat("dir download fail:", as.character(res), "\n")
  unlink(tf)
}

cat("\n=== direct read_html ===\n")
h <- try(xml2::read_html(u_dir), silent = TRUE)
if (!inherits(h, "try-error")) cat("read_html OK\n") else cat("read_html fail:", as.character(h), "\n")
