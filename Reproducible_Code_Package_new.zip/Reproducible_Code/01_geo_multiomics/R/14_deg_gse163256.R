# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 14_deg_gse163256.R
# GSE163256: 21 ICH patients (longitudinal, day1-6) + 6 healthy controls (HC)
# Core case-control DEG: ICH blood at trial day 1 (baseline) vs HC blood,
# run separately for monocytes and neutrophils, edgeR QL.
suppressPackageStartupMessages({ library(edgeR); library(dplyr) })
root <- PATHS$project
data_root <- file.path(root, "00_data/GSE163256")
resdir <- file.path(root, "02_results")

# pData from series matrix
es <- GEOquery::getGEO(filename = file.path(data_root,
  "GSE163256_series_matrix.txt.gz"), getGPL = FALSE)
pd <- Biobase::pData(es)
pd$sid <- pd$description          # internal name matching counts columns
pd$source <- pd$source_name_ch1
pd$cell <- ifelse(grepl("monos", pd$characteristics_ch1), "monos", "neuts")
pd$day <- suppressWarnings(as.integer(
  sub("day of trial: ", "", pd$characteristics_ch1.3)))
pd$patient <- sub("patientid: ", "", pd$characteristics_ch1.2)
is_hc <- grepl("^HC", pd$patient)

read_counts <- function(cell) {
  f <- file.path(data_root, sprintf("GSE163256_%s_counts.csv.gz", cell))
  m <- as.matrix(read.csv(gzfile(f), row.names = 1, check.names = FALSE))
  storage.mode(m) <- "integer"
  m
}

all_res <- list()
for (cell in c("monos", "neuts")) {
  cnt <- read_counts(cell)
  meta <- pd[pd$cell == cell, ]
  meta$hc <- grepl("^HC", meta$patient)
  # baseline case-control: HC blood (single draw) vs ICH blood at day 1
  keep_meta <- meta[(meta$hc & meta$source == "HC blood") |
                    (!meta$hc & meta$source == "blood" & meta$day == 1), ]
  keep_sids <- intersect(keep_meta$sid, colnames(cnt))
  x <- cnt[, keep_sids, drop = FALSE]
  grp <- ifelse(keep_meta$hc[match(keep_sids, keep_meta$sid)], "HC", "ICH")
  group <- factor(grp, levels = c("HC", "ICH"))
  cat("\n===", cell, "baseline HC vs ICH:", table(group), "===\n")

  y <- DGEList(x, group = group)
  k <- filterByExpr(y, group = group)
  y <- y[k, , keep.lib.sizes = FALSE]
  y <- calcNormFactors(y)
  design <- model.matrix(~group)
  y <- estimateDisp(y, design)
  fit <- glmQLFit(y, design, robust = TRUE)
  qlf <- glmQLFTest(fit, coef = "groupICH")
  tt <- topTags(qlf, n = Inf)$table
  tt$gene <- rownames(tt); tt$cell <- cell
  tt$contrast <- "ICH_day1_vs_HC"
  tt$regulation <- "NS"
  tt$regulation[tt$FDR < 0.05 & tt$logFC >= 1]  <- "up"
  tt$regulation[tt$FDR < 0.05 & tt$logFC <= -1] <- "down"
  cat("genes tested:", nrow(tt), "\n"); print(table(tt$regulation))
  all_res[[cell]] <- tt[, c("gene", "cell", "contrast", "logFC", "logCPM",
                            "PValue", "FDR", "regulation")]
}
out <- do.call(rbind, all_res); rownames(out) <- NULL
write.csv(out, file.path(resdir, "GSE163256_DEG_baseline.csv"), row.names = FALSE)
cat("\ntop monos DEGs:\n")
print(head(all_res$monos[order(all_res$monos$FDR),
      c("gene","logFC","FDR","regulation")], 12), row.names = FALSE)
cat("\ntop neuts DEGs:\n")
print(head(all_res$neuts[order(all_res$neuts$FDR),
      c("gene","logFC","FDR","regulation")], 12), row.names = FALSE)
cat("\nGSE163256 baseline DEG done\n")
