# -*- coding: utf-8 -*-
"""Central path configuration (Python).

This is the ONLY file you need to edit. Access-controlled databases are not
redistributed; see README.md for access instructions.
"""
import os

PATHS = {
    # folder containing this package (the extracted project root)
    "project": os.path.abspath("."),
    # source folder that holds the derived clinical cohort CSV files
    "clinical_src": "PLEASE_SET/clinical_cohort_source",
    # root folders of the source databases
    "mimic": "PLEASE_SET/mimic-iv-3.1/mimic-iv-3.1",
    "eicu": "PLEASE_SET/eicu-collaborative-research-database-2.0/eicu-collaborative-research-database-2.0",
    "nwicu": "PLEASE_SET/northwestern-icu-nwicu-database-0.1.0/northwestern-icu-nwicu-database-0.1.0",
    "note": "PLEASE_SET/mimic-iv-note-deidentified-free-text-clinical-notes-2.2/note",
    # working/output directory used by the clinical target-trial scripts
    "clinical": "PLEASE_SET/clinical_output",
    "work": "PLEASE_SET/working_directory",
}
