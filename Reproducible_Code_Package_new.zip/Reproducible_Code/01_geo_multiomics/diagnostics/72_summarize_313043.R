# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 汇总 GSE313043 核心结果
resdir <- file.path(PATHS$project, "02_results")
cat("=== composition by treatment ===\n")
tx <- read.csv(file.path(resdir, "GSE313043_composition_treatment.csv"))
print(tidyr::pivot_wider(tx, names_from = Var2, values_from = Freq))
cat("\n=== composition by day ===\n")
dy <- read.csv(file.path(resdir, "GSE313043_composition_day.csv"))
print(tidyr::pivot_wider(dy, names_from = Var2, values_from = Freq))
cat("\n=== hub pct expressing (key genes) ===\n")
hp <- read.csv(file.path(resdir, "GSE313043_hub_pct_expressing.csv"),
               check.names = FALSE, row.names = 1)
key <- intersect(c("ADM","FKBP5","IL1R2","ALOX5AP","ALPL","ANXA3","ARG1",
                   "ACSL1","CD74","HLA-DRA","STAT1","S100A8","S100A9"),
                 rownames(hp))
print(round(hp[key, ], 2))
