# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E5 - 连续剂量-反应: 给药时间 vs 院内死亡 (eICU 主, NWICU 备)
# 方法: 细时间窗逐项 TTE —— 每个窗口 [a,b) 内的首次给药 vs 延迟/不预防
#   窗口: 0-12,12-24,24-36,36-48,48-72,72-96,96-168h; 对照统一为 ">Gmax 或不预防"
#   每个窗口用 IPCW-HT (kept 子集, 与主分析同框架), bootstrap 300
# 输出: E5_剂量反应.csv + E5_剂量反应.png
# 用法: source(file.path(PATHS$clinical, "步骤E5-剂量反应.R"), encoding="UTF-8")   约 15 分钟
# ============================================================

library(data.table)
options(error = NULL); set.seed(2026)
dir_out <- PATHS$clinical
B <- 300

xvars <- c("age","female","gcs","mech_vent","neurosx","sbp","hr",
           "platelet","hemoglobin","creatinine","glucose",
           "hypertension","diabetes","ckd","heart_failure","malignancy","liver",
           "prior_vte","prior_stroke")
windows <- list(c(0,12), c(12,24), c(24,36), c(36,48), c(48,72), c(72,96), c(96,168))

win_est <- function(dt, lo, hi, use, B) {
  n <- nrow(dt)
  cl <- rbind(copy(dt)[, arm := 1L], copy(dt)[, arm := 0L])
  # 早臂: 首次给药落在 [lo,hi); 对照臂: 晚于 hi 或从不
  cl[, adherent := as.integer((arm == 1 & !is.na(first_px_hrs) & first_px_hrs >= lo & first_px_hrs < hi) |
                                (arm == 0 & (is.na(first_px_hrs) | first_px_hrs >= hi)))]
  cl[, tdiv := pmin(first_px_hrs, hi, na.rm = TRUE)]
  cl[, ev_before_div := as.integer(hosp_mort == 1 & death_hrs <= tdiv)]
  cl[, Y := hosp_mort]
  cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
  n_early <- sum(cl$adherent[cl$arm == 1])
  if (n_early < 15) return(NULL)
  f <- reformulate(c("factor(arm)", use), response = "adherent")
  m <- suppressWarnings(glm(f, data = cl[ev_before_div == 0], family = binomial))
  pc <- pmin(pmax(predict(m, newdata = cl, type = "response"), 0.02), 0.98)
  cl[, w := fifelse(kept == 1 & ev_before_div == 1, 1, fifelse(kept == 1, 1/pc, 0))]
  est <- function(cc, nn) {
    k <- cc[kept == 1]
    r1 <- sum(k$w * (k$arm == 1) * k$Y) / nn
    r0 <- sum(k$w * (k$arm == 0) * k$Y) / nn
    r1 - r0
  }
  rd <- est(cl, n)
  subj <- dt$subject_id; uids <- unique(subj)
  boot <- replicate(B, {
    db <- dt[subject_id %in% sample(uids, length(uids), TRUE)]
    nb <- nrow(db)
    cb <- rbind(copy(db)[, arm := 1L], copy(db)[, arm := 0L])
    cb[, adherent := as.integer((arm == 1 & !is.na(first_px_hrs) & first_px_hrs >= lo & first_px_hrs < hi) |
                                  (arm == 0 & (is.na(first_px_hrs) | first_px_hrs >= hi)))]
    cb[, tdiv := pmin(first_px_hrs, hi, na.rm = TRUE)]
    cb[, ev_before_div := as.integer(hosp_mort == 1 & death_hrs <= tdiv)]
    cb[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
    cb[, Y := hosp_mort]
    mb <- tryCatch(suppressWarnings(glm(f, data = cb[ev_before_div == 0], family = binomial,
                                        control = list(maxit = 50))), error = function(e) NULL)
    if (is.null(mb)) return(NA_real_)
    pcb <- pmin(pmax(predict(mb, newdata = cb, type = "response"), 0.02), 0.98)
    cb[, w := fifelse(kept == 1 & ev_before_div == 1, 1, fifelse(kept == 1, 1/pcb, 0))]
    est(cb, nb)
  })
  ci <- quantile(boot, c(.025, .975), na.rm = TRUE)
  data.table(win = sprintf("%d-%dh", lo, hi), mid = (lo+hi)/2, n_early = n_early,
             rd_pp = round(100*rd, 2), rd_lo = round(100*ci[1], 2), rd_hi = round(100*ci[2], 2))
}

run_db <- function(dt, label) {
  dt <- copy(dt)
  if (!"female" %in% names(dt)) dt[, female := as.integer(gender == "Female")]
  if (!"death_hrs" %in% names(dt))
    dt[, death_hrs := fifelse(hosp_mort == 1, as.numeric(hospitaldischargeoffset)/60, Inf)]
  use <- intersect(xvars, names(dt))
  for (v in use) if (any(is.na(dt[[v]]))) dt[is.na(get(v)), (v) := median(dt[[v]], na.rm = TRUE)]
  cat("\n=====", label, "=====\n")
  res <- rbindlist(lapply(windows, function(w) {
    r <- win_est(dt, w[1], w[2], use, B)
    if (!is.null(r)) cat(sprintf("  %s: n=%d, RD %+.2fpp (%+.2f,%+.2f)\n",
                                 r$win, r$n_early, r$rd_pp, r$rd_lo, r$rd_hi))
    r
  }))
  res[, db := label]
  res
}

res <- list()
res[["eICU"]] <- run_db(fread(file.path(dir_out, "E1_分析队列.csv")), "eICU")
if (file.exists(file.path(dir_out, "N1_分析队列.csv")))
  res[["NWICU"]] <- run_db(fread(file.path(dir_out, "N1_分析队列.csv")), "NWICU")
res_all <- rbindlist(res)
print(res_all)
fwrite(res_all, file.path(dir_out, "E5_剂量反应.csv"))

# 绘图
png(file.path(dir_out, "E5_剂量反应.png"), width = 1800, height = 1200, res = 200)
par(mar = c(5,5,3,1))
cols <- c(eICU = "#2166AC", NWICU = "#B2182B")
plot(NA, xlim = c(0, 170), ylim = c(min(res_all$rd_lo, na.rm=TRUE)-2, 5),
     xlab = "Time of first prophylactic dose (h since ICU admission)",
     ylab = "Risk difference vs delayed/none (pp)", main = "Dose-response: timing of first prophylactic anticoagulant dose")
abline(h = 0, lty = 3, col = "grey50")
for (dbn in unique(res_all$db)) {
  d <- res_all[db == dbn]
  lines(d$mid, d$rd_pp, col = cols[dbn], lwd = 2)
  points(d$mid, d$rd_pp, col = cols[dbn], pch = 16, cex = 1.3)
  arrows(d$mid, d$rd_lo, d$mid, d$rd_hi, col = cols[dbn], angle = 90, code = 3, length = 0.05)
}
legend("bottomleft", legend = names(cols), col = cols, lwd = 2, pch = 16, bty = "n")
dev.off()
cat("\n完成 -> E5_剂量反应.csv / E5_剂量反应.png\n")

