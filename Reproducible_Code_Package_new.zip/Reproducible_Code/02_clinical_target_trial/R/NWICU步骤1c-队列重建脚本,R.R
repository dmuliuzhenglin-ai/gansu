# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# NWICU 步骤1c：队列重建（整合1b全部修正 + 正确VTE口径）
# 相对1b的变化：
#   ① 不再用"本次住院VTE编码"做排除 → 既往VTE仅指同一患者更早住院的编码
#   ② 结局vte = 本次住院VTE编码（保留在队列中）
#   ③ 整合1b修正：emar排除Not Given、机械通气/神外取自procedureevents、
#      院内死亡用deathtime、mort90与院内死亡取并集
# 输入：NWICU 0.1.0
# 输出：覆盖保存 [clinical output directory]/N1_分析队列.csv + N1c_队列摘要.txt
# ================================================================

rm(list = ls())
suppressMessages(library(data.table))

dir_nwicu <- PATHS$nwicu
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "N1c_队列摘要.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

rd <- function(rel, ...) fread(file.path(dir_nwicu, rel), ...)

# ----------------------------------------------------------------
# 1. ICH 队列
# ----------------------------------------------------------------
cat("== 1. ICH 队列 ==\n")
icu <- rd("data/nw_icu/icustays.csv.gz")
icu[, intime := as.POSIXct(intime)]
dx  <- rd("data/nw_hosp/diagnoses_icd.csv.gz")
adm <- rd("data/nw_hosp/admissions.csv.gz")
adm[, admittime := as.POSIXct(admittime)]
ich_dx <- dx[grepl("^I61", icd_code) | (grepl("^431", icd_code) & icd_version == 9)]
cohort <- merge(ich_dx[, .(hadm_id = unique(hadm_id))], icu, by = "hadm_id")
cat("ICH ICU stay：", nrow(cohort), "\n")

# ----------------------------------------------------------------
# 2. 暴露：emar实际给药（排除Not Given）
# ----------------------------------------------------------------
cat("\n== 2. 暴露 ==\n")
emar <- rd("data/nw_hosp/emar.csv.gz")
emar[, charttime := as.POSIXct(charttime)]
hep_all <- emar[grepl("HEPARIN|ENOXAPARIN", medication, ignore.case = TRUE)]
proph <- hep_all[
  (grepl("HEPARIN.*5000", medication, ignore.case = TRUE) &
     !grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("30 MG|40 MG", medication, ignore.case = TRUE))
]
proph <- proph[event_txt != "Not Given" | is.na(event_txt)]
px <- merge(proph[, .(hadm_id, charttime)],
            cohort[, .(stay_id, hadm_id, intime)], by = "hadm_id")
px[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
first_px <- px[hrs >= -1, .(first_px_hrs = min(hrs)), by = stay_id]
cohort <- merge(cohort, first_px, by = "stay_id", all.x = TRUE, sort = FALSE)
cat("有预防抗凝：", sum(!is.na(cohort$first_px_hrs)), "/", nrow(cohort),
    "；48h内：", sum(cohort$first_px_hrs <= 48, na.rm = TRUE), "\n")

# ----------------------------------------------------------------
# 3. 排除：治疗剂量抗凝 + 既往VTE（仅更早住院）
# ----------------------------------------------------------------
cat("\n== 3. 排除 ==\n")
therap <- hep_all[
  (grepl("HEPARIN", medication, ignore.case = TRUE) &
     grepl("IV SOLP|IV SYRG|INFUSION|BOLUS|NACL|DEX", medication, ignore.case = TRUE)) |
    (grepl("ENOXAPARIN", medication, ignore.case = TRUE) &
       grepl("80 MG|100 MG|120 MG|150 MG", medication, ignore.case = TRUE))
]
therap <- therap[event_txt != "Not Given" | is.na(event_txt)]
n0 <- nrow(cohort)
cohort <- cohort[!hadm_id %in% unique(therap$hadm_id)]
cat("排除治疗剂量抗凝：", n0 - nrow(cohort), "；剩余", nrow(cohort), "\n")

# 既往VTE：同一患者更早住院（admittime < 本次）的VTE编码
vte_pat <- "^I26|^I80|^I82|^453|^4151"
cur <- merge(cohort[, .(hadm_id, subject_id)],
             adm[, .(hadm_id, admittime)], by = "hadm_id", all.x = TRUE, sort = FALSE)
prior <- merge(cur, dx[grepl(vte_pat, icd_code),
                       .(subject_id, dx_hadm = hadm_id)],
               by = "subject_id", allow.cartesian = TRUE)
prior <- merge(prior, adm[, .(dx_hadm = hadm_id, dx_time = admittime)],
               by = "dx_hadm")
prior_vte <- unique(prior[dx_hadm != hadm_id & dx_time < admittime]$hadm_id)
cat("既往VTE（更早住院编码）：", length(prior_vte), "个住院\n")
n0 <- nrow(cohort)
cohort <- cohort[!hadm_id %in% prior_vte]
cat("排除既往VTE：", n0 - nrow(cohort), "；剩余", nrow(cohort), "\n")

# ----------------------------------------------------------------
# 4. 人口学 + 合并症
# ----------------------------------------------------------------
cat("\n== 4. 人口学与合并症 ==\n")
pat <- rd("data/nw_hosp/patients.csv.gz")
cohort <- merge(cohort, pat[, .(subject_id, gender, anchor_age)], by = "subject_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, adm[, .(hadm_id, race, insurance, admission_type, deathtime)],
                by = "hadm_id", all.x = TRUE, sort = FALSE)
dx_all <- dx[hadm_id %in% cohort$hadm_id]
flag_dx <- function(p10, p9) {
  hit <- dx_all[grepl(p10, icd_code) & icd_version == 10 |
                  grepl(p9, icd_code) & icd_version == 9]
  unique(hit$hadm_id)
}
cohort[, `:=`(
  hypertension = as.integer(hadm_id %in% flag_dx("^I1[0-5]", "^401|^402|^403|^405")),
  diabetes     = as.integer(hadm_id %in% flag_dx("^E1[01]", "^250")),
  atrial_fib   = as.integer(hadm_id %in% flag_dx("^I48", "^42731")),
  ckd          = as.integer(hadm_id %in% flag_dx("^N18", "^585")),
  liver_dz     = as.integer(hadm_id %in% flag_dx("^K7[0-6]", "^571")),
  malignancy   = as.integer(hadm_id %in% flag_dx("^C", "^1[4-9][0-9]|^2[0-3][0-9]")),
  longterm_ac  = as.integer(hadm_id %in% flag_dx("^Z7901|^Z7902", "^V5812|^V5861")),
  prior_stroke = as.integer(hadm_id %in% flag_dx("^I69|^Z8673", "^438|^V1254"))
)]
print(round(100 * cohort[, lapply(.SD, mean),
                         .SDcols = c("hypertension","diabetes","atrial_fib","ckd","liver_dz",
                                     "malignancy","longterm_ac","prior_stroke")], 1))

# ----------------------------------------------------------------
# 5. 机械通气 + 神外（procedureevents）
# ----------------------------------------------------------------
cat("\n== 5. 机械通气与神外 ==\n")
items <- rd("data/nw_icu/d_items.csv.gz")
vent_ids <- items[grepl("INTUBATION|MECHANICAL VENTILATION|NON-INVASIVE VENTILATION",
                        label, ignore.case = TRUE)]$itemid
nsx_ids  <- items[grepl("NEUROSURG", label, ignore.case = TRUE)]$itemid
proc <- rd("data/nw_icu/procedureevents.csv.gz")
cohort[, mech_vent := as.integer(stay_id %in% proc[itemid %in% vent_ids]$stay_id)]
cohort[, neurosx   := as.integer(stay_id %in% proc[itemid %in% nsx_ids]$stay_id)]
cat("机械通气：", sum(cohort$mech_vent), "；神外：", sum(cohort$neurosx), "\n")

# ----------------------------------------------------------------
# 6. 生命体征（首24h中位数）
# ----------------------------------------------------------------
cat("\n== 6. 生命体征 ==\n")
sbp_id <- items[grepl("systolic|sbp", label, ignore.case = TRUE)]$itemid[1]
hr_id  <- items[grepl("^heart rate|^pulse$", label, ignore.case = TRUE)]$itemid[1]
ch <- rd("data/nw_icu/chartevents.csv.gz",
         select = c("stay_id", "itemid", "charttime", "valuenum"))
ch[, charttime := as.POSIXct(charttime)]
ch_c <- merge(ch, cohort[, .(stay_id, intime)], by = "stay_id", sort = FALSE)
ch_c[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
ch24 <- ch_c[hrs >= 0 & hrs <= 24 & !is.na(valuenum)]
v_sbp <- ch24[itemid == sbp_id & valuenum >= 40 & valuenum <= 280,
              .(sbp = median(valuenum)), by = stay_id]
v_hr  <- ch24[itemid == hr_id & valuenum >= 30 & valuenum <= 220,
              .(hr = median(valuenum)), by = stay_id]
cohort <- merge(cohort, v_sbp, by = "stay_id", all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, v_hr,  by = "stay_id", all.x = TRUE, sort = FALSE)
cat(sprintf("SBP覆盖：%.0f%%；HR覆盖：%.0f%%\n",
            100 * mean(!is.na(cohort$sbp)), 100 * mean(!is.na(cohort$hr))))

# ----------------------------------------------------------------
# 7. 化验（首24h中位数）
# ----------------------------------------------------------------
cat("\n== 7. 化验 ==\n")
labd <- rd("data/nw_hosp/d_labitems.csv.gz")
lab <- rd("data/nw_hosp/labevents.csv.gz",
          select = c("hadm_id", "itemid", "charttime", "valuenum"))
lab[, charttime := as.POSIXct(charttime)]
lab_c <- merge(lab, unique(cohort[, .(hadm_id, intime)]), by = "hadm_id")
lab_c[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
lab24 <- lab_c[hrs >= 0 & hrs <= 24 & !is.na(valuenum)]
get_lab <- function(pattern, nm) {
  ids <- labd[grepl(pattern, label, ignore.case = TRUE)]$itemid
  v <- lab24[itemid %in% ids, .(v = median(valuenum)), by = hadm_id]
  setnames(v, "v", nm)
  v
}
cohort <- merge(cohort, get_lab("platelet", "platelet"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, get_lab("^hemoglobin", "hemoglobin"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, get_lab("^creatinine$", "creatinine"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
cohort <- merge(cohort, get_lab("^glucose", "glucose"), by = "hadm_id",
                all.x = TRUE, sort = FALSE)
print(round(100 * cohort[, lapply(.SD, function(x) mean(!is.na(x))),
                         .SDcols = c("platelet","hemoglobin","creatinine","glucose")], 1))

# ----------------------------------------------------------------
# 8. 结局（含VTE本次住院口径）
# ----------------------------------------------------------------
cat("\n== 8. 结局 ==\n")
cohort[, death_hrs := as.numeric(difftime(as.POSIXct(deathtime), intime,
                                          units = "hours"))]
cohort[, hosp_mort := as.integer(!is.na(death_hrs))]
cohort <- merge(cohort, pat[, .(subject_id, dod)], by = "subject_id",
                all.x = TRUE, sort = FALSE)
cohort[, death90_hrs := as.numeric(as.Date(dod) - as.Date(intime)) * 24]
cohort[!is.na(death_hrs) & (is.na(death90_hrs) | death90_hrs > 90 * 24) &
         death_hrs <= 90 * 24, death90_hrs := death_hrs]
cohort[, mort90 := as.integer(!is.na(death90_hrs) & death90_hrs <= 90 * 24)]
vte_cur <- dx[grepl("^I26|^I82", icd_code) & icd_version == 10 |
                grepl("^4151|^453", icd_code) & icd_version == 9]
cohort[, vte := as.integer(hadm_id %in% unique(vte_cur$hadm_id))]
cat("院内死亡：", sum(cohort$hosp_mort), sprintf("(%.1f%%)", 100*mean(cohort$hosp_mort)),
    "；90天：", sum(cohort$mort90), sprintf("(%.1f%%)", 100*mean(cohort$mort90)),
    "；VTE：", sum(cohort$vte), sprintf("(%.1f%%)\n", 100*mean(cohort$vte)))

# ----------------------------------------------------------------
# 9. 保存
# ----------------------------------------------------------------
keep_cols <- c("subject_id","hadm_id","stay_id","intime","anchor_age","gender",
               "race","insurance","admission_type","hypertension","diabetes",
               "prior_stroke","atrial_fib","ckd","liver_dz","malignancy",
               "longterm_ac","mech_vent","neurosx","sbp","hr","platelet",
               "hemoglobin","creatinine","glucose","first_px_hrs","vte",
               "hosp_mort","mort90","death_hrs","death90_hrs")
out <- cohort[, ..keep_cols]
fwrite(out, file.path(dir_out, "N1_分析队列.csv"))
cat("\n最终队列：", nrow(out), " stay；48h内早期预防：",
    sum(out$first_px_hrs <= 48, na.rm = TRUE), "\n")
cat("已覆盖保存：", file.path(dir_out, "N1_分析队列.csv"), "\n")
sink()
cat("完成，请上传 N1c_队列摘要.txt\n")
