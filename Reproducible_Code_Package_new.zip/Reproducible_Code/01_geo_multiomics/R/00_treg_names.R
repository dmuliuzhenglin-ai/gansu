# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
Sys.setenv(http_proxy = "http://127.0.0.1:7897",
           https_proxy = "http://127.0.0.1:7897")
suppressPackageStartupMessages(library(msigdbr))
c8 <- msigdbr(species = "Homo sapiens", category = "C8")
gs <- unique(c8$gs_name)
cat("sets containing REG:\n"); print(grep("REG", gs, value = TRUE))
cat("\nGSVA version:", as.character(packageVersion("GSVA")), "\n")
cat("ssgseaParam exists:", exists("ssgseaParam"), "\n")
print(args(ssgseaParam))
