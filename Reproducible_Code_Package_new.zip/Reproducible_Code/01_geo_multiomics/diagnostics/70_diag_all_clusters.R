# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 全 cluster 检查真中性粒特异标记 FCGR3B/CXCR2
suppressPackageStartupMessages(library(Seurat))
sobj <- readRDS(file.path(PATHS$project, "02_results/GSE313043_seurat.rds"))
expr_data <- GetAssayData(sobj, layer = "data"); clusters <- sobj$seurat_clusters
clv <- levels(clusters)
genes <- c("FCGR3B","CXCR2","CSF3R","S100A12","CD14","VCAN","FCGR3A")
out <- sapply(clv, function(cl) {
  cells <- which(clusters == cl)
  sapply(genes, function(g) {
    if (!g %in% rownames(expr_data)) return(NA)
    mean(expr_data[g, cells] > 0)
  })
})
colnames(out) <- clv
print(round(t(out), 2))
