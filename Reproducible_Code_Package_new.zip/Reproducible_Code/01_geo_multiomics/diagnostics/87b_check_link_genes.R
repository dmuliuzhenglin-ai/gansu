# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
deg <- read.csv(file.path(PATHS$project, "02_results/cross_DEG_long.csv"),
                check.names = FALSE)
e <- deg[deg$gene %in% c("RNASE3", "VNN3"), ]
print(e[, c("gene", "unit", "logFC", "direction")])
print(stats::aggregate(logFC ~ gene, e, mean))
