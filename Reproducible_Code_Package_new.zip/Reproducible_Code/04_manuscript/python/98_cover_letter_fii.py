# --- shared path configuration; edit config_paths.py for your local machine ---
import os as _os, sys as _sys
for _cf in ("config_paths.py", "../../config_paths.py", "../config_paths.py",
            "../../../config_paths.py", "../../../../config_paths.py"):
    if _os.path.exists(_cf):
        _d = _os.path.dirname(_os.path.abspath(_cf))
        if _d not in _sys.path:
            _sys.path.insert(0, _d)
        import config_paths as _cp
        PATHS = _cp.PATHS
        break
# -*- coding: utf-8 -*-
"""Generate the Frontiers in Immunology cover letter (revised to match the
reviewed manuscript: null IV, no recorded VTE decrease, exploratory forest)."""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = PATHS["project"] + r"\04_manuscript\Cover_Letter_Frontiers_Immunology.docx"

doc = Document()
st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(10.5)
rpr = st.element.get_or_add_rPr()
rf = rpr.find(qn("w:rFonts"))
if rf is None:
    rf = OxmlElement("w:rFonts")
    rpr.append(rf)
for k in ("ascii", "hAnsi", "eastAsia"):
    rf.set(qn("w:" + k), "Times New Roman")

for s in doc.sections:
    s.top_margin = Cm(1.9)
    s.bottom_margin = Cm(1.9)
    s.left_margin = Cm(2.2)
    s.right_margin = Cm(2.2)


def para(text, space_after=6, bold=False, size=10.5):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(size)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.05
    return p


para("Department of Neurosurgery, The Second Affiliated Hospital of Dalian Medical University", space_after=0)
para("467 Zhongshan Road, Shahekou District, Dalian 116023, China  |  jyin@dmu.edu.cn  |  +86 17709876333", space_after=12)

para("23 November 2026", space_after=12)

para("Dear Editor,", space_after=10)

para("We submit for your consideration as an Original Research article in Frontiers in "
     "Immunology (Inflammation section) the manuscript entitled:", space_after=8)

para("\u201cImmunosuppressive myeloid reprogramming after intracerebral hemorrhage: "
     "multi-omics mechanisms and a three-database target trial of early venous "
     "thromboembolism prophylaxis\u201d", bold=True, space_after=10)

para("Intracerebral hemorrhage (ICH) is followed by a systemic immune response that is "
     "recognized clinically but has never been given a molecular anatomy. At the same time, "
     "the timing of pharmacological venous thromboembolism (VTE) prophylaxis after ICH has "
     "been argued over for three decades without any mechanistic frame. Our manuscript "
     "brings these two problems together and asks whether the immune response is the "
     "missing link between them.", space_after=8)

para("The immunological finding is the spine of the paper. Across four independent bulk "
     "transcriptomic cohorts, ICH produced a conserved programme in which neutrophil and "
     "monocyte activation is coupled to a coordinated shutdown of antigen presentation: "
     "HLA-DRA, HLA-DQB1, CD74 and their transactivator CIITA were among the most "
     "consistently repressed transcripts. Consensus enrichment analysis resolved the "
     "response into two arms that move in opposite directions, an inflammatory arm "
     "(neutrophil degranulation, Toll-like receptor and NF-kB signalling) and an "
     "immunosuppressive arm (MHC class II presentation, T-cell co-stimulation, "
     "immunoglobulin gene sets). A myeloid and interferon-weighted co-expression module "
     "tracked the ICH state; deconvolution assigned the shift to neutrophils and monocytes; "
     "and single-cell transcriptomes from three independent datasets placed the hub genes "
     "in neutrophils, microglia and endothelial cells rather than lymphocytes. Methylation "
     "and microRNA layers are reported as exploratory support, with their limits stated "
     "explicitly.", space_after=8)

para("The clinical component emulates a target trial of early (within 48 h) versus delayed "
     "prophylaxis in MIMIC-IV, eICU-CRD and NWICU, using clone-censor-weight designs with "
     "cross-fitted augmented and machine-learning estimators. Early prophylaxis was "
     "associated with lower in-hospital mortality (risk difference -4.2 percentage points "
     "in MIMIC-IV, -3.5 in eICU) without increased hematoma expansion, with the largest "
     "association in Glasgow Coma Scale 3-8; in NWICU the inverse-probability estimate "
     "was null after the same deterministic rerun, while the augmented estimate remained "
     "protective. We do not present this as a causal effect: "
     "recorded VTE did not decrease, the hospital-preference instrumental-variable estimate "
     "was null (+1.9 percentage points, 95% CI -14.9 to +18.7), and the early group was "
     "less severely affected at baseline, so residual confounding would inflate rather than "
     "mask the observed association. The severity gradient is defined by the pre-specified "
     "inverse-probability-weighted strata, and an exploratory causal forest did not "
     "reproduce it; we report that disagreement rather than conceal it. All analysis code "
     "is supplied as a supplementary code archive, and the primary estimates were re-run "
     "independently before submission.", space_after=8)

para("We are aware that the clinical databases and the transcriptomic cohorts are distinct "
     "populations, and that no wet-lab validation is included. We state both limitations "
     "plainly and convert them into a specific, falsifiable next step: prospective profiling "
     "of monocyte HLA-DR expression across prophylaxis timing. We believe this candour, "
     "together with the breadth of the multi-omic layers and the methodological strength of "
     "the emulated trial, makes the manuscript a useful contribution to the immunology of "
     "acute brain injury rather than another descriptive bioinformatics report. Should the "
     "editorial team consider the Multiple Sclerosis and Neuroimmunology section a better "
     "fit, we would welcome that reassignment.", space_after=8)

para("This work has not been published previously and is not under consideration elsewhere. "
     "Both authors have approved the submission and declare no competing interests. All "
     "databases were accessed under their respective data use agreements and contain no "
     "identifiable information.", space_after=12)

para("Yours sincerely,", space_after=14)
para("Jian Yin, MD", space_after=0)
para("Corresponding author, on behalf of both authors", space_after=0)
para("ORCID 0000-0002-5167-9821", space_after=0)

doc.save(OUT)
print("SAVED:", OUT)
print("paragraphs:", len(doc.paragraphs))
