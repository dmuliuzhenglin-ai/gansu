# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 62_scrna_gse166638.R
# Single-cell analysis of blood (BLD) and hematoma effluent (HEF) across donors
# (GSE166638). dge count tables, QC, harmony by donor, clustering, marker
# annotation, BLD vs HEF composition, and hub-gene localisation.
suppressPackageStartupMessages({
  library(Seurat); library(harmony); library(dplyr)
})
options(future.globals.maxSize = 10 * 1024^3)
root <- PATHS$project
exdir <- file.path(root, "00_data/GSE166638/extracted")
resdir <- file.path(root, "02_results")

files <- list.files(exdir, pattern = "dge.txt.gz$")
objs <- list()
for (fl in files) {
  base <- sub("_dge.txt.gz$", "", fl)
  d <- read.delim(gzfile(file.path(exdir, fl)), check.names = FALSE)
  cnt <- as.matrix(d[, -1]); rownames(cnt) <- d[[1]]
  storage.mode(cnt) <- "integer"
  s <- CreateSeuratObject(cnt, project = base, min.cells = 3, min.features = 200)
  p <- strsplit(base, "_")[[1]]
  s$day <- p[2]; s$donor <- p[3]; s$source <- p[4]
  s$platform <- if (length(p) >= 6) p[6] else p[length(p)]
  objs[[base]] <- s
}
sobj <- merge(objs[[1]], objs[-1])
sobj <- JoinLayers(sobj)
sobj[["percent_mt"]] <- PercentageFeatureSet(sobj, pattern = "^MT-")
cat("cells before QC:", ncol(sobj), "\n")
sobj <- subset(sobj, subset = nFeature_RNA > 200 & nFeature_RNA < 8000 &
                 percent_mt < 20)
cat("cells after QC:", ncol(sobj), "\n")

sobj <- NormalizeData(sobj, verbose = FALSE)
sobj <- FindVariableFeatures(sobj, nfeatures = 2000, verbose = FALSE)
sobj <- ScaleData(sobj, verbose = FALSE)
sobj <- RunPCA(sobj, npcs = 30, verbose = FALSE)
sobj <- RunHarmony(sobj, group.by.vars = "donor", verbose = FALSE)
sobj <- RunUMAP(sobj, reduction = "harmony", dims = 1:20, verbose = FALSE)
sobj <- FindNeighbors(sobj, reduction = "harmony", dims = 1:20, verbose = FALSE)
sobj <- FindClusters(sobj, resolution = 0.6, verbose = FALSE)

# cluster-level marker annotation
expr_data <- GetAssayData(sobj, layer = "data")
clusters <- sobj$seurat_clusters; clv <- levels(clusters)
posfrac <- function(genes) {
  genes <- intersect(genes, rownames(expr_data))
  sapply(clv, function(cl) {
    cells <- which(clusters == cl)
    mean(colSums(expr_data[genes, cells, drop = FALSE] > 0) > 0)
  })
}
pf <- as.data.frame(list(
  astro = posfrac(c("GFAP","AQP4","ALDH1L1")),
  endo  = posfrac(c("PECAM1","CLDN5","VWF")),
  mic   = posfrac(c("P2RY12","TMEM119","CX3CR1")),
  neut  = posfrac(c("FCGR3B","CSF3R","S100A12","CXCR2")),
  macc  = posfrac(c("CD14","C1QA","C1QB","CD68","APOE")),
  tcell = posfrac(c("CD3D","CD3E","TRAC")),
  bcell = posfrac(c("CD79A","CD79B","MS4A1")),
  nk    = posfrac(c("GNLY","NKG7","KLRD1"))))
rownames(pf) <- clv; print(round(pf, 2))
annot <- apply(pf, 1, function(r) {
  if (r["astro"] >= .5) "astrocytes"
  else if (r["endo"] >= .5) "endothelial"
  else if (r["mic"] >= .4) "microglia"
  else if (r["neut"] >= .5) "neutrophils"
  else if (r["macc"] >= .5) "monocytes_macrophages"
  else if (r["nk"] >= .6 && r["tcell"] < .5) "NK_cells"
  else if (r["tcell"] >= .5) "T_cells"
  else if (r["bcell"] >= .5) "B_cells"
  else "unassigned"
})
sobj$cell_type <- unname(annot[as.character(clusters)])
cat("\ncell type counts:\n"); print(table(sobj$cell_type))

Idents(sobj) <- "cell_type"
mk <- FindAllMarkers(sobj, only.pos = TRUE, min.pct = .25,
                     logfc.threshold = .5, verbose = FALSE)
write.csv(mk, file.path(resdir, "GSE166638_celltype_markers.csv"),
          row.names = FALSE)

# BLD vs HEF composition
comp <- as.data.frame(prop.table(table(sobj$source, sobj$cell_type), margin = 1))
write.csv(comp, file.path(resdir, "GSE166638_composition_source.csv"),
          row.names = FALSE)

# hub localisation (reuse consensus + module-1 hubs)
lists <- readRDS(file.path(resdir, "consensus_gene_lists.rds"))
w <- readRDS(file.path(resdir, "GSE335924_WGCNA.rds"))
hub <- unique(c(head(lists$cs_up, 60), head(lists$cs_dn, 30),
                head(w$gene_tab$gene[w$gene_tab$module == 1], 20)))
hub <- intersect(hub, rownames(sobj))
pct <- sapply(unique(sobj$cell_type), function(ct) {
  cells <- which(sobj$cell_type == ct)
  rowMeans(expr_data[hub, cells, drop = FALSE] > 0)
})
write.csv(as.data.frame(pct), file.path(resdir,
          "GSE166638_hub_pct_expressing.csv"))
saveRDS(sobj, file.path(resdir, "GSE166638_seurat.rds"))
cat("\nGSE166638 single-cell done\n")
