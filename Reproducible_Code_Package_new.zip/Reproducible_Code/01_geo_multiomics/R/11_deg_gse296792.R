# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 11_deg_gse296792.R
# GSE296792 (whole blood, normalized counts): repeated measures over time
# 27 patients, time points baseline / 72h / 7day (unbalanced)
# limma on log2(count+1), patient as blocking variable (duplicateCorrelation)
suppressPackageStartupMessages({ library(limma); library(dplyr) })

root <- PATHS$project
resdir <- file.path(root, "02_results")

mp <- gzfile(file.path(root,
  "00_data/GSE296792/GSE296792_Normalized_mRNA_counts_v1.csv.gz"))
raw <- read.csv(mp, check.names = FALSE, row.names = 1)

# normalize labels
norm_tp <- function(x) {
  x <- gsub("bas$", "base", x); x <- gsub("7da$", "7day", x); x
}
sids <- colnames(raw)
pat <- sub("_(base|bas|72h|7day|7da)$", "", sids)
tp  <- factor(norm_tp(sub("^.*_", "", sids)),
              levels = c("base", "72h", "7day"))
cat("patients:", length(unique(pat)), "| samples:", length(sids), "\n")
print(table(tp))

# log2 transform normalized counts
logx <- log2(as.matrix(raw) + 1)

# ---- paired analysis with patient block ----
design <- model.matrix(~0 + tp)
colnames(design) <- c("base", "t72h", "t7day")   # legal R names
corfit <- duplicateCorrelation(logx, design, block = pat)
cat("consensus correlation:", round(corfit$consensus.correlation, 4), "\n")
fit <- lmFit(logx, design, block = pat,
             correlation = corfit$consensus.correlation)
contr <- makeContrasts(
  h72_base = t72h - base,
  d7_base  = t7day - base,
  d7_h72   = t7day - t72h,
  levels = design)
fit2 <- contrasts.fit(fit, contr)
fit2 <- eBayes(fit2, trend = TRUE, robust = TRUE)

out <- list()
for (cx in colnames(contr)) {
  tt <- topTable(fit2, coef = cx, number = Inf, sort.by = "P")
  tt$gene <- rownames(tt)
  tt$contrast <- cx
  tt$regulation <- "NS"
  tt$regulation[tt$adj.P.Val < 0.05 & tt$logFC >= 1]  <- "up"
  tt$regulation[tt$adj.P.Val < 0.05 & tt$logFC <= -1] <- "down"
  out[[cx]] <- tt
  cat("\n", cx, ":\n", sep = ""); print(table(tt$regulation))
}
all <- do.call(rbind, lapply(out, function(x)
  x[, c("gene", "contrast", "logFC", "AveExpr", "t", "P.Value",
        "adj.P.Val", "regulation")]))
rownames(all) <- NULL
write.csv(all, file.path(resdir, "GSE296792_DEG_all.csv"), row.names = FALSE)
saveRDS(list(fit = fit2, degs = out), file.path(resdir, "GSE296792_limma.rds"))

cat("\ntop 10 at 72h vs base:\n")
print(head(out$h72_base, 10)[, c("gene", "logFC", "adj.P.Val", "regulation")],
      row.names = FALSE)
cat("\nGSE296792 DEG done\n")
