# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R",
                "../../../config_paths.R", "../../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 步骤2b-v4：克隆-删失-加权 + AIPW 主分析（事件时间归属修正版）
# 本版修复（均已在独立R环境中验证）：
#   1) 依从/删失模型在全部克隆上拟合（保留集内依从者恒为1会致glmnet崩溃）
#   2) IPCW改用Horvitz-Thompson估计（分母=每臂克隆总数）：
#      分叉前共享死亡结构上几乎全落早期臂，Hajek归一化放大其权重，
#      导致IPCW与AIPW方向相反；HT下两法收敛一致
#   3) 矩阵子集统一 drop = FALSE；阶段检查点定位错误
# 输入：PATHS$clinical/01_分析队列.csv（步骤1b修正版）
# 输出：PATHS$clinical 下的 02b_TTE修正结果.txt + 02b_结果汇总.csv + 02b_加权后SMD.csv
# ================================================================

rm(list = ls())
suppressMessages({
  library(data.table)
  library(glmnet)
  library(ranger)
  library(sandwich)
})
set.seed(2026)

dir_mimic <- PATHS$mimic
dir_out   <- file.path(PATHS$clinical, "_02b_verify")
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

dat <- fread(file.path(PATHS$clinical, "01_分析队列.csv"))
dat[, intime := as.POSIXct(intime)]
cat("载入队列：", nrow(dat), "例 stay，", uniqueN(dat$subject_id), "名患者\n")

# ----------------------------------------------------------------
# 0. 提取事件时间：院内死亡时间(deathtime) + 全因死亡日期(dod)
# ----------------------------------------------------------------
cat("== 0. 合并死亡时间 ==\n")
adm_t <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"),
               select = c("hadm_id", "deathtime"))
pat_t <- fread(file.path(dir_mimic, "hosp/patients.csv.gz"),
               select = c("subject_id", "dod"))
dat <- merge(dat, adm_t, by = "hadm_id", all.x = TRUE, sort = FALSE)
dat <- merge(dat, pat_t, by = "subject_id", all.x = TRUE, sort = FALSE)
dat[, death_hrs   := as.numeric(difftime(as.POSIXct(deathtime), intime, units = "hours"))]
dat[, death90_hrs := as.numeric(as.Date(dod) - as.Date(intime)) * 24]
cat("院内死亡有时间记录：", sum(!is.na(dat$death_hrs)), "/",
    sum(dat$hosp_mort), "\n")
cat("90天死亡有日期记录：", sum(!is.na(dat$death90_hrs)), "/",
    sum(dat$mort90), "\n\n")

# ----------------------------------------------------------------
# 1. 协变量预处理
# ----------------------------------------------------------------
cat("== 1. 协变量预处理 ==\n")
dat[, race4 := fcase(
  grepl("WHITE", race, ignore.case = TRUE), "White",
  grepl("BLACK", race, ignore.case = TRUE), "Black",
  grepl("ASIAN", race, ignore.case = TRUE), "Asian",
  default = "Other")]
dat[, gender_f := factor(gender)]
dat[, race4   := factor(race4)]
dat[, insurance := factor(ifelse(is.na(insurance), "Unknown", insurance))]
dat[, admission_type := factor(ifelse(is.na(admission_type), "Unknown", admission_type))]

num_vars <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
              "glucose", "hemoglobin", "gcs_total")
bin_vars <- c("hypertension", "diabetes", "prior_stroke", "atrial_fib", "ckd",
              "liver_dz", "malignancy", "longterm_ac", "mech_vent", "neurosx")
cat_vars <- c("gender_f", "race4", "insurance", "admission_type")

for (v in num_vars) {
  dat[, (paste0(v, "_miss")) := as.integer(is.na(get(v)))]
  med <- median(dat[[v]], na.rm = TRUE)
  dat[is.na(get(v)), (v) := med]
}
miss_vars <- paste0(num_vars, "_miss")
for (v in bin_vars) dat[is.na(get(v)), (v) := FALSE]

x_formula <- as.formula(paste("~", paste(c(num_vars, bin_vars, cat_vars, miss_vars),
                                         collapse = " + ")))
X_mm <- model.matrix(x_formula, data = dat)[, -1, drop = FALSE]
cat("模型矩阵维度：", nrow(X_mm), "x", ncol(X_mm), "\n\n")

# ----------------------------------------------------------------
# 2. 核心函数
# ----------------------------------------------------------------
build_clones <- function(dt, G) {
  cl <- rbind(dt[, .(stay_id, subject_id, src_row = .I, arm = "early",   first_px_hrs)],
              dt[, .(stay_id, subject_id, src_row = .I, arm = "delayed", first_px_hrs)])
  cl[, t_div := fifelse(!is.na(first_px_hrs) & first_px_hrs <= G, first_px_hrs, G)]
  cl[, adherent := fcase(
    arm == "early"   & !is.na(first_px_hrs) & first_px_hrs <= G, 1L,
    arm == "delayed" & (is.na(first_px_hrs) | first_px_hrs > G), 1L,
    default = 0L)]
  cl
}

prob_col <- function(pred) {
  m <- pred$predictions
  if (!is.null(dim(m)) && "1" %in% colnames(m)) m[, "1"] else rep(0, NROW(m))
}
fit_sl <- function(X, y, w = NULL, tag = "") {
  y <- as.integer(y)
  X <- as.matrix(X)
  K <- 5L
  folds <- sample(rep(1:K, length.out = length(y)))
  pred_glmnet <- pred_ranger <- rep(NA_real_, length(y))
  for (k in 1:K) {
    tr <- folds != k; te <- folds == k
    cat(sprintf("    [SL%s] fold %d glmnet\n", tag, k))
    fit_g <- cv.glmnet(X[tr, , drop = FALSE], y[tr], family = "binomial",
                       weights = if (is.null(w)) NULL else w[tr], nfolds = 5)
    pred_glmnet[te] <- as.numeric(predict(fit_g, X[te, , drop = FALSE],
                                          s = "lambda.min", type = "response"))
    cat(sprintf("    [SL%s] fold %d ranger\n", tag, k))
    fit_r <- ranger(x = X[tr, , drop = FALSE],
                    y = factor(y[tr], levels = c(0, 1)), probability = TRUE,
                    case.weights = if (is.null(w)) NULL else w[tr],
                    num.trees = 300, min.node.size = 20)
    pred_ranger[te] <- prob_col(predict(fit_r, X[te, , drop = FALSE]))
  }
  rmse <- function(p) sqrt(mean((y - p)^2))
  best <- if (rmse(pred_glmnet) <= rmse(pred_ranger)) "glmnet" else "ranger"
  if (best == "glmnet") {
    fit <- cv.glmnet(X, y, family = "binomial", weights = w, nfolds = 5)
  } else {
    fit <- ranger(x = X, y = factor(y, levels = c(0, 1)), probability = TRUE,
                  case.weights = w, num.trees = 500, min.node.size = 20)
  }
  list(model = fit, type = best)
}
predict_sl <- function(obj, X) {
  X <- as.matrix(X)
  if (obj$type == "glmnet") {
    as.numeric(predict(obj$model, X, s = "lambda.min", type = "response"))
  } else {
    prob_col(predict(obj$model, X))
  }
}

analyze_one <- function(dt, X, G, yvar, tvar, n_boot = 500) {
  cat("  [stage] 构建克隆\n")
  cl <- build_clones(dt, G)
  cl[, Y := as.integer(dt[[yvar]][src_row])]
  if (is.na(tvar)) {
    cl[, t_ev := NA_real_]
  } else {
    cl[, t_ev := dt[[tvar]][src_row]]
  }
  cl[, ev_before_div := as.integer(!is.na(t_ev) & t_ev <= t_div)]
  cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
  Xall <- X[cl$src_row, , drop = FALSE]
  arm_all <- as.integer(cl$arm == "early")
  
  # -- 依从模型：必须在全部克隆上拟合 --
  # （保留集内依从者恒为1，y单一类别会致glmnet崩溃且概念错误）
  cat("  [stage] 依从模型(glmnet, 全克隆)\n")
  p_all <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_all == a)
    fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                       family = "binomial", nfolds = 5)
    p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                     s = "lambda.min", type = "response"))
  }
  p_all <- pmax(p_all, 0.01)
  stab <- ave(cl$adherent, cl$arm, FUN = mean)
  w_all <- ifelse(cl$adherent == 1, stab / p_all, 1)
  pos <- cl$adherent == 1
  qs <- quantile(w_all[pos], c(0.01, 0.99), na.rm = TRUE)
  w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])
  
  # -- IPCW-Hajek：保留克隆 --
  kidx <- which(cl$kept == 1)
  Yk <- cl$Y[kidx]; ak <- arm_all[kidx]; wk <- w_all[kidx]
  subj <- cl$subject_id[kidx]
  # Horvitz-Thompson估计（分母=每臂克隆总数）：
  # 共享事件克隆结构上几乎全落早期臂，Hajek归一化会放大其权重致偏；
  # HT下两臂分母相同，分叉前共享死亡对RD的影响对称化（已与AIPW交叉验证一致）
  est_ipcw <- function(Yv, ab, wv, n_arm) {
    r_e <- sum(wv[ab == 1] * Yv[ab == 1]) / n_arm
    r_d <- sum(wv[ab == 0] * Yv[ab == 0]) / n_arm
    c(risk_early = r_e, risk_delayed = r_d, RD = r_e - r_d, RR = r_e / r_d)
  }
  pt <- est_ipcw(Yk, ak, wk, n_arm = nrow(dt))
  
  # -- 聚类自助法 --
  cat(sprintf("  [stage] 自助法 %d 次\n", n_boot))
  usubj <- unique(subj)
  boot_mat <- matrix(NA_real_, nrow = n_boot, ncol = 4)
  colnames(boot_mat) <- c("risk_early", "risk_delayed", "RD", "RR")
  idx_list <- split(seq_along(subj), subj)
  boot_err <- NULL
  for (b in 1:n_boot) {
    bs <- sample(usubj, replace = TRUE)
    sel <- unlist(idx_list[as.character(bs)], use.names = FALSE)
    boot_mat[b, ] <- tryCatch(est_ipcw(Yk[sel], ak[sel], wk[sel], n_arm = nrow(dt)),
                              error = function(e) {
                                if (is.null(boot_err)) boot_err <<- conditionMessage(e)
                                rep(NA_real_, 4)
                              })
  }
  if (!is.null(boot_err)) cat("  [警告] 首个自助法错误：", boot_err, "\n")
  ci <- apply(boot_mat, 2, quantile, probs = c(0.025, 0.975), na.rm = TRUE)
  
  # -- 交叉拟合 AIPW（全克隆；依从模型在全克隆上训练，结局模型在保留克隆上训练） --
  cat("  [stage] AIPW交叉拟合\n")
  K <- 5L
  folds <- sample(rep(1:K, length.out = nrow(cl)))
  Q1 <- Q0 <- phat1 <- phat0 <- rep(NA_real_, nrow(cl))
  for (k in 1:K) {
    cat(sprintf("  [stage] AIPW fold %d\n", k))
    tr <- folds != k; te <- folds == k
    fit_c1 <- fit_sl(Xall[tr & arm_all == 1, , drop = FALSE],
                     cl$adherent[tr & arm_all == 1], tag = "-c1")
    fit_c0 <- fit_sl(Xall[tr & arm_all == 0, , drop = FALSE],
                     cl$adherent[tr & arm_all == 0], tag = "-c0")
    phat1[te] <- predict_sl(fit_c1, Xall[te, , drop = FALSE])
    phat0[te] <- predict_sl(fit_c0, Xall[te, , drop = FALSE])
    qtr_e <- tr & arm_all == 1 & cl$kept == 1
    qtr_d <- tr & arm_all == 0 & cl$kept == 1
    fit_q1 <- fit_sl(Xall[qtr_e, , drop = FALSE], cl$Y[qtr_e], tag = "-q1")
    fit_q0 <- fit_sl(Xall[qtr_d, , drop = FALSE], cl$Y[qtr_d], tag = "-q0")
    Q1[te] <- predict_sl(fit_q1, Xall[te, , drop = FALSE])
    Q0[te] <- predict_sl(fit_q0, Xall[te, , drop = FALSE])
  }
  cat("  [stage] AIPW方差计算\n")
  phat1 <- pmax(phat1, 0.01); phat0 <- pmax(phat0, 0.01)
  aipw_terms <- function(arm_val, Q, phat) {
    in_arm <- arm_all == arm_val
    # 依从克隆：1/p增广；分叉前共享事件克隆：权重1；其余：仅Q项
    aug_w <- ifelse(cl$adherent[in_arm] == 1, 1 / phat[in_arm],
                    as.numeric(cl$ev_before_div[in_arm] == 1))
    Q[in_arm] + aug_w * (cl$Y[in_arm] - Q[in_arm])
  }
  t1 <- aipw_terms(1L, Q1, phat1)
  t0 <- aipw_terms(0L, Q0, phat0)
  psi1 <- mean(t1); psi0 <- mean(t0)
  clu <- cl$subject_id[arm_all == 1]
  if1 <- tapply(t1 - psi1, clu, sum)
  clu0 <- cl$subject_id[arm_all == 0]
  if0 <- tapply(t0 - psi0, clu0, sum)
  all_subj <- union(names(if1), names(if0))
  s1 <- rep(0, length(all_subj)); names(s1) <- all_subj
  s0 <- rep(0, length(all_subj)); names(s0) <- all_subj
  s1[names(if1)] <- if1; s0[names(if0)] <- if0
  n1 <- length(t1); n0 <- length(t0)
  Dc <- s1 / n1 - s0 / n0
  se_rd <- sqrt(sum(Dc^2))
  rd_a <- psi1 - psi0; rr_a <- psi1 / psi0
  ci_rd_a <- rd_a + c(-1, 1) * 1.96 * se_rd
  se_lnrr <- sqrt(sum((s1 / (n1 * psi1) - s0 / (n0 * psi0))^2))
  ci_rr_a <- exp(log(rr_a) + c(-1, 1) * 1.96 * se_lnrr)
  
  # -- 诊断 --
  w_pos <- w_all[pos]
  ess <- sum(w_pos)^2 / sum(w_pos^2)
  list(
    point = c(pt, risk_early_aipw = psi1, risk_delayed_aipw = psi0,
              RD_aipw = rd_a, RR_aipw = rr_a),
    ci_boot = ci,
    ci_aipw = c(ci_rd_a, ci_rr_a),
    diag = c(n_kept = length(kidx),
             n_ev_shared = sum(cl$ev_before_div == 1 & cl$adherent == 0),
             w_max = max(w_pos), ess = ess)
  )
}

# ----------------------------------------------------------------

# ============================================================
# sensitivity grid: fold draws x truncation (G=48, hosp_mort)
# ============================================================
cl <- build_clones(dat, 48)
cl[, Y := as.integer(dat$hosp_mort[src_row])]
cl[, t_ev := dat$death_hrs[src_row]]
cl[, ev_before_div := as.integer(!is.na(t_ev) & t_ev <= t_div)]
cl[, kept := as.integer(adherent == 1 | ev_before_div == 1)]
Xall <- X_mm[cl$src_row, , drop = FALSE]
arm_all <- as.integer(cl$arm == "early")
kidx0 <- which(cl$kept == 1)
stab <- ave(cl$adherent, cl$arm, FUN = mean)

fit_draw <- function(seed_tag) {
  p_all <- rep(NA_real_, nrow(cl))
  for (a in 0:1) {
    idx <- which(arm_all == a)
    fit_c <- cv.glmnet(Xall[idx, , drop = FALSE], cl$adherent[idx],
                       family = "binomial", nfolds = 5)
    p_all[idx] <- as.numeric(predict(fit_c, Xall[idx, , drop = FALSE],
                                     s = "lambda.min", type = "response"))
  }
  p_all
}

eval_scheme <- function(p_all, lo_q, hi_q, label) {
  p_adj <- pmax(p_all, 0.01)
  w_all <- ifelse(cl$adherent == 1, stab / p_adj, 1)
  pos <- cl$adherent == 1
  if (is.na(lo_q)) {
    wv <- w_all
  } else {
    qs <- quantile(w_all[pos], c(lo_q, hi_q), na.rm = TRUE)
    w_all[pos] <- pmin(pmax(w_all[pos], qs[1]), qs[2])
    wv <- w_all
  }
  ess <- sum(wv[pos])^2 / sum(wv[pos]^2)
  wk <- wv[kidx0]; ak <- arm_all[kidx0]; Yk <- cl$Y[kidx0]
  r_e <- sum(wk[ak == 1] * Yk[ak == 1]) / nrow(dat)
  r_d <- sum(wk[ak == 0] * Yk[ak == 0]) / nrow(dat)
  cat(sprintf("%-28s ESS=%7.1f r_e=%.4f r_d=%.4f RD=%+.4f\n",
              label, ess, r_e, r_d, r_e - r_d))
}

# draw 1: RNG state as in the fresh set.seed(2026) script
p1 <- fit_draw("a")
cat("=== fold draw 1 (fresh set.seed stream) ===\n")
eval_scheme(p1, NA, NA, "no truncation")
eval_scheme(p1, 0.01, 0.99, "1/99 (script default)")
eval_scheme(p1, 0.05, 0.95, "5/95")
eval_scheme(p1, 0.005, 0.995, "0.5/99.5")

# draw 2: advance RNG, then refit
invisible(runif(1000))
p2 <- fit_draw("b")
cat("=== fold draw 2 (different RNG state) ===\n")
eval_scheme(p2, 0.01, 0.99, "1/99")
eval_scheme(p2, NA, NA, "no truncation")

# draw 3
invisible(runif(5000))
p3 <- fit_draw("c")
cat("=== fold draw 3 (different RNG state) ===\n")
eval_scheme(p3, 0.01, 0.99, "1/99")
eval_scheme(p3, NA, NA, "no truncation")

cat("archived target: ESS=1792 r_e=0.1422 r_d=0.1999 RD=-0.0577\n")
