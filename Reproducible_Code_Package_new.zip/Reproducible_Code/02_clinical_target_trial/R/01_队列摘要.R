# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 步骤1b：修正补丁（在步骤1基础上运行）
# 修正：1) GCS提取  2) prior_stroke误标  3) neurosx低估
#       4) HR/SBP范围清洗  5) icu_hours缺失回填
# 输入：[clinical output directory]/01_分析队列.csv（步骤1产物）
# 输出：覆盖写回 01_分析队列.csv + 01b_修正摘要.txt
# ================================================================

rm(list = ls())
library(data.table)

dir_mimic <- PATHS$mimic
dir_out   <- PATHS$clinical
sink(file.path(dir_out, "01b_修正摘要.txt"), split = TRUE)
cat("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

cohort <- fread(file.path(dir_out, "01_分析队列.csv"))
cohort[, `:=`(intime = as.POSIXct(intime), outtime = as.POSIXct(outtime))]
cat("载入队列：", nrow(cohort), "例\n\n")

# ================================================================
# 1. GCS 重新提取
# ================================================================
cat("== 1. GCS itemid 探查 ==\n")
d_items <- fread(file.path(dir_mimic, "icu/d_items.csv.gz"))
gcs_all <- d_items[grepl("gcs|glasgow|eye opening|verbal response|motor response",
                         label, ignore.case = TRUE), .(itemid, label, linksto)]
cat("匹配到的GCS相关条目：\n")
print(gcs_all)

gcs_ids <- list(
  gcs_e = d_items[grepl("eye", label, ignore.case = TRUE) &
                    grepl("gcs|glasgow|opening", label, ignore.case = TRUE), itemid],
  gcs_v = d_items[grepl("verbal", label, ignore.case = TRUE), itemid],
  gcs_m = d_items[grepl("motor", label, ignore.case = TRUE) &
                    grepl("gcs|glasgow|response", label, ignore.case = TRUE), itemid]
)
cat("各分量itemid：", sapply(gcs_ids, length), "\n\n")

read_ce_chunks <- function(path, keep_items, keep_stays, chunk_size = 5e6) {
  con <- gzfile(path, open = "rt")
  on.exit(close(con))
  header    <- strsplit(readLines(con, n = 1), ",", fixed = TRUE)[[1]]
  keep_cols <- c("stay_id", "itemid", "charttime", "value", "valuenum")
  keep_idx  <- match(keep_cols, header)
  res <- list()
  k   <- 0L
  repeat {
    lines <- readLines(con, n = chunk_size)
    if (length(lines) == 0L) break
    dt <- fread(text = paste(lines, collapse = "\n"), header = FALSE,
                select = keep_idx, fill = TRUE)
    setnames(dt, keep_cols)
    dt[, `:=`(stay_id = as.integer(stay_id), itemid = as.integer(itemid))]
    dt <- dt[itemid %in% keep_items & stay_id %in% keep_stays]
    if (nrow(dt) > 0) {
      k <- k + 1L
      res[[k]] <- dt
    }
    cat(sprintf("\r已扫描约 %.0f 百万行，命中 %d 行...",
                k * chunk_size / 1e6, sum(vapply(res, nrow, integer(1)))))
  }
  cat("\n")
  rbindlist(res)
}

gcs_items_all <- unique(unlist(gcs_ids))
if (length(gcs_items_all) > 0) {
  cat("chartevents分块重扫（仅GCS条目）...\n")
  ce <- read_ce_chunks(file.path(dir_mimic, "icu/chartevents.csv.gz"),
                       keep_items = gcs_items_all,
                       keep_stays = cohort$stay_id)
  ce <- merge(ce, cohort[, .(stay_id, intime)], by = "stay_id")
  ce[, charttime := as.POSIXct(charttime)]
  ce[, hrs := as.numeric(difftime(charttime, intime, units = "hours"))]
  ce24 <- ce[hrs >= 0 & hrs <= 24]
  
  parse_gcs <- function(x) suppressWarnings(as.numeric(sub("^([0-9]+).*", "\\1", x)))
  # 删除旧的GCS列
  cohort[, (intersect(c("gcs_e", "gcs_v", "gcs_m", "gcs_total"), names(cohort))) := NULL]
  for (nm in names(gcs_ids)) {
    sub <- ce24[itemid %in% gcs_ids[[nm]]]
    sub[, gcs_num := parse_gcs(value)]
    # 文本解析失败时尝试valuenum
    sub[is.na(gcs_num) & !is.na(valuenum), gcs_num := valuenum]
    agg <- sub[!is.na(gcs_num), .(v = min(gcs_num, na.rm = TRUE)), by = stay_id]
    cohort <- merge(cohort, setNames(agg, c("stay_id", nm)), by = "stay_id", all.x = TRUE)
  }
  cohort[, gcs_total := rowSums(.SD), .SDcols = c("gcs_e", "gcs_v", "gcs_m")]
  cohort[is.na(gcs_e) | is.na(gcs_v) | is.na(gcs_m), gcs_total := NA]
}
cat("GCS覆盖率：e ",
    sprintf("%.0f%%", 100 * mean(!is.na(cohort$gcs_e))),
    " / v ", sprintf("%.0f%%", 100 * mean(!is.na(cohort$gcs_v))),
    " / m ", sprintf("%.0f%%", 100 * mean(!is.na(cohort$gcs_m))),
    " / total ", sprintf("%.0f%%", 100 * mean(!is.na(cohort$gcs_total))), "\n\n", sep = "")

# ================================================================
# 2. prior_stroke 修正：既往住院卒中 + 病史编码（不含本次ICH）
# ================================================================
cat("== 2. prior_stroke 修正 ==\n")
adm  <- fread(file.path(dir_mimic, "hosp/admissions.csv.gz"))
diag <- fread(file.path(dir_mimic, "hosp/diagnoses_icd.csv.gz"))
diag[, code_clean := gsub("\\.", "", icd_code)]

index_adm <- merge(cohort[, .(subject_id, hadm_id)],
                   adm[, .(hadm_id, admittime)], by = "hadm_id")
setnames(index_adm, "admittime", "index_admittime")

# (a) 病史编码（任何住院出现即算既往史）
hist_subj <- unique(diag[(icd_version == 9  & grepl("^438|^V1254", code_clean)) |
                           (icd_version == 10 & grepl("^I69|^Z8673", code_clean)),
                         subject_id])

# (b) 索引住院之前的卒中诊断（430-434, 436 / I60-I64）
diag_adm <- merge(diag, adm[, .(hadm_id, admittime)], by = "hadm_id")
prior_dx <- merge(diag_adm, index_adm[, .(subject_id, index_admittime)],
                  by = "subject_id")
prior_dx <- prior_dx[as.POSIXct(admittime) < as.POSIXct(index_admittime)]
prior_subj <- unique(prior_dx[(icd_version == 9  & grepl("^43[0-46]", code_clean)) |
                                (icd_version == 10 & grepl("^I6[0-4]", code_clean)),
                              subject_id])

stroke_subj <- union(hist_subj, prior_subj)
cohort[, prior_stroke := subject_id %in% stroke_subj]
cat("修正后 prior_stroke 比例：",
    sprintf("%.1f%%", 100 * mean(cohort$prior_stroke)), "\n\n")

# ================================================================
# 3. neurosx 修正：放宽ICD-10-PCS前缀
# ================================================================
cat("== 3. neurosx 修正 ==\n")
proc <- fread(file.path(dir_mimic, "hosp/procedures_icd.csv.gz"))
proc[, code_clean := gsub("\\.", "", icd_code)]
nsx_ids <- unique(proc[hadm_id %in% cohort$hadm_id &
                         ((icd_version == 9  & grepl("^022[12]|^012[45]|^013[19]", code_clean)) |
                            (icd_version == 10 & grepl("^009|^00B0|^0N[BP]0", code_clean))),
                       hadm_id])
cohort[, neurosx := hadm_id %in% nsx_ids]
cat("修正后 neurosx 比例：", sprintf("%.1f%%", 100 * mean(cohort$neurosx)),
    "（正式稿前请人工复核ICD-10-PCS映射）\n\n")

# ================================================================
# 4. HR/SBP 生理范围清洗
# ================================================================
cat("== 4. 范围清洗 ==\n")
n_hr  <- sum(!is.na(cohort$hr)  & (cohort$hr  < 30 | cohort$hr  > 220))
n_sbp <- sum(!is.na(cohort$sbp) & (cohort$sbp < 40 | cohort$sbp > 280))
cohort[!between(hr, 30, 220), hr := NA]
cohort[!between(sbp, 40, 280), sbp := NA]
cat("HR 超范围置缺失：", n_hr, "例；SBP 超范围置缺失：", n_sbp, "例\n\n")

# ================================================================
# 5. icu_hours 缺失回填（icustays.los 单位为天）
# ================================================================
stays <- fread(file.path(dir_mimic, "icu/icustays.csv.gz"),
               select = c("stay_id", "los"))
cohort <- merge(cohort, stays, by = "stay_id", all.x = TRUE)
n_fill <- sum(is.na(cohort$icu_hours) & !is.na(cohort$los))
cohort[is.na(icu_hours) & !is.na(los), icu_hours := los * 24]
cohort[, los := NULL]
cohort[, icu_lt_24h := icu_hours < 24]
cat("icu_hours 回填：", n_fill, "例\n\n")

# ================================================================
# 6. 更新基线表并保存
# ================================================================
cat("== 6. 修正后基线特征 ==\n")
covars_num <- c("anchor_age", "sbp", "hr", "platelet", "inr", "creatinine",
                "glucose", "hemoglobin", "gcs_total", "icu_hours")
covars_cat <- c("gender", "hypertension", "diabetes", "prior_stroke", "atrial_fib",
                "ckd", "liver_dz", "malignancy", "longterm_ac", "mech_vent",
                "neurosx", "icu_lt_24h")

cat("-- 连续变量：均值(SD) --\n")
print(cohort[, lapply(.SD, function(x)
  sprintf("%.1f (%.1f)", mean(x, na.rm = TRUE), sd(x, na.rm = TRUE))),
  by = exposure_48h, .SDcols = covars_num])

cat("\n-- 分类变量：n(%) --\n")
print(cohort[, lapply(.SD, function(x)
  sprintf("%d (%.1f%%)", sum(x == TRUE | x == "F", na.rm = TRUE),
          100 * mean(x == TRUE | x == "F", na.rm = TRUE))),
  by = exposure_48h, .SDcols = covars_cat])

cat("\n缺失率（总体）：\n")
print(cohort[, lapply(.SD, function(x) sprintf("%.1f%%", 100 * mean(is.na(x)))),
             .SDcols = covars_num])

fwrite(cohort, file.path(dir_out, "01_分析队列.csv"))
cat("\n已覆盖保存：", file.path(dir_out, "01_分析队列.csv"), "\n")
sink()
cat("运行完毕，请查看 [clinical output directory]/01b_修正摘要.txt/n")