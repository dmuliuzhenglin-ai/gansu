# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 89_fig6_concept.R
# Figure 6. Integrated mechanistic concept map linking the clinical target
# trial effect to the systemic and cerebral immune response, molecular hubs,
# and the epigenetic/miRNA regulatory layer.
source(file.path(PATHS$project, "01_code/80_fig_theme.R"))
suppressPackageStartupMessages(library(ggforce))

# ---- node definitions (x, y centre; w, h half-extents) -------------------
N <- data.frame(rbind(
  c("ich", 50, 93, 26, 4.5, "Intracerebral hemorrhage", "#2C3E50", "white"),
  c("n_sys", 14, 73, 13, 5, "Neutrophils up", "#E67E22", "white"),
  c("m_sys", 36, 73, 13, 5, "Monocytes up", "#C0392B", "white"),
  c("supp", 25, 60.5, 20, 5.5,
    "CD4 / CD8 / B down\nMHC-II (HLA-DRA, CD74) down", "#2471A3", "white"),
  c("n_cer", 64, 73, 14, 5, "Neutrophil infiltration", "#E67E22", "white"),
  c("m_cer", 86, 73, 14, 5, "Monocyte / macrophage", "#C0392B", "white"),
  c("mic", 75, 60.5, 14, 5.5, "Microglia activation", "#8E44AD", "white"),
  c("h1", 14, 45, 14, 6, "IL1R2 . FCGR3B\nCXCL8 . KCNJ15", "#922B21", "white"),
  c("h2", 38, 45, 14, 6, "ACSL1 . ARG1\nANXA3 . ALPL", "#922B21", "white"),
  c("h3", 62, 45, 14, 6, "ALOX5AP\nFCER1G", "#922B21", "white"),
  c("h4", 86, 45, 14, 6, "CD74 . HLA-DRA\nADM . UPP1", "#922B21", "white"),
  c("meth", 30, 27, 21, 5.5,
    "Hypomethylation\nRNASE3 . VNN3 -> expression up", "#117A65", "white"),
  c("mir", 70, 27, 21, 5.5,
    "miRNA network\nlet-7 . miR-21 . miR-30", "#7B241C", "white"),
  c("clin", 50, 9, 40, 6,
    "Early VTE prophylaxis -> lower in-hospital mortality\n(three-database target trial)",
    "#2C3E50", "white")
), stringsAsFactors = FALSE)
colnames(N) <- c("id", "x", "y", "w", "h", "label", "fill", "tcol")
for (k in c("x", "y", "w", "h")) N[[k]] <- as.numeric(N[[k]])
N$xmin <- N$x - N$w; N$xmax <- N$x + N$w
N$ymin <- N$y - N$h; N$ymax <- N$y + N$h

# ---- compartment background panels ----------------------------------------
panels <- data.frame(xmin = c(2, 52), xmax = c(48, 98),
                     ymin = 53, ymax = 82,
                     name = c("Systemic circulation",
                              "Cerebral perilesional tissue"))

# ---- edges (from node id -> node id) --------------------------------------
edges <- data.frame(rbind(
  c("ich", "n_sys"), c("ich", "m_sys"), c("ich", "n_cer"), c("ich", "m_cer"),
  c("n_sys", "supp"), c("m_sys", "supp"),
  c("n_cer", "mic"), c("m_cer", "mic"),
  c("n_sys", "h1"), c("m_sys", "h2"),
  c("mic", "h3"), c("m_cer", "h3"), c("mic", "h4"),
  c("h1", "meth"), c("h2", "meth"), c("h3", "mir"), c("h4", "mir"),
  c("meth", "clin"), c("mir", "clin")
), stringsAsFactors = FALSE)
colnames(edges) <- c("from", "to")
pos <- N
rownames(pos) <- N$id
e <- data.frame(
  x = pos[edges$from, "x"], y = pos[edges$from, "ymin"],
  xend = pos[edges$to, "x"], yend = pos[edges$to, "ymax"])

fig6 <- ggplot() +
  geom_rect(data = panels, aes(xmin = xmin, xmax = xmax, ymin = ymin,
                               ymax = ymax), fill = "grey95",
            colour = "grey70", linewidth = .4, linetype = "dashed") +
  geom_text(data = panels, aes(x = xmin + 2, y = ymax - 2.2,
                               label = name), hjust = 0, vjust = 1,
            size = 3, fontface = "bold", colour = "grey35") +
  geom_segment(data = e, aes(x = x, y = y, xend = xend, yend = yend),
               linewidth = .35, colour = "grey45",
               arrow = grid::arrow(length = unit(1.6, "mm"), type = "closed"),
               linejoin = "mitre") +
  geom_rect(data = N, aes(xmin = xmin, xmax = xmax, ymin = ymin,
                         ymax = ymax),
            fill = N$fill, colour = "white", linewidth = .4) +
  geom_text(data = N, aes(x = x, y = y, label = label), size = 2.7,
            colour = N$tcol, lineheight = .95) +
  annotate("text", x = 50, y = 36, label = "Convergent molecular hubs",
           fontface = "bold", size = 3, colour = "grey30") +
  coord_fixed(xlim = c(-1.5, 101.5), ylim = c(2, 99), expand = FALSE) +
  labs(x = NULL, y = NULL) +
  theme_void(base_family = base_family)
save_pdf(fig6, "Figure6_concept_map", 180, 175)
