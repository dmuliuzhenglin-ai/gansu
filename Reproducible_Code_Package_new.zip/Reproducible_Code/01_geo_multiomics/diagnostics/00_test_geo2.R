# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 验证自定义 GEO 下载工具
source(file.path(PATHS$project, "01_code/00_geo_utils.R"))
dest <- file.path(PATHS$project, "00_data/GSE125512")
dir.create(dest, recursive = TRUE, showWarnings = FALSE)

t0 <- Sys.time()
es <- get_gse_eset("GSE125512", dest)
cat("elapsed:", round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1), "s\n")
cat("dim:", nrow(Biobase::exprs(es)), "x", ncol(Biobase::exprs(es)), "\n")
cat("platform:", Biobase::annotation(es), "\n")
pd <- Biobase::pData(es)
cat("pheno columns:\n")
print(colnames(pd))
cat("\nkey characteristics:\n")
if ("characteristics_ch1" %in% colnames(pd)) print(head(pd$characteristics_ch1, 3))
cat("\nexpression range:", range(Biobase::exprs(es)), "\n")
cat("OK\n")
