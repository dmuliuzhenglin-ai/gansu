# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 88_fig5_epigenetic.R
# Figure 5. Epigenetic and post-transcriptional layer:
# gene-level methylation changes, methylation-expression links, and the
# exploratory miRNA-mRNA regulatory network.
source(file.path(PATHS$project, "01_code/80_fig_theme.R"))
r <- file.path(PATHS$project, "02_results")
dmr <- read.csv(file.path(r, "GSE179759_DMR_gene_level.csv"),
                check.names = FALSE)
mel <- read.csv(file.path(r, "methyl_expression_link.csv"),
                check.names = FALSE)
net <- read.csv(file.path(r, "miRNA_mRNA_network.csv"),
                check.names = FALSE)

# ---- A: gene-level methylation (top 20 by FDR) ---------------------------
top20 <- head(dmr[order(dmr$min_FDR), ], 20)
top20$gene_symbol <- factor(top20$gene_symbol,
                            levels = rev(top20$gene_symbol))
pA <- ggplot(top20, aes(mean_delta_beta, gene_symbol, fill = regulation)) +
  geom_col(width = .72) + geom_vline(xintercept = 0, colour = "grey15",
                                     linewidth = .3) +
  scale_fill_manual(values = pal_meth, name = NULL,
                    labels = c(hyper = "Hypermethylated",
                               hypo = "Hypomethylated")) +
  labs(x = "Mean delta beta", y = NULL,
       title = "Differential methylation, gene level") +
  fig_theme + theme(legend.position = "bottom",
                    legend.direction = "horizontal")

# ---- B: methylation-expression links --------------------------------------
linked <- mel[!is.na(mel$link_type), c("gene_symbol", "mean_delta_beta",
                                       "min_FDR")]
deg <- read.csv(file.path(r, "cross_DEG_long.csv"), check.names = FALSE)
expr <- deg[deg$gene %in% linked$gene_symbol, ]
expr_agg <- stats::aggregate(logFC ~ gene, expr, mean)
colnames(expr_agg) <- c("gene_symbol", "mean_logFC")
b <- merge(linked, expr_agg, by = "gene_symbol", all.x = TRUE)
bL <- data.frame(gene = rep(b$gene_symbol, 2),
  layer = rep(c("DNA methylation (delta beta)", "mRNA expression (logFC)"),
              each = nrow(b)),
  value = c(b$mean_delta_beta, b$mean_logFC),
  direction = c(rep("hypo", nrow(b)), rep("up", nrow(b))))
pB <- ggplot(bL, aes(value, gene, fill = direction)) +
  geom_col(width = .6) + geom_vline(xintercept = 0, colour = "grey15",
                                    linewidth = .3) +
  scale_fill_manual(values = c(hypo = "#2471A3", up = "#C0392B"),
                    guide = "none") +
  scale_x_continuous(expand = expansion(mult = .12)) +
  facet_wrap(~ layer, scales = "free_x", ncol = 1) +
  geom_text(aes(label = round(value, 2)),
            hjust = ifelse(bL$value >= 0, -.2, 0),
            colour = ifelse(bL$value >= 0, "grey15", "white"),
            size = 2.6, nudge_x = ifelse(bL$value >= 0, 0, .004)) +
  labs(x = NULL, y = NULL, title = "Methylation-expression links") +
  fig_theme

# ---- C: miRNA family edge counts ------------------------------------------
fam <- dplyr::summarise(dplyr::group_by(net, family),
                        n_edges = dplyr::n(),
                        n_targets = dplyr::n_distinct(target))
fam <- head(fam[order(-fam$n_edges), ], 12)
fam$family <- factor(fam$family, levels = rev(fam$family))
pC <- ggplot(fam, aes(n_edges, family, fill = n_targets)) +
  geom_col(width = .7) +
  scale_fill_gradient(low = "#F5B7B1", high = "#7B241C",
                      name = "Distinct\ntargets") +
  scale_x_continuous(limits = c(0, max(fam$n_edges) * 1.18)) +
  geom_text(aes(label = n_edges), hjust = -.2, size = 2.6) +
  labs(x = "Predicted regulatory edges", y = "miRNA family",
       title = "miRNA families by target burden") +
  fig_theme

# ---- D: focused miRNA-mRNA network ----------------------------------------
top6 <- names(utils::head(sort(table(net$miRNA), decreasing = TRUE), 6))
sub <- do.call(rbind, lapply(top6, function(m) {
  utils::head(net[net$miRNA == m, ], 12)
}))
edges <- data.frame(from = sub$miRNA, to = sub$target)
g <- igraph::graph_from_data_frame(edges, directed = TRUE)
igraph::V(g)$kind <- ifelse(igraph::V(g)$name %in% top6, "miRNA", "Target gene")
igraph::V(g)$short <- ifelse(igraph::V(g)$kind == "miRNA",
                     sub("Hsa-", "", sub("\\*$", "", igraph::V(g)$name)), "")
set.seed(1)
pD <- ggraph::ggraph(g, layout = "kk") +
  ggraph::geom_edge_link(alpha = .15, edge_colour = "#7B241C") +
  ggraph::geom_node_point(aes(colour = kind, size = kind)) +
  ggraph::geom_node_text(aes(label = short), repel = TRUE, size = 2.4,
                         max.overlaps = 30) +
  scale_colour_manual(values = c(miRNA = "#922B21", `Target gene` = "#5D6D7E"),
                      name = NULL) +
  scale_size_manual(values = c(miRNA = 3.2, `Target gene` = 1.4), guide = "none") +
  ggraph::theme_graph(base_family = base_family) +
  labs(title = "Focused miRNA-mRNA network") +
  theme(plot.title = element_text(size = 9.5, face = "bold"),
        legend.position = "bottom")

pA <- pA + labs(tag = "A"); pB <- pB + labs(tag = "B")
pC <- pC + labs(tag = "C"); pD <- pD + labs(tag = "D")
fig5 <- patchwork::wrap_plots(pA, pB, pC, pD, ncol = 2) &
  theme(plot.tag = element_text(face = "bold", size = 10),
        plot.tag.position = c(.01, .99))
save_pdf(fig5, "Figure5_epigenetic_network", 180, 180)
