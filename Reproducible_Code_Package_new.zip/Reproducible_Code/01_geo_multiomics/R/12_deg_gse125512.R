# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 12_deg_gse125512.R
# GSE125512 (peripheral blood, n=22 = 11 paired patients, second vs first sample)
# The depositor supplied a complete DESeq2 result table; standardize its format.
suppressPackageStartupMessages(library(dplyr))
root <- PATHS$project
resdir <- file.path(root, "02_results")

p <- file.path(root,
  "00_data/GSE125512/GSE125512_SecondSample_vs_FirstSample.all.gene.result.xls.gz")
d <- read.csv(gzfile(p), sep = "\t", check.names = FALSE,
              stringsAsFactors = FALSE)
cat("rows:", nrow(d), "\n"); cat("cols:\n"); print(names(d)[1:10])

# keep DESeq2 statistics columns only (drop per-sample expression columns)
stat <- d[, c("geneid", "symbol", "name", "baseMean", "log2FoldChange",
              "pval", "padj")]
names(stat) <- c("entrez", "gene", "name", "baseMean", "logFC",
                 "PValue", "FDR")
stat$contrast <- "second_first"
stat$regulation <- "NS"
stat$regulation[!is.na(stat$FDR) & stat$FDR < 0.05 & stat$logFC >= 1]  <- "up"
stat$regulation[!is.na(stat$FDR) & stat$FDR < 0.05 & stat$logFC <= -1] <- "down"
cat("\nDEG counts (FDR<0.05, |logFC|>=1):\n"); print(table(stat$regulation))

# FDR-only count (paired longitudinal changes are often small in magnitude)
n_fdr <- sum(!is.na(stat$FDR) & stat$FDR < 0.05)
cat("genes with FDR<0.05 regardless of fold change:", n_fdr, "\n")

write.csv(stat[, c("gene", "entrez", "contrast", "logFC", "baseMean",
                   "PValue", "FDR", "regulation")],
          file.path(resdir, "GSE125512_DEG_all.csv"), row.names = FALSE)
cat("\ntop 15 by FDR:\n")
print(head(stat[order(stat$FDR), c("gene", "logFC", "FDR", "regulation")], 15),
      row.names = FALSE)
cat("\nGSE125512 standardized done\n")
