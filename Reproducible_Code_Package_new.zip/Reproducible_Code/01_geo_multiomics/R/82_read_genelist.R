# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 用 R 正确读取 GeneList
f <- file.path(PATHS$project, "00_data/GSE43618/GeneList.txt.gz")
con <- gzfile(f); lines <- readLines(con); close(con)
cat("lines:", length(lines), "\n"); print(head(lines, 15))
