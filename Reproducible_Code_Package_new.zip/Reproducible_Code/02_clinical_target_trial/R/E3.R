# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E3 - 医院偏好工具变量分析 (eICU 主分析; NWICU 备用)
# 工具变量 Z: 同医院"其他" ICH 患者的早期预防率 (leave-one-out)
# 暴露 X: 本院 ≤48h 启动预防 (0/1); 结局 Y: 院内死亡
# 方法: 2SLS (一阶段 X~Z+协变量, 二阶段 Y~Xhat+协变量), 医院层面聚类 SE
#       报告: 一阶段 F 统计量, Wald 比, 2SLS RD
# 用法: source(file.path(PATHS$clinical, "eICU步骤3-IV.R"), encoding="UTF-8")
# ============================================================

library(data.table)
options(error = NULL); set.seed(2026)
dir_out <- PATHS$clinical

xvars <- c("age","female","gcs","mech_vent","neurosx","sbp","hr",
           "platelet","hemoglobin","creatinine","glucose",
           "hypertension","diabetes","ckd","heart_failure","malignancy","liver",
           "prior_vte","prior_stroke")

prep <- function(path) {
  dt <- fread(path)
  if ("gender" %in% names(dt)) dt[, female := as.integer(gender == "Female")]
  for (v in xvars) if (v %in% names(dt) && any(is.na(dt[[v]])))
    dt[is.na(get(v)), (v) := median(dt[[v]], na.rm = TRUE)]
  dt[, early48 := as.integer(!is.na(first_px_hrs) & first_px_hrs <= 48)]
  dt
}

iv_one <- function(dt, label, min_hosp_n = 5) {
  cat("\n==========", label, "==========\n")
  use <- intersect(xvars, names(dt))
  # leave-one-out 医院预防率
  dt[, hosp_n := .N, by = hospitalid]
  dt[, hosp_early := sum(early48), by = hospitalid]
  dt[, Z := (hosp_early - early48) / (hosp_n - 1)]
  d <- dt[hosp_n >= min_hosp_n & !is.na(Z)]
  cat("分析样本:", nrow(d), " 医院数:", uniqueN(d$hospitalid),
      " 早期预防:", sum(d$early48), sprintf("(%.1f%%)", 100*mean(d$early48)), "\n")
  cat("工具变量 Z 分布: 均值", round(mean(d$Z),3), " 范围", round(min(d$Z),3), "-", round(max(d$Z),3), "\n")
  
  # 一阶段
  f1 <- reformulate(c("Z", use), response = "early48")
  m1 <- lm(f1, data = d)
  fstat <- summary(m1)$fstatistic
  zt <- coef(summary(m1))["Z", "t value"]
  cat(sprintf("一阶段: Z 系数 %+.3f (t=%.1f), 偏 F ≈ %.1f  %s\n",
              coef(m1)["Z"], zt, zt^2, ifelse(abs(zt) > 3.2, "(>10, 工具强度合格)", "(偏弱, 谨慎解读)")))
  # 相关性/排他性粗查: Z 与协变量平衡
  cat("Z 高低三分位组的协变量平衡(均值差, 应接近0):\n")
  d[, Z_hi := as.integer(Z > median(Z))]
  bal <- sapply(use, function(v) abs(mean(d[Z_hi==1][[v]]) - mean(d[Z_hi==0][[v]])) /
                  max(sd(d[[v]]), 1e-9))
  print(round(sort(bal, decreasing = TRUE)[1:6], 3))
  d[, Z_hi := NULL]
  
  # 简约式 + Wald 比
  rf <- lm(reformulate(c("Z", use), response = "hosp_mort"), data = d)
  wald <- coef(rf)["Z"] / coef(m1)["Z"]
  cat(sprintf("简约式(Z→Y): %+.4f;  Wald 比 RD = %+.1fpp\n", coef(rf)["Z"], 100*wald))
  
  # 2SLS
  d[, Xhat := predict(m1)]
  m2 <- lm(reformulate(c("Xhat", use), response = "hosp_mort"), data = d)
  # 医院聚类稳健 SE (手工 sandwich)
  u <- residuals(m2); X <- model.matrix(m2)
  XtX1 <- solve(crossprod(X))
  meat <- matrix(0, ncol(X), ncol(X))
  for (h in unique(d$hospitalid)) {
    idx <- which(d$hospitalid == h)
    sc <- colSums(X[idx, ] * u[idx])
    meat <- meat + tcrossprod(sc)
  }
  G <- uniqueN(d$hospitalid)
  V <- XtX1 %*% meat %*% XtX1 * (G/(G-1)) * (nrow(d)/(nrow(d)-ncol(X)))
  se <- sqrt(diag(V))["Xhat"]
  est <- coef(m2)["Xhat"]
  cat(sprintf("2SLS: RD = %+.1fpp (聚类 95%%CI %+.1f, %+.1f)\n",
              100*est, 100*(est - 1.96*se), 100*(est + 1.96*se)))
  data.table(db = label, n = nrow(d), hosp = G, first_stage_t = round(zt, 2),
             wald_rd = round(100*wald, 1),
             tsls_rd = round(100*est, 1),
             lo = round(100*(est - 1.96*se), 1), hi = round(100*(est + 1.96*se), 1))
}

res <- list()
res[["eICU"]] <- iv_one(prep(file.path(dir_out, "E1_分析队列.csv")), "eICU-CRD")
nw_file <- file.path(dir_out, "N1_分析队列.csv")
if (file.exists(nw_file)) {
  nw <- fread(nw_file)
  if (!"hospitalid" %in% names(nw)) {
    cat("\nNWICU 队列无 hospitalid 列, 用 hospital 层面代理不可用 -> 跳过(12 院太少, 弱工具风险高)\n")
  } else res[["NWICU"]] <- iv_one(prep(nw_file), "NWICU")
}
res_all <- rbindlist(res)
print(res_all)
fwrite(res_all, file.path(dir_out, "E3_IV结果.csv"))
cat("/n完成 -> [clinical output directory]/E3_IV结果.csv/n")
cat("解读提示: 2SLS 估计的是 LATE(依从者效应), 与 ITT 方向的 IPCW-HT 不必数值一致, 方向+显著性一致即为强证据\n")

