# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 探查两个 miRNA 数据集
root <- PATHS$project

# GSE43618
f436 <- file.path(root, "00_data/GSE43618/GSE43618_series_matrix.txt.gz")
e436 <- GEOquery::getGEO(filename = f436, getGPL = FALSE)
cat("GSE43618 samples:", ncol(e436), "\n")
pd <- Biobase::pData(e436)
print(pd[, c("title","source_name_ch1")])
cat("platform:", unique(pd$platform_id), "\n")
ex <- Biobase::exprs(e436)
cat("expr dim:", dim(ex), "\n"); print(head(ex, 3))
cat("feature head:/n"); print(head(rownames(ex), 5))

# GSE296792 miRNA counts
f296 <- file.path(root, "00_data/GSE296792/GSE296792_Normalized_miRNA_counts_v1.csv.gz")
mi <- read.csv(gzfile(f296), check.names = FALSE, row.names = 1)
cat("\nGSE296792 miRNA matrix:", dim(mi), "\n")
print(head(rownames(mi), 5)); print(head(colnames(mi), 8))
