# robust_download.ps1 (ASCII-only; paths derived from script location)
# Resumable downloader with unlimited retries and remote-size verification.
$ErrorActionPreference = "Continue"
$root  = Split-Path $PSScriptRoot -Parent
$log   = Join-Path $root "02_results\robust_download.log"
$proxy = "http://127.0.0.1:7897"

function Log($msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    Add-Content -Path $log -Value $line
    Write-Output $line
}

$jobs = @(
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE313nnn/GSE313043/suppl/GSE313043_RAW.tar";
       f = Join-Path $root "00_data\GSE313043\GSE313043_RAW.tar" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE266nnn/GSE266873/suppl/GSE266873_RAW.tar";
       f = Join-Path $root "00_data\GSE266873\GSE266873_RAW.tar" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE179nnn/GSE179759/suppl/GSE179759_Matrix_processed.csv.gz";
       f = Join-Path $root "00_data\GSE179759\GSE179759_Matrix_processed.csv.gz" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE166nnn/GSE166638/suppl/GSE166638_RAW.tar";
       f = Join-Path $root "00_data\GSE166638\GSE166638_RAW.tar" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE163nnn/GSE163256/matrix/GSE163256_series_matrix.txt.gz";
       f = Join-Path $root "00_data\GSE163256\GSE163256_series_matrix.txt.gz" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE313nnn/GSE313043/suppl/filelist.txt";
       f = Join-Path $root "00_data\GSE313043\filelist.txt" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE266nnn/GSE266873/suppl/filelist.txt";
       f = Join-Path $root "00_data\GSE266873\filelist.txt" },
    @{ u = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE179nnn/GSE179759/suppl/filelist.txt";
       f = Join-Path $root "00_data\GSE179759\filelist.txt" }
)

function Get-Remote-Size($url) {
    foreach ($attempt in 1..6) {
        $out = curl.exe -sS -I -L --proxy $proxy --ssl-no-revoke --connect-timeout 20 $url 2>$null
        $cl = $out | Where-Object { $_ -match "content-length:" } | Select-Object -Last 1
        if ($cl) {
            $n = ($cl -replace "(?i)content-length:\s*", "").Trim()
            $v = 0
            if ([long]::TryParse($n, [ref]$v)) { return $v }
        }
        Start-Sleep 5
    }
    return -1
}

foreach ($j in $jobs) {
    $url = $j.u; $lf = $j.f
    $dir = Split-Path $lf -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

    $remote = Get-Remote-Size $url
    if ($remote -lt 0) { Log "WARN cannot HEAD size, will try anyway: $url"; $remote = -1 }

    $local = if (Test-Path $lf) { (Get-Item $lf).Length } else { 0 }
    Log ("START {0} local={1} remote={2}" -f (Split-Path $lf -Leaf), $local, $remote)

    $round = 0
    while ($true) {
        $local = if (Test-Path $lf) { (Get-Item $lf).Length } else { 0 }
        if ($remote -gt 0 -and $local -ge $remote) {
            Log ("COMPLETE {0} ({1} bytes)" -f (Split-Path $lf -Leaf), $local)
            break
        }
        $round++
        $before = $local
        curl.exe -sS -L -C - --proxy $proxy --ssl-no-revoke --connect-timeout 25 `
                 --max-time 1500 --speed-time 60 --speed-limit 1024 `
                 -o $lf $url 2>$null
        $code = $LASTEXITCODE
        $after = if (Test-Path $lf) { (Get-Item $lf).Length } else { 0 }
        Log ("  round {0} exit={1} {2}->{3} MB" -f $round, $code,
             [math]::Round($before/1MB,1), [math]::Round($after/1MB,1))
        if ($after -eq $before) { Start-Sleep 10 } else { Start-Sleep 2 }
    }
}
Log "ALL DOWNLOADS COMPLETE"
