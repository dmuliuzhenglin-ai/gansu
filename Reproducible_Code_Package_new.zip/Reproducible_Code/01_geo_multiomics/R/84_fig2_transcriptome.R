# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 84_fig2_transcriptome.R
# Figure 2. Consensus transcriptomic remodelling in a clean 2x2 layout:
# per-unit DEG counts, cross-sectional and longitudinal signed logFC matrices,
# and GO/KEGG over-representation. Short unit labels keep panels legible.
source(file.path(PATHS$project, "01_code/80_fig_theme.R"))
r <- file.path(PATHS$project, "02_results")
cl <- read.csv(file.path(r, "cross_DEG_long.csv"), check.names = FALSE)

short <- c(GSE335924_PBMC = "PBMC", GSE163256_monos = "Monos",
           GSE163256_neuts = "Neuts", GSE296792_h72_base = "72h",
           GSE296792_d7_base = "7d", GSE125512_second_vs_first = "Follow-up")
unit_order <- names(short)
cl$unit_short <- unname(short[cl$unit])

# ---- A: DEG counts per unit ----------------------------------------------
counts <- as.data.frame(table(cl$unit, cl$direction))
counts$short <- unname(short[as.character(counts$Var1)])
counts$short <- factor(counts$short, levels = rev(unname(short)))
pA <- ggplot(counts, aes(Freq, short, fill = Var2)) +
  geom_col(width = .7) +
  geom_text(aes(label = ifelse(Freq >= 60, Freq, "")),
            position = position_stack(vjust = .5),
            size = 2.3, colour = "grey15") +
  xlim(0, 1280) +
  scale_fill_manual(values = pal_dir, name = "Direction") +
  labs(x = "Number of DEGs", y = NULL, title = "Differential expression") +
  fig_theme + theme(legend.position = c(.82, .28))

# ---- helper: signed logFC matrix -----------------------------------------
logfc_matrix <- function(genes, units) {
  sub <- cl[cl$gene %in% genes & cl$unit %in% units, ]
  w <- reshape(sub[, c("gene", "unit", "logFC")], idvar = "gene",
               timevar = "unit", direction = "wide")
  rownames(w) <- w$gene; w$gene <- NULL
  colnames(w) <- sub("logFC.", "", colnames(w))
  as.matrix(w[genes, units, drop = FALSE])
}
prettify <- function(m) {
  data.frame(gene = rownames(m), m, check.names = FALSE) |>
    tidyr::pivot_longer(-gene, names_to = "unit", values_to = "logFC") |>
    dplyr::mutate(unit_short = unname(short[unit]))
}

# ---- B: cross-sectional consensus ----------------------------------------
cs <- read.csv(file.path(r, "cross_section_consensus.csv"), check.names = FALSE)
cs_up <- head(cs$gene[cs$consensus == "consensus_up"], 10)
cs_dn <- head(cs$gene[cs$consensus == "consensus_down"], 10)
cs_units <- c("GSE335924_PBMC", "GSE163256_monos", "GSE163256_neuts")
mB <- logfc_matrix(c(cs_up, rev(cs_dn)), cs_units); limB <- max(abs(mB), na.rm=TRUE)
dB <- prettify(mB); dB$gene <- factor(dB$gene, levels = rownames(mB))
pB <- ggplot(dB, aes(unit_short, gene, fill = logFC)) +
  geom_tile(colour = "white", linewidth = .3) +
  geom_text(aes(label = ifelse(is.na(logFC), "-", round(logFC, 1))), size = 2) +
  signed_scale(limits = c(-limB, limB), name = "logFC") +
  scale_x_discrete(position = "top") +
  labs(x = NULL, y = NULL, title = "Cross-sectional consensus") +
  fig_theme

# ---- C: longitudinal consensus -------------------------------------------
lg <- read.csv(file.path(r, "longitudinal_consensus.csv"), check.names = FALSE)
lg_up <- head(lg$gene[lg$consensus == "consensus_up"], 9)
lg_dn <- head(lg$gene[lg$consensus == "consensus_down"], 3)
lg_units <- c("GSE296792_h72_base", "GSE296792_d7_base",
              "GSE125512_second_vs_first")
mC <- logfc_matrix(c(lg_up, rev(lg_dn)), lg_units); limC <- max(abs(mC), na.rm=TRUE)
dC <- prettify(mC); dC$gene <- factor(dC$gene, levels = rownames(mC))
pC <- ggplot(dC, aes(unit_short, gene, fill = logFC)) +
  geom_tile(colour = "white", linewidth = .3) +
  geom_text(aes(label = ifelse(is.na(logFC), "-", round(logFC, 1))), size = 2) +
  signed_scale(limits = c(-limC, limC), name = "logFC") +
  scale_x_discrete(position = "top") +
  labs(x = NULL, y = NULL, title = "Longitudinal consensus") +
  fig_theme

# ---- D: consensus ORA -----------------------------------------------------
ora <- read.csv(file.path(r, "consensus_ORA.csv"), check.names = FALSE)
ora$family <- sub("_(GO_BP|GO_CC|GO_MF|KEGG)$", "", ora$set)
sel <- do.call(rbind, lapply(c("cs_up", "cs_dn", "lg_up"), function(fam) {
  d <- ora[ora$family == fam, ]; d <- d[order(d$p.adjust), ]; head(d, 5)
}))
sel$lab <- sub("\\(.*", "", sel$Description)
sel$lab <- ifelse(nchar(sel$lab) > 34,
                  paste0(substr(sel$lab, 1, 33), "..."), sel$lab)
sel$lab <- factor(sel$lab, levels = rev(sel$lab))
pD <- ggplot(sel, aes(family, lab, size = Count, colour = -log10(p.adjust))) +
  geom_point() +
  scale_colour_gradient(low = "#F5B041", high = "#922B21",
                        name = "-log10(FDR)") +
  scale_size_continuous(range = c(1.5, 4), name = "Genes") +
  labs(x = NULL, y = NULL, title = "Over-representation (GO/KEGG)") +
  fig_theme + theme(axis.text.x = element_text(face = "bold"),
                    axis.text.y = element_text(size = 6.8))

fig2 <- patchwork::wrap_plots(pA, pB, pC, pD, ncol = 2) +
  patchwork::plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(face = "bold", size = 10))
save_pdf(fig2, "Figure2_transcriptome", 180, 175)
