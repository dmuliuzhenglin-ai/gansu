# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 05_peek_xlsx.R - 探查 GSE335924 expression.xlsx 结构
p <- file.path(PATHS$project, "00_data/GSE335924/GSE335924_expression.xlsx")
cat("file size MB:", round(file.info(p)$size / 1e6, 1), "\n")
# sheet 名（不读全部数据，较快）
sheets <- readxl::excel_sheets(p)
cat("sheets:\n"); print(sheets)

# 每个 sheet 只读前 5 行看结构
for (sh in sheets) {
  cat("\n==== sheet:", sh, "====\n")
  d <- readxl::read_excel(p, sheet = sh, n_max = 5, .name_repair = "minimal")
  cat("dim preview cols:", ncol(d), "\n")
  print(names(d)[1:min(8, ncol(d))])
  print(as.data.frame(d[1:min(3, nrow(d)), 1:min(4, ncol(d))]))
}
