# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 71_final_annotate_313043.R
# Final, lineage-rigorous annotation. Neutrophils require the granulocyte-
# specific FCGR3B/CXCR2 (absent after PBMC isolation); CD14/VCAN-positive,
# FCGR3B-negative myeloid cells are monocytes. Recomputes markers, composition
# and hub localisation on the existing integrated object.
suppressPackageStartupMessages(library(Seurat))
options(future.globals.maxSize = 20 * 1024^3)
root <- PATHS$project; resdir <- file.path(root, "02_results")
sobj <- readRDS(file.path(resdir, "GSE313043_seurat.rds"))
expr_data <- GetAssayData(sobj, layer = "data")
clusters <- sobj$seurat_clusters; clv <- levels(clusters)
posfrac <- function(genes) {
  genes <- intersect(genes, rownames(expr_data))
  sapply(clv, function(cl) {
    cells <- which(clusters == cl)
    mean(colSums(expr_data[genes, cells, drop = FALSE] > 0) > 0)
  })
}
pf <- as.data.frame(list(
  tcell = posfrac(c("CD3D","CD3E","TRAC")),
  bcell = posfrac(c("CD79A","CD79B","MS4A1")),
  nk    = posfrac(c("GNLY","NKG7","KLRF1")),
  neut  = posfrac(c("FCGR3B","CXCR2")),
  dc    = posfrac(c("FCER1A","CLEC10A")),
  mono  = posfrac(c("CD14","VCAN"))))
rownames(pf) <- clv; print(round(pf, 2))

annot <- apply(pf, 1, function(r) {
  if (r["tcell"] >= .5) "T_cells"
  else if (r["bcell"] >= .5) "B_cells"
  else if (r["nk"] >= .6 && r["tcell"] < .5) "NK_cells"
  else if (r["neut"] >= .3) "neutrophils"
  else if (r["dc"] >= .5) "dendritic_cells"
  else if (r["mono"] >= .5) "monocytes"
  else "unassigned"
})
sobj$cell_type <- unname(annot[as.character(clusters)])
cat("\nfinal cell type counts:\n"); print(table(sobj$cell_type))

Idents(sobj) <- "cell_type"
mk <- FindAllMarkers(sobj, only.pos = TRUE, min.pct = .25,
                     logfc.threshold = .5, verbose = FALSE)
write.csv(mk, file.path(resdir, "GSE313043_celltype_markers.csv"),
          row.names = FALSE)
write.csv(as.data.frame(prop.table(table(sobj$treatment, sobj$cell_type), 1)),
          file.path(resdir, "GSE313043_composition_treatment.csv"),
          row.names = FALSE)
write.csv(as.data.frame(prop.table(table(sobj$day, sobj$cell_type), 1)),
          file.path(resdir, "GSE313043_composition_day.csv"),
          row.names = FALSE)

lists <- readRDS(file.path(resdir, "consensus_gene_lists.rds"))
w <- readRDS(file.path(resdir, "GSE335924_WGCNA.rds"))
hub <- unique(c(head(lists$cs_up, 60), head(lists$cs_dn, 30),
                head(w$gene_tab$gene[w$gene_tab$module == 1], 20)))
hub <- intersect(hub, rownames(sobj))
pct <- sapply(unique(sobj$cell_type), function(ct) {
  cells <- which(sobj$cell_type == ct)
  rowMeans(expr_data[hub, cells, drop = FALSE] > 0)
})
write.csv(as.data.frame(pct), file.path(resdir,
          "GSE313043_hub_pct_expressing.csv"))
saveRDS(sobj, file.path(resdir, "GSE313043_seurat.rds"))
cat("\nGSE313043 final annotation done\n")
