# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 检查 WGCNA / 免疫浸润 / 后续所需包
pkgs <- c("WGCNA", "GSVA", "GSEABase", "limma", "edgeR", "Seurat",
          "minfi", "IlluminaHumanMethylationEPICanno.ilm10b4.hg19",
          "ggplot2", "pheatmap", "RColorBrewer", "reshape2")
for (p in pkgs) {
  ok <- requireNamespace(p, quietly = TRUE)
  cat(sprintf("%-55s %s\n", p, if (ok) "OK" else "MISSING"))
}
# edgeR rds 内容
r <- readRDS(file.path(PATHS$project, "02_results/GSE335924_edgeR.rds"))
cat("\nGSE335924 edgeR rds class:", class(r), "\n")
if (is.list(r)) print(names(r))
