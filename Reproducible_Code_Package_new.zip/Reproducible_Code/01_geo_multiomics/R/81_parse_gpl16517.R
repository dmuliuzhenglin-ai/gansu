# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# 解析 GPL16517 注释
gpl <- GEOquery::getGEO(filename =
  file.path(PATHS$project, "00_data/GSE43618/GPL16517_family.soft.gz"))
cat("class:", class(gpl), "\n")
tb <- GEOquery::Table(gpl)
cat("table dim:", dim(tb), "\n"); cat("columns:\n"); print(colnames(tb))
if (nrow(tb) > 0) print(head(tb, 5))
