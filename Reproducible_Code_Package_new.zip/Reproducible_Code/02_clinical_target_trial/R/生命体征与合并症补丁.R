# --- shared path configuration; edit config_paths.R for your local machine ---
if (!exists("PATHS")) {
  for (.cf in c("config_paths.R", "../../config_paths.R", "../config_paths.R", "../../../config_paths.R"))
    if (file.exists(.cf)) { source(.cf); break }
}
# E1c - 补回生命体征与合并症（E1 运行时被中断跳过的两步）
# 直接读取 E1_分析队列.csv, 补 sbp/hr + 8 合并症列后覆盖写回
# 用法: source(file.path(PATHS$clinical, "eICU步骤1c.R"), encoding="UTF-8")
# 注意: vitalperiodic 很大, 只读需要的列; 全程有进度输出
# ============================================================

library(data.table)
options(error = NULL)   # 防止掉进 Browse 调试态
dir_eicu <- PATHS$eicu
dir_out  <- PATHS$clinical

rd <- function(name, ...) {
  f1 <- file.path(dir_eicu, paste0(name, ".csv.gz"))
  f2 <- file.path(dir_eicu, paste0(name, ".csv"))
  fread(if (file.exists(f1)) f1 else f2, ...)
}

out <- fread(file.path(dir_out, "E1_分析队列.csv"))
stays <- out$stay_id
cat("队列:", length(stays), "stays\n")

# ---- 1. 生命体征: vitalperiodic 首个非负 offset ----
cat("读取 vitalperiodic (大表, 1-3 分钟)...\n")
vt <- rd("vitalperiodic",
         select = c("patientunitstayid", "observationoffset", "systemicsystolic", "heartrate"))
cat("  总行数:", nrow(vt), "\n")
vt_c <- vt[patientunitstayid %in% stays & !is.na(observationoffset) & observationoffset >= 0]
setorder(vt_c, patientunitstayid, observationoffset)
vt_f <- vt_c[, .(sbp = suppressWarnings(as.numeric(systemicsystolic[1])),
                 hr  = suppressWarnings(as.numeric(heartrate[1]))),
             by = patientunitstayid]
cat("  覆盖 stays:", nrow(vt_f), "\n")

# ---- 2. 合并症: pasthistory 关键词 ----
cat("读取 pasthistory...\n")
ph <- rd("pasthistory", select = c("patientunitstayid", "pasthistorypath"))
ph_c <- ph[patientunitstayid %in% stays]
cm <- function(pat) unique(ph_c[grepl(pat, pasthistorypath, ignore.case = TRUE)]$patientunitstayid)
comorb <- data.table(patientunitstayid = stays)
comorb[, `:=`(
  hypertension  = as.integer(patientunitstayid %in% cm("hypertension")),
  diabetes      = as.integer(patientunitstayid %in% cm("diabetes")),
  ckd           = as.integer(patientunitstayid %in% cm("renal|kidney")),
  heart_failure = as.integer(patientunitstayid %in% cm("heart failure|CHF")),
  malignancy    = as.integer(patientunitstayid %in% cm("malignan|cancer|tumor")),
  liver         = as.integer(patientunitstayid %in% cm("cirrhosis|liver|hepat")),
  prior_vte     = as.integer(patientunitstayid %in% cm("thrombosis|DVT|pulmonary embol")),
  prior_stroke  = as.integer(patientunitstayid %in% cm("stroke|CVA"))
)]
cat("  pasthistory 覆盖 stays:", uniqueN(ph_c$patientunitstayid), "\n")
print(comorb[, lapply(.SD, sum), .SDcols = -1])

# ---- 3. 合并写回 ----
setnames(vt_f, "patientunitstayid", "stay_id")
setnames(comorb, "patientunitstayid", "stay_id")
out <- merge(out, vt_f, by = "stay_id", all.x = TRUE)
out <- merge(out, comorb, by = "stay_id", all.x = TRUE)

cat("\n合并后关键列缺失率:\n")
for (v in c("sbp", "hr", "hypertension", "prior_vte", "prior_stroke"))
  cat(sprintf("  %-12s %.1f%%\n", v, 100*mean(is.na(out[[v]]))))

fwrite(out, file.path(dir_out, "E1_分析队列.csv"))
cat("/n已写回 [clinical output directory]/E1_分析队列.csv, 列数:", ncol(out), "\n")
# E1d - 从 vitalaperiodic 补无创血压 (eICU 的 NIBP 在这张表)
# 策略: sbp = vitalperiodic 有创值优先, 缺失用 vitalaperiodic 的 noninvasivesystolic 首值
# 用法: source(file.path(PATHS$clinical, "eICU步骤1d.R"), encoding="UTF-8")
# ============================================================

library(data.table)
options(error = NULL)
dir_eicu <- PATHS$eicu
dir_out  <- PATHS$clinical

rd <- function(name, ...) {
  f1 <- file.path(dir_eicu, paste0(name, ".csv.gz"))
  f2 <- file.path(dir_eicu, paste0(name, ".csv"))
  fread(if (file.exists(f1)) f1 else f2, ...)
}

out <- fread(file.path(dir_out, "E1_分析队列.csv"))
stays <- out$stay_id
cat("当前 sbp 缺失:", sum(is.na(out$sbp)), "\n")

cat("读取 vitalaperiodic...\n")
va <- rd("vitalaperiodic",
         select = c("patientunitstayid", "observationoffset", "noninvasivesystolic"))
cat("  总行数:", nrow(va), "\n")
va_c <- va[patientunitstayid %in% stays & !is.na(observationoffset) & observationoffset >= 0
           & !is.na(noninvasivesystolic)]
setorder(va_c, patientunitstayid, observationoffset)
va_f <- va_c[, .(sbp_nibp = as.numeric(noninvasivesystolic[1])), by = patientunitstayid]
cat("  无创血压覆盖 stays:", nrow(va_f), "\n")

setnames(va_f, "patientunitstayid", "stay_id")
out <- merge(out, va_f, by = "stay_id", all.x = TRUE)
out[is.na(sbp), sbp := sbp_nibp]
out[, sbp_nibp := NULL]

cat("合并后 sbp 缺失:", sum(is.na(out$sbp)), sprintf("(%.1f%%)", 100*mean(is.na(out$sbp))), "\n")
cat("sbp 分布:", paste(round(quantile(out$sbp, c(.1,.5,.9), na.rm=TRUE)), collapse=" / "), "\n")

fwrite(out, file.path(dir_out, "E1_分析队列.csv"))
cat("已写回 [clinical output directory]/E1_分析队列.csv/n")

