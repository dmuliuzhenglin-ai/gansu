# ============================================================
# Master driver.
# Run this from the package root (the folder containing config_paths.R):
#   setwd(".../Reproducible_Code"); source("run_all.R")
#
# Notes
# * Many analysis scripts call rm(list = ls()); each one reloads PATHS through
#   its own config loader, so the sequence below keeps working.
# * Scripts read and write intermediate files (derived cohorts, DEG tables,
#   figures) and must be run in the order listed.
# * Diagnostic/peek scripts in 01_geo_multiomics/diagnostics are not run here;
#   use them interactively if you need to inspect an intermediate object.
# ============================================================

# --------------------------------------------------------------- 1. GEO multi-omics
# 1a. download the nine public GEO accessions (requires internet)
source("01_geo_multiomics/R/02_download_all.R", encoding = "UTF-8")
source("01_geo_multiomics/R/04_pdata_dict.R", encoding = "UTF-8")

# 1b. bulk differential expression
source("01_geo_multiomics/R/10_deg_gse335924.R", encoding = "UTF-8")
source("01_geo_multiomics/R/11_deg_gse296792.R", encoding = "UTF-8")
source("01_geo_multiomics/R/12_deg_gse125512.R", encoding = "UTF-8")
source("01_geo_multiomics/R/14_deg_gse163256.R", encoding = "UTF-8")

# 1c. cross-dataset integration and consensus enrichment
source("01_geo_multiomics/R/20_enrich_gse335924.R", encoding = "UTF-8")
source("01_geo_multiomics/R/30_cross_integrate.R", encoding = "UTF-8")
source("01_geo_multiomics/R/31_enrich_consensus.R", encoding = "UTF-8")

# 1d. co-expression and immune deconvolution
source("01_geo_multiomics/R/40_wgcna_gse335924.R", encoding = "UTF-8")
source("01_geo_multiomics/R/50_immune_infiltration.R", encoding = "UTF-8")

# 1e. single-cell analyses
source("01_geo_multiomics/R/60_scrna_gse266873.R", encoding = "UTF-8")
source("01_geo_multiomics/R/62_scrna_gse166638.R", encoding = "UTF-8")
source("01_geo_multiomics/R/67_scrna_gse313043.R", encoding = "UTF-8")
source("01_geo_multiomics/R/68_reannotate_313043.R", encoding = "UTF-8")
source("01_geo_multiomics/R/71_final_annotate_313043.R", encoding = "UTF-8")

# 1f. DNA methylation and methylation-expression links
source("01_geo_multiomics/R/70_peek_methyl.R", encoding = "UTF-8")
source("01_geo_multiomics/R/71_dmp_gse179759.R", encoding = "UTF-8")
source("01_geo_multiomics/R/72_relink_methyl.R", encoding = "UTF-8")

# 1g. miRNA annotation and regulatory network
source("01_geo_multiomics/R/81_parse_gpl16517.R", encoding = "UTF-8")
source("01_geo_multiomics/R/82_read_genelist.R", encoding = "UTF-8")
source("01_geo_multiomics/R/87_mir_296_names.R", encoding = "UTF-8")
source("01_geo_multiomics/R/88_c3_mirdb_names.R", encoding = "UTF-8")
source("01_geo_multiomics/R/89_mirdb_exact.R", encoding = "UTF-8")
source("01_geo_multiomics/R/89b_mirdb_exact.R", encoding = "UTF-8")
source("01_geo_multiomics/R/90_mirna_network.R", encoding = "UTF-8")

# 1h. manuscript figures (vector PDF/PNG)
source("01_geo_multiomics/R/80_fig_theme.R", encoding = "UTF-8")
source("01_geo_multiomics/R/83_fig1_clinical.R", encoding = "UTF-8")
source("01_geo_multiomics/R/84_fig2_transcriptome.R", encoding = "UTF-8")
source("01_geo_multiomics/R/85_fig3_network.R", encoding = "UTF-8")
source("01_geo_multiomics/R/86_fig4_scrna.R", encoding = "UTF-8")
source("01_geo_multiomics/R/88_fig5_epigenetic.R", encoding = "UTF-8")
source("01_geo_multiomics/R/89_fig6_concept.R", encoding = "UTF-8")

# --------------------------------------------------------------- 2. Clinical target trial
# Cohort construction and target-trial emulation across the three databases.
# These require the access-controlled source databases configured in config_paths.R.
source("02_clinical_target_trial/R/00.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/01_队列摘要.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/01补充.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/02b_结果汇总.R", encoding = "UTF-8")

# 2b. DETERMINISTIC re-analysis (authoritative post-review pipeline).
# Fixed foldid makes these runs byte-identical across sessions; see README 7.
source("02_clinical_target_trial/deterministic/153_02b_deterministic.R", encoding = "UTF-8")
source("02_clinical_target_trial/deterministic/155_nwicu_deterministic.R", encoding = "UTF-8")
source("02_clinical_target_trial/deterministic/156_evalue.R", encoding = "UTF-8")
source("02_clinical_target_trial/deterministic/158_fig1_rerun.R", encoding = "UTF-8")
source("02_clinical_target_trial/deterministic/159_forest_s4.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/03.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/04.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/05.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/21_supp_analyses.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/21a_evalue.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/22_ml_analyses.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/因果森林HTE + 策略树.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/验证队列构建.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/基线特征表.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/补充图.R", encoding = "UTF-8")
# eICU-specific and NWICU-specific emulation steps
source("02_clinical_target_trial/R/构建脚本 E1.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/EICU.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/EICU探测.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/E3.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/E4.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/E5.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/E6.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/E7.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/E8.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/N1b_修正摘要.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/NWICU步骤1c-队列重建脚本,R.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/NWICU步骤2-TTE验证分析脚本.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/NWICU步骤2-TTE验证分析脚本2.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/步骤4-竞争风险敏感性与阴性对照脚本.tx.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/可行性.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/探查补丁.R", encoding = "UTF-8")
source("02_clinical_target_trial/R/生命体征与合并症补丁.R", encoding = "UTF-8")

# --------------------------------------------------------------- 3. Immune bridge
# Python extraction steps are run separately (see README); the R steps below
# consume the extracted laboratory subsets.
source("03_immune_bridge/R/101_build_bridge.R", encoding = "UTF-8")
source("03_immune_bridge/R/103_build_eicu.R", encoding = "UTF-8")
source("03_immune_bridge/R/104_analyze_bridge.R", encoding = "UTF-8")
source("03_immune_bridge/R/105_figure8.R", encoding = "UTF-8")

# --------------------------------------------------------------- 4. Manuscript assembly
# The Word document is assembled by the Python build script in 04_manuscript:
#   python 04_manuscript/python/96_build_fii.py
# then exported to PDF with 04_manuscript/powershell/97_fii_to_pdf.ps1.
message("All R analysis steps completed.")
